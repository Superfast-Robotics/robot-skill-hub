import math
from ruckig import InputParameter, Ruckig, Trajectory, Result


def solve(task):
    n = len(task['current_position'])
    inp = InputParameter(n)
    inp.current_position = list(map(float, task['current_position']))
    inp.current_velocity = list(map(float, task['current_velocity']))
    inp.current_acceleration = list(map(float, task['current_acceleration']))
    inp.target_position = list(map(float, task['target_position']))
    inp.target_velocity = list(map(float, task['target_velocity']))
    inp.target_acceleration = list(map(float, task['target_acceleration']))
    inp.max_velocity = list(map(float, task['max_velocity']))
    inp.max_acceleration = list(map(float, task['max_acceleration']))
    inp.max_jerk = list(map(float, task['max_jerk']))
    # symmetric negative limits are needed for general motions
    inp.min_velocity = [-v for v in inp.max_velocity]
    inp.min_acceleration = [-a for a in inp.max_acceleration]

    r = Ruckig(n)
    traj = Trajectory(n)
    res = r.calculate(inp, traj)
    if res not in (Result.Working, Result.Finished):
        raise ValueError('Ruckig calculation failed')
    T = float(traj.duration)
    dt = float(task['dt'])
    if T < 0:
        T = 0.0
    # Build sample times with exact start/end and spacing <= dt when possible.
    if T == 0.0:
        times = [0.0, 0.0]
    else:
        intervals = max(1, int(math.ceil(T / dt)))
        # Prefer a strict dt grid. If that would exceed 3000 samples, cap at 2999 intervals.
        if intervals + 1 > 3000:
            intervals = 2999
        step = T / intervals
        if step > dt + 1e-12:
            # If the exact-end cap would violate dt, fall back to dt grid and merge final point if needed.
            intervals = int(math.floor(T / dt))
            times = [i * dt for i in range(intervals + 1)]
            if abs(times[-1] - T) > 1e-12:
                if len(times) >= 3000:
                    times[-1] = T
                else:
                    times.append(T)
            else:
                times[-1] = T
        else:
            times = [i * step for i in range(intervals)] + [T]
    pos = []
    vel = []
    acc = []
    for t in times:
        p, v, a = traj.at_time(t)
        pos.append([float(x) for x in p])
        vel.append([float(x) for x in v])
        acc.append([float(x) for x in a])
    return {
        'time_s': [float(x) for x in times],
        'position': pos,
        'velocity': vel,
        'acceleration': acc,
        'coordinate_type': task['coordinate_type'],
        'duration_s': T,
    }
