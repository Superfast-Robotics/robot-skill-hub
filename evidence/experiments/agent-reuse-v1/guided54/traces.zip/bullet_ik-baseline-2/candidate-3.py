import math, random
import numpy as np
import pybullet as p
from public import scene


def solve(task):
    q = np.array(task['joint_angles'], dtype=float)
    target = np.array(task['target_xyz'], dtype=float)
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0,0,0)
        robot = scene.create_arm(p)
        n = 7
        def fk_and_jac(q):
            for i, qi in enumerate(q):
                p.resetJointState(robot, i, float(qi))
            ls = p.getLinkState(robot, 6, computeForwardKinematics=True)
            pos = np.array(ls[4], dtype=float)
            zero = [0.0]*n
            qlist = list(map(float, q))
            jlin, jang = p.calculateJacobian(robot, 6, [0,0,0], qlist, zero, zero)
            J = np.array(jlin, dtype=float)
            return pos, J
        best = q.copy(); best_err = 1e9
        for restart in range(12):
            if restart:
                q = best + np.random.uniform(-1,1,size=7)
            for it in range(120):
                pos, J = fk_and_jac(q)
                e = target - pos
                err = float(np.linalg.norm(e))
                if err < best_err:
                    best_err, best = err, q.copy()
                if err < 1e-6:
                    break
                # damped least squares solve J dq = e
                JT = J.T
                lam = 1e-3 + 1e-2*err
                dq = JT @ np.linalg.solve(J @ JT + (lam*lam)*np.eye(3), e)
                # line search
                alpha = 1.0
                improved = False
                for _ in range(8):
                    qn = q + alpha*dq
                    posn, _ = fk_and_jac(qn)
                    if np.linalg.norm(target-posn) < err:
                        q = qn
                        improved = True
                        break
                    alpha *= 0.5
                if not improved:
                    q = q + 0.1*dq
            if best_err < 1e-4:
                break
        for i, qi in enumerate(best):
            p.resetJointState(robot, i, float(qi))
        pos = np.array(p.getLinkState(robot, 6, computeForwardKinematics=True)[4], dtype=float)
        err = float(np.linalg.norm(pos-target))
        return {'joint_angles_rad': best.tolist(), 'end_effector_xyz_m': pos.tolist(), 'position_error_m': err}
    finally:
        p.disconnect(cid)
