import math, itertools
import numpy as np
import pybullet as p
from scipy.optimize import least_squares
from public import scene


def fk(robot, q):
    for i, qi in enumerate(q):
        p.resetJointState(robot, i, float(qi))
    return np.array(p.getLinkState(robot, 6, computeForwardKinematics=True)[4], dtype=float)


def solve(task):
    q0 = np.array(task['joint_angles'], dtype=float)
    target = np.array(task['target_xyz'], dtype=float)
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0,0,0)
        robot = scene.create_arm(p)
        # initial guess from provided config and several local perturbations
        seeds = [q0]
        for s in [0.2, -0.2, 0.5, -0.5]:
            seeds.append(q0 + s*np.array([1,-1,1,-1,1,-1,1]))
            seeds.append(q0 + s*np.array([1,1,-1,-1,1,1,-1]))
        best = None
        best_cost = 1e9
        bounds = (-np.pi*4*np.ones(7), np.pi*4*np.ones(7))
        for seed in seeds:
            def fun(q):
                return fk(robot, q) - target
            res = least_squares(fun, seed, bounds=bounds, xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=200)
            cost = np.linalg.norm(res.fun)
            if cost < best_cost:
                best_cost = cost
                best = res.x
            if best_cost < 1e-6:
                break
        for i, qi in enumerate(best):
            p.resetJointState(robot, i, float(qi))
        pos = np.array(p.getLinkState(robot, 6, computeForwardKinematics=True)[4], dtype=float)
        err = float(np.linalg.norm(pos-target))
        return {'joint_angles_rad': best.tolist(), 'end_effector_xyz_m': pos.tolist(), 'position_error_m': err}
    finally:
        p.disconnect(cid)
