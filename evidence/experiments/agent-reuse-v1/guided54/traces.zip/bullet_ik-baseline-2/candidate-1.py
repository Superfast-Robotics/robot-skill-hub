import json, math
import pybullet as p
from public import scene


def solve(task):
    init = task['joint_angles']
    target = task['target_xyz']
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0, 0, 0)
        robot = scene.create_arm(p)
        for i, q in enumerate(init):
            p.resetJointState(robot, i, q)
        # Damped least squares IK with limits derived from joint type and reasonable ranges
        ll = [-2*math.pi]*7
        ul = [2*math.pi]*7
        jr = [4*math.pi]*7
        rp = init
        sol = p.calculateInverseKinematics(robot, 6, target, lowerLimits=ll, upperLimits=ul, jointRanges=jr, restPoses=rp, maxNumIterations=200, residualThreshold=1e-6)
        sol = list(sol[:7])
        for i, q in enumerate(sol):
            p.resetJointState(robot, i, q)
        pos = p.getLinkState(robot, 6, computeForwardKinematics=True)[4]
        err = math.sqrt(sum((pos[i]-target[i])**2 for i in range(3)))
        return {'joint_angles_rad': sol, 'end_effector_xyz_m': list(pos), 'position_error_m': err}
    finally:
        p.disconnect(cid)
