from typing import Any, Dict, List


def solve(task: Dict[str, Any]):
    from ruckig import InputParameter, Ruckig, Trajectory, Result

    n = len(task["current_position"])
    inp = InputParameter(n)
    inp.current_position = [float(x) for x in task["current_position"]]
    inp.current_velocity = [float(x) for x in task["current_velocity"]]
    inp.current_acceleration = [float(x) for x in task["current_acceleration"]]
    inp.target_position = [float(x) for x in task["target_position"]]
    inp.target_velocity = [float(x) for x in task["target_velocity"]]
    inp.target_acceleration = [float(x) for x in task["target_acceleration"]]
    inp.max_velocity = [float(x) for x in task["max_velocity"]]
    inp.max_acceleration = [float(x) for x in task["max_acceleration"]]
    inp.max_jerk = [float(x) for x in task["max_jerk"]]

    ruckig = Ruckig(n)
    traj = Trajectory(n)
    result = ruckig.calculate(inp, traj)
    if result == Result.ErrorInvalidInput:
        raise ValueError("Invalid input for Ruckig")

    duration = float(traj.duration)
    dt = float(task["dt"])
    # Sample times: include t=0 and exact completion time, spacing <= dt.
    if duration <= 0.0:
        times = [0.0]
    else:
        times = [0.0]
        t = dt
        # avoid floating accumulation issues; keep spacing <= dt
        while t < duration - 1e-12 and len(times) < 2999:
            times.append(float(t))
            t += dt
        if len(times) >= 3000:
            # compress by using uniform spacing not exceeding dt
            steps = 2999
            times = [duration * i / steps for i in range(steps)]
        if abs(times[-1] - duration) > 1e-12:
            times.append(duration)

    position: List[List[float]] = []
    velocity: List[List[float]] = []
    acceleration: List[List[float]] = []
    for t in times:
        p, v, a = traj.at_time(float(t))
        position.append([float(x) for x in p])
        velocity.append([float(x) for x in v])
        acceleration.append([float(x) for x in a])

    return {
        "time_s": [float(x) for x in times],
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": task["coordinate_type"],
        "duration_s": duration,
    }
