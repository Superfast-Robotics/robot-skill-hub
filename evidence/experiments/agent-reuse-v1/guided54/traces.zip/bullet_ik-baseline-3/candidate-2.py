import json, math, numpy as np
import pybullet as p
from public.scene import create_arm

def solve(task):
    target = task['target_xyz']
    q0 = task['joint_angles']
    cid = p.connect(p.DIRECT)
    robot = create_arm(p)
    p.resetBasePositionAndOrientation(robot,[0,0,0],[0,0,0,1])
    for i,a in enumerate(q0):
        p.resetJointState(robot,i,float(a))
    q = p.calculateInverseKinematics(robot, 6, target, maxNumIterations=200, residualThreshold=1e-10)
    q = list(q[:7])
    for i,a in enumerate(q): p.resetJointState(robot,i,float(a))
    ee = p.getLinkState(robot,6,computeForwardKinematics=True)[4]
    err = float(np.linalg.norm(np.array(ee)-np.array(target)))
    p.disconnect()
    return {'joint_angles_rad': q, 'end_effector_xyz_m': list(map(float,ee)), 'position_error_m': err}
