import json, math
import numpy as np
import pybullet as p
from public.scene import create_arm

def fk(q):
    cid = p.connect(p.DIRECT)
    robot = create_arm(p)
    p.resetBasePositionAndOrientation(robot,[0,0,0],[0,0,0,1])
    for i,a in enumerate(q):
        p.resetJointState(robot,i,float(a))
    ls = p.getLinkState(robot,6,computeForwardKinematics=True)
    x = ls[4]
    p.disconnect()
    return x

print(fk([0.1,-0.3,0.4,0.2,-0.2,0.1,0.1]))