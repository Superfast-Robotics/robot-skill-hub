import math
from ruckig import InputParameter, Ruckig, Trajectory, Result


def solve(task):
    n = len(task["current_position"])
    inp = InputParameter(n)
    inp.current_position = list(task["current_position"])
    inp.current_velocity = list(task["current_velocity"])
    inp.current_acceleration = list(task["current_acceleration"])
    inp.target_position = list(task["target_position"])
    inp.target_velocity = list(task["target_velocity"])
    inp.target_acceleration = list(task["target_acceleration"])
    inp.max_velocity = list(task["max_velocity"])
    inp.max_acceleration = list(task["max_acceleration"])
    inp.max_jerk = list(task["max_jerk"])

    r = Ruckig(n)
    traj = Trajectory(n)
    res = r.calculate(inp, traj)
    if res != Result.Working and res != Result.Finished:
        raise ValueError(f"Ruckig failed: {res}")

    duration = float(traj.duration)
    dt = float(task["dt"])
    # Build time grid including exact endpoint.
    if duration == 0.0:
        times = [0.0, 0.0]
    else:
        intervals = max(1, int(math.ceil(duration / dt)))
        if intervals + 1 > 3000:
            intervals = 2999
        step = duration / intervals
        if step > dt:
            # If necessary due to sample cap, keep at most 3000 samples while preserving endpoint.
            # This is the best possible under the hard cap.
            step = duration / intervals
        times = [step * i for i in range(intervals)] + [duration]
        times[0] = 0.0
        times[-1] = duration
        # de-duplicate potential floating issue
        for i in range(1, len(times)):
            if times[i] < times[i-1]:
                times[i] = times[i-1]

    pos, vel, acc = [], [], []
    for t in times:
        p, v, a = traj.at_time(float(t))
        pos.append([float(x) for x in p])
        vel.append([float(x) for x in v])
        acc.append([float(x) for x in a])

    return {
        "time_s": [float(t) for t in times],
        "position": pos,
        "velocity": vel,
        "acceleration": acc,
        "coordinate_type": task["coordinate_type"],
        "duration_s": duration,
    }
