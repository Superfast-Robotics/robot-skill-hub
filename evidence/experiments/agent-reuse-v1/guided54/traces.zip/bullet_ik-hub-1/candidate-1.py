import json, math
import numpy as np
import pybullet as p
import pybullet_data
from public.scene import create_arm


def solve(task):
    target = np.asarray(task['target_xyz'], dtype=float)
    q0 = list(map(float, task['joint_angles']))
    cid = p.connect(p.DIRECT)
    try:
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        p.loadURDF('plane.urdf')
        robot = create_arm(p)
        for i, q in enumerate(q0):
            p.resetJointState(robot, i, q)
        # Joint limits: revolute without explicit limits, use wide bounds
        lower = [-10.0] * 7
        upper = [10.0] * 7
        ranges = [20.0] * 7
        rest = q0
        q_sol = p.calculateInverseKinematics(robot, 6, target.tolist(), lowerLimits=lower, upperLimits=upper, jointRanges=ranges, restPoses=rest, maxNumIterations=200, residualThreshold=1e-8)
        q_sol = [float(x) for x in q_sol[:7]]
        for i, q in enumerate(q_sol):
            p.resetJointState(robot, i, q)
        ls = p.getLinkState(robot, 6, computeForwardKinematics=True)
        ee = np.array(ls[4], dtype=float)
        err = float(np.linalg.norm(ee - target))
        return {'joint_angles_rad': q_sol, 'end_effector_xyz_m': ee.tolist(), 'position_error_m': err}
    finally:
        p.disconnect(cid)
