import numpy as np
import pybullet as p
from public.scene import create_arm


def fk(robot, q):
    for i, qi in enumerate(q):
        p.resetJointState(robot, i, float(qi))
    return np.array(p.getLinkState(robot, 6, computeForwardKinematics=True)[4], dtype=float)


def solve(task):
    target = np.array(task['target_xyz'], dtype=float)
    q = np.array(task['joint_angles'], dtype=float)
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0,0,-9.8)
        robot = create_arm(p)
        best_q = q.copy(); best_err = 1e9; best_ee = None
        # multi-start around initial and zero
        seeds = [q, np.zeros(7), q + np.linspace(-0.5,0.5,7), q - np.linspace(0.5,-0.5,7)]
        for seed in seeds:
            qi = seed.astype(float).copy()
            for _ in range(100):
                ee = fk(robot, qi)
                e = target - ee
                err = float(np.linalg.norm(e))
                if err < best_err:
                    best_err = err; best_q = qi.copy(); best_ee = ee.copy()
                if err < 1e-4:
                    break
                zeros = [0.0]*7
                Jlin, Jang = p.calculateJacobian(robot, 6, [0,0,0], qi.tolist(), zeros, zeros)
                J = np.array(Jlin, dtype=float)
                # damped least squares
                lam = 0.05
                A = J @ J.T + (lam**2)*np.eye(3)
                dq = J.T @ np.linalg.solve(A, e)
                norm = np.linalg.norm(dq)
                if norm > 0.4:
                    dq *= 0.4 / norm
                qi = qi + dq
            ee = fk(robot, qi)
            err = float(np.linalg.norm(target - ee))
            if err < best_err:
                best_err = err; best_q = qi.copy(); best_ee = ee.copy()
        # polish with small random restarts using built-in IK around best
        for _ in range(5):
            qik = p.calculateInverseKinematics(robot, 6, target.tolist(), restPoses=best_q.tolist(), maxNumIterations=100, residualThreshold=1e-10)
            qi = np.array(qik[:7], dtype=float)
            ee = fk(robot, qi)
            err = float(np.linalg.norm(target - ee))
            if err < best_err:
                best_err = err; best_q = qi.copy(); best_ee = ee.copy()
        return {'joint_angles_rad': best_q.tolist(), 'end_effector_xyz_m': best_ee.tolist(), 'position_error_m': best_err}
    finally:
        p.disconnect(cid)
