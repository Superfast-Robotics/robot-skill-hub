import json, math
from typing import Any
import numpy as np
import pybullet as p
import pybullet_data
import scene


def _fk(robot, q):
    for i, a in enumerate(q):
        p.resetJointState(robot, i, float(a))
    ls = p.getLinkState(robot, 6, computeForwardKinematics=True)
    return np.array(ls[4], dtype=float)


def solve(task):
    q0 = np.array(task['joint_angles'], dtype=float)
    target = np.array(task['target_xyz'], dtype=float)
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        p.setTimeStep(1/240)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        robot = scene.create_arm(p)
        n = p.getNumJoints(robot)
        for i, a in enumerate(q0):
            p.resetJointState(robot, i, float(a))
        lower = [-3.14159]*n
        upper = [3.14159]*n
        ranges = [6.28318]*n
        rest = q0.tolist()
        # several restarts around initial configuration and zero pose
        cands = []
        for seed in [rest, [0.0]*n, (q0*0.5).tolist(), (q0*0.0).tolist()]:
            try:
                sol = p.calculateInverseKinematics(robot, 6, target.tolist(), lowerLimits=lower, upperLimits=upper, jointRanges=ranges, restPoses=seed, maxNumIterations=200, residualThreshold=1e-6)
            except TypeError:
                sol = p.calculateInverseKinematics(robot, 6, target.tolist(), restPoses=seed, maxNumIterations=200, residualThreshold=1e-6)
            cands.append(sol[:n])
        best = None
        best_err = float('inf')
        best_ee = None
        for sol in cands:
            ee = _fk(robot, sol)
            err = float(np.linalg.norm(ee - target))
            if err < best_err:
                best_err = err
                best = sol
                best_ee = ee
        # local random refinement via damped least squares numeric jacobian
        q = np.array(best, dtype=float)
        for _ in range(60):
            ee = _fk(robot, q)
            e = target - ee
            err = np.linalg.norm(e)
            if err < 2e-3:
                break
            J = np.zeros((3, n))
            eps = 1e-4
            for j in range(n):
                qq = q.copy(); qq[j] += eps
                ee2 = _fk(robot, qq)
                J[:, j] = (ee2 - ee) / eps
            lam = 1e-3
            dq = J.T @ np.linalg.solve(J @ J.T + lam*np.eye(3), e)
            q += dq
            # keep within bounds
            q = np.clip(q, -math.pi, math.pi)
        ee = _fk(robot, q)
        err = float(np.linalg.norm(ee - target))
        return {'joint_angles_rad': [float(x) for x in q.tolist()], 'end_effector_xyz_m': [float(x) for x in ee.tolist()], 'position_error_m': err}
    finally:
        p.disconnect(cid)
