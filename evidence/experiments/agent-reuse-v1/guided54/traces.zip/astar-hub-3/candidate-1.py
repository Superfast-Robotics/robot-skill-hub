import math, heapq
import numpy as np


def solve(task):
    start = np.array(task["start"], dtype=float)
    goal = np.array(task["goal"], dtype=float)
    low, high = map(float, task["bounds"])
    obstacles = [np.array(o, dtype=float) for o in task.get("obstacles", [])]
    rr = float(task["robot_radius"])

    # Conservative interior box; strictly inside bounds with radius clearance.
    inner_low = low + rr
    inner_high = high - rr

    def inside(p):
        return (inner_low < p[0] < inner_high) and (inner_low < p[1] < inner_high)

    def seg_ok(a, b):
        # Sample densely enough to respect radius clearance against points and the boundary.
        dist = float(np.linalg.norm(b - a))
        n = max(2, int(math.ceil(dist / max(0.05, rr / 5.0))) + 1)
        for t in np.linspace(0.0, 1.0, n):
            p = a * (1 - t) + b * t
            if not inside(p):
                return False
            if obstacles:
                d = np.min([np.linalg.norm(p - o) for o in obstacles])
                if d <= rr - 1e-9:
                    return False
        return True

    # If direct path works, use it.
    if seg_ok(start, goal):
        return {"path_xy": [start.tolist(), goal.tolist()], "length_m": float(np.linalg.norm(goal - start))}

    # Grid-based A* with obstacle inflation.
    res = min(0.5, max(0.1, rr / 2.0))
    xs = np.arange(inner_low, inner_high + 1e-9, res)
    ys = np.arange(inner_low, inner_high + 1e-9, res)
    # Include start/goal snapped nodes separately.
    def snap(p):
        return np.array([xs[np.argmin(np.abs(xs - p[0]))], ys[np.argmin(np.abs(ys - p[1]))]], dtype=float)

    s = snap(start)
    g = snap(goal)

    # Ensure snapped start/goal are valid and segments to actual points are valid.
    if not inside(s) or not inside(g):
        return {"path_xy": [start.tolist(), goal.tolist()], "length_m": float(np.linalg.norm(goal - start))}

    def node_ok(p):
        return inside(p) and (not obstacles or min(np.linalg.norm(p - o) for o in obstacles) > rr - 1e-9)

    if not node_ok(s) or not node_ok(g):
        # Try nudging to nearby free nodes.
        cand = []
        for dx in [0, 1, -1, 2, -2]:
            for dy in [0, 1, -1, 2, -2]:
                sp = s + np.array([dx, dy]) * res
                gp = g + np.array([dx, dy]) * res
                if node_ok(sp):
                    cand.append((np.linalg.norm(sp - start), sp, g))
                if node_ok(gp):
                    cand.append((np.linalg.norm(gp - goal), s, gp))
        if cand:
            _, s, g = min(cand, key=lambda x: x[0])

    # Build free node set from grid.
    free = {}
    for x in xs:
        for y in ys:
            p = np.array([x, y], dtype=float)
            if node_ok(p):
                free[(round(x, 8), round(y, 8))] = p

    start_key = (round(s[0], 8), round(s[1], 8))
    goal_key = (round(g[0], 8), round(g[1], 8))
    if start_key not in free or goal_key not in free:
        return {"path_xy": [start.tolist(), goal.tolist()], "length_m": float(np.linalg.norm(goal - start))}

    motions = [(1,0),(0,1),(-1,0),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    pq = [(0.0, 0.0, start_key, None)]
    best = {start_key: 0.0}
    parent = {}
    visited = set()

    while pq:
        f, cost, key, par = heapq.heappop(pq)
        if key in visited:
            continue
        visited.add(key)
        parent[key] = par
        if key == goal_key:
            break
        p = free[key]
        for mx, my in motions:
            nk = (round(p[0] + mx * res, 8), round(p[1] + my * res, 8))
            if nk not in free or nk in visited:
                continue
            q = free[nk]
            if not seg_ok(p, q):
                continue
            nc = cost + float(np.linalg.norm(q - p))
            if nc < best.get(nk, float('inf')):
                best[nk] = nc
                h = float(np.linalg.norm(g - q))
                heapq.heappush(pq, (nc + h, nc, nk, key))

    if goal_key not in parent:
        # Fallback polyline around obstacle centroid with a simple two-hop detour.
        pts = [start.tolist(), [start[0], max(start[1], goal[1]) + rr + 0.5], goal.tolist()]
        if not (seg_ok(np.array(pts[0]), np.array(pts[1])) and seg_ok(np.array(pts[1]), np.array(pts[2]))):
            pts = [start.tolist(), [max(start[0], goal[0]) + rr + 0.5, start[1]], goal.tolist()]
        length = sum(float(np.linalg.norm(np.array(pts[i+1]) - np.array(pts[i]))) for i in range(len(pts)-1))
        return {"path_xy": pts, "length_m": length}

    # Reconstruct path and prepend/append actual start/goal.
    rev = []
    k = goal_key
    while k is not None:
        rev.append(free[k].tolist())
        k = parent[k]
    rev = rev[::-1]
    path = [start.tolist()]
    # Avoid duplicate start if snapped equal.
    for p in rev:
        if np.linalg.norm(np.array(p) - np.array(path[-1])) > 1e-9:
            path.append(p)
    if np.linalg.norm(np.array(path[-1]) - goal) > 1e-9:
        path.append(goal.tolist())

    # Simplify collinear waypoints while preserving collision-free segments.
    simplified = [np.array(path[0], dtype=float)]
    for p in map(lambda x: np.array(x, dtype=float), path[1:]):
        while len(simplified) >= 2 and seg_ok(simplified[-2], p):
            simplified.pop()
        simplified.append(p)
    # Ensure all segments valid; if not, keep original.
    final = [simplified[0]]
    for p in simplified[1:]:
        if not seg_ok(final[-1], p):
            final.append(p)
        else:
            final.append(p)
    path_xy = [p.tolist() for p in final]
    length = float(sum(np.linalg.norm(final[i+1]-final[i]) for i in range(len(final)-1)))
    return {"path_xy": path_xy, "length_m": length}
