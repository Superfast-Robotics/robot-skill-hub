import math
import heapq
import numpy as np


def _dist_point_segment(px, py, ax, ay, bx, by):
    abx, aby = bx - ax, by - ay
    apx, apy = px - ax, py - ay
    denom = abx * abx + aby * aby
    if denom == 0:
        return math.hypot(px - ax, py - ay)
    t = (apx * abx + apy * aby) / denom
    t = 0.0 if t < 0.0 else 1.0 if t > 1.0 else t
    cx, cy = ax + t * abx, ay + t * aby
    return math.hypot(px - cx, py - cy)


def _segment_safe(a, b, obstacles, rr, bounds, eps=1e-9):
    ax, ay = a
    bx, by = b
    mn, mx = bounds
    # strict interior at endpoints and all sampled points via analytic bounds on segment bbox
    if not (mn + rr < ax < mx - rr and mn + rr < ay < mx - rr):
        return False
    if not (mn + rr < bx < mx - rr and mn + rr < by < mx - rr):
        return False
    # boundary clearance: since segment is inside open square if endpoints are and segment is straight,
    # still check a few sample points for numerical robustness
    for t in (0.25, 0.5, 0.75):
        x = ax + (bx - ax) * t
        y = ay + (by - ay) * t
        if not (mn + rr < x < mx - rr and mn + rr < y < mx - rr):
            return False
    for ox, oy in obstacles:
        if _dist_point_segment(ox, oy, ax, ay, bx, by) <= rr - eps:
            return False
    return True


def solve(task):
    sx, sy = task['start']
    gx, gy = task['goal']
    mn, mx = task['bounds']
    obstacles = [tuple(map(float, p)) for p in task['obstacles']]
    rr = float(task['robot_radius'])

    # Fine grid search in free space with a safety margin.
    res = min(0.25, max(0.1, rr / 2.0))
    margin = rr + 1e-6
    x0 = mn + margin
    y0 = mn + margin
    x1 = mx - margin
    y1 = mx - margin
    if x1 <= x0 or y1 <= y0:
        return {"path_xy": [[sx, sy], [gx, gy]], "length_m": math.hypot(gx - sx, gy - sy)}

    xs = np.arange(x0, x1 + 1e-9, res)
    ys = np.arange(y0, y1 + 1e-9, res)
    nxs, nys = len(xs), len(ys)

    # occupancy at grid points (node validity)
    free = np.ones((nxs, nys), dtype=bool)
    for i, x in enumerate(xs):
        for j, y in enumerate(ys):
            for ox, oy in obstacles:
                if math.hypot(x - ox, y - oy) <= rr - 1e-9:
                    free[i, j] = False
                    break

    def nearest_idx(x, y):
        i = int(round((x - x0) / res))
        j = int(round((y - y0) / res))
        i = max(0, min(nxs - 1, i))
        j = max(0, min(nys - 1, j))
        return i, j

    sidx = nearest_idx(sx, sy)
    gidx = nearest_idx(gx, gy)
    if not free[sidx] or not free[gidx]:
        # fall back to exact start/goal with simple detour waypoints around obstacle line if possible
        # try via top and bottom corridors
        candidates = [
            [(sx, sy), (sx, mx - margin), (gx, mx - margin), (gx, gy)],
            [(sx, sy), (sx, mn + margin), (gx, mn + margin), (gx, gy)],
        ]
        best = None
        for path in candidates:
            ok = all(_segment_safe(path[k], path[k+1], obstacles, rr, (mn, mx)) for k in range(len(path)-1))
            if ok:
                length = sum(math.hypot(path[k+1][0]-path[k][0], path[k+1][1]-path[k][1]) for k in range(len(path)-1))
                if best is None or length < best[1]:
                    best = (path, length)
        if best is not None:
            return {"path_xy": [list(p) for p in best[0]], "length_m": best[1]}
        return {"path_xy": [[sx, sy], [gx, gy]], "length_m": math.hypot(gx - sx, gy - sy)}

    motions = [(1,0,res),(0,1,res),(-1,0,res),(0,-1,res),(1,1,res*math.sqrt(2)),(1,-1,res*math.sqrt(2)),(-1,1,res*math.sqrt(2)),(-1,-1,res*math.sqrt(2))]
    start = sidx
    goal = gidx

    def h(i, j):
        return math.hypot(xs[i]-xs[goal[0]], ys[j]-ys[goal[1]])

    openh = [(h(*start), 0.0, start)]
    came = {start: None}
    gcost = {start: 0.0}
    visited = set()
    found = False
    while openh:
        f, g, cur = heapq.heappop(openh)
        if cur in visited:
            continue
        visited.add(cur)
        if cur == goal:
            found = True
            break
        ci, cj = cur
        for di, dj, step in motions:
            ni, nj = ci + di, cj + dj
            if ni < 0 or nj < 0 or ni >= nxs or nj >= nys or not free[ni, nj]:
                continue
            a = (xs[ci], ys[cj])
            b = (xs[ni], ys[nj])
            if not _segment_safe(a, b, obstacles, rr, (mn, mx)):
                continue
            ng = g + step
            nxt = (ni, nj)
            if ng < gcost.get(nxt, float('inf')):
                gcost[nxt] = ng
                came[nxt] = cur
                heapq.heappush(openh, (ng + h(ni, nj), ng, nxt))

    if not found:
        # fallback via two corridor waypoints that are likely safe
        top = mx - margin
        bot = mn + margin
        candidates = [
            [(sx, sy), (sx, top), (gx, top), (gx, gy)],
            [(sx, sy), (sx, bot), (gx, bot), (gx, gy)],
        ]
        best = None
        for path in candidates:
            ok = all(_segment_safe(path[k], path[k+1], obstacles, rr, (mn, mx)) for k in range(len(path)-1))
            if ok:
                length = sum(math.hypot(path[k+1][0]-path[k][0], path[k+1][1]-path[k][1]) for k in range(len(path)-1))
                if best is None or length < best[1]:
                    best = (path, length)
        if best is not None:
            return {"path_xy": [list(p) for p in best[0]], "length_m": best[1]}
        # last resort: direct segment if safe else use tiny dogleg
        path = [(sx, sy), (sx, sy + 0.5), (gx, gy - 0.5), (gx, gy)]
        length = sum(math.hypot(path[k+1][0]-path[k][0], path[k+1][1]-path[k][1]) for k in range(len(path)-1))
        return {"path_xy": [list(p) for p in path], "length_m": length}

    rev = [goal]
    cur = goal
    while came[cur] is not None:
        cur = came[cur]
        rev.append(cur)
    rev.reverse()
    path = [(sx, sy)] + [(float(xs[i]), float(ys[j])) for i, j in rev[1:-1]] + [(gx, gy)]

    # simplify path by skipping unnecessary intermediate points if safe
    simplified = [path[0]]
    i = 0
    while i < len(path)-1:
        j = len(path)-1
        while j > i+1:
            if _segment_safe(simplified[-1], path[j], obstacles, rr, (mn, mx)):
                break
            j -= 1
        simplified.append(path[j])
        i = j

    length = sum(math.hypot(simplified[k+1][0]-simplified[k][0], simplified[k+1][1]-simplified[k][1]) for k in range(len(simplified)-1))
    return {"path_xy": [[float(x), float(y)] for x, y in simplified], "length_m": float(length)}
