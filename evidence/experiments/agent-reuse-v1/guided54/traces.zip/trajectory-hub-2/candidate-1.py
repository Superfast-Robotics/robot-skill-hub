from typing import Any, Dict, List


def solve(task):
    from ruckig import InputParameter, Ruckig, Trajectory, Result
    import math

    cp = task['current_position']
    cv = task['current_velocity']
    ca = task['current_acceleration']
    tp = task['target_position']
    tv = task['target_velocity']
    ta = task['target_acceleration']
    mv = task['max_velocity']
    ma = task['max_acceleration']
    mj = task['max_jerk']
    dt = float(task['dt'])
    ctype = task['coordinate_type']
    dof = len(cp)

    inp = InputParameter(dof)
    inp.current_position = [float(x) for x in cp]
    inp.current_velocity = [float(x) for x in cv]
    inp.current_acceleration = [float(x) for x in ca]
    inp.target_position = [float(x) for x in tp]
    inp.target_velocity = [float(x) for x in tv]
    inp.target_acceleration = [float(x) for x in ta]
    inp.max_velocity = [float(abs(x)) for x in mv]
    inp.max_acceleration = [float(abs(x)) for x in ma]
    inp.max_jerk = [float(abs(x)) for x in mj]
    inp.min_velocity = [-float(abs(x)) for x in mv]
    inp.min_acceleration = [-float(abs(x)) for x in ma]

    r = Ruckig(dof)
    traj = Trajectory(dof)
    res = r.calculate(inp, traj)
    if res == Result.ErrorInvalidInput:
        raise ValueError('Invalid input')
    duration = float(traj.duration)
    if not math.isfinite(duration) or duration < 0 or duration > 30:
        raise ValueError('Invalid duration')

    times = []
    t = 0.0
    # sample at spacing <= dt and exact duration
    while t < duration - 1e-15:
        times.append(t)
        t += dt
        if len(times) > 2999:
            break
    if not times or abs(times[-1] - duration) > 1e-12:
        if times and duration - times[-1] < 1e-15:
            times[-1] = duration
        else:
            times.append(duration)
    if times[0] != 0.0:
        times.insert(0, 0.0)
    # ensure no overshoot count
    if len(times) > 3000:
        # downsample by slightly larger effective step if needed, but keep first and last
        step = duration / 2999.0 if duration > 0 else 0.0
        times = [i * step for i in range(2999)] + [duration]

    pos = []
    vel = []
    acc = []
    for ti in times:
        p, v, a = traj.at_time(float(ti))
        pos.append([float(x) for x in p])
        vel.append([float(x) for x in v])
        acc.append([float(x) for x in a])

    return {
        'time_s': [float(x) for x in times],
        'position': pos,
        'velocity': vel,
        'acceleration': acc,
        'coordinate_type': ctype,
        'duration_s': duration,
    }
