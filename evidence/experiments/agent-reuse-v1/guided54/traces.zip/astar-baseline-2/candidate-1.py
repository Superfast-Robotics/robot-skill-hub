import math
import heapq
from typing import List, Tuple


def solve(task):
    start = tuple(task['start'])
    goal = tuple(task['goal'])
    b0, b1 = task['bounds']
    obstacles = [tuple(p) for p in task['obstacles']]
    rr = float(task['robot_radius'])

    xmin, ymin, xmax, ymax = float(b0), float(b0), float(b1), float(b1)
    eps = 1e-6
    inner_minx, inner_miny = xmin + rr + eps, ymin + rr + eps
    inner_maxx, inner_maxy = xmax - rr - eps, ymax - rr - eps

    def inside(p):
        x, y = p
        return (inner_minx <= x <= inner_maxx) and (inner_miny <= y <= inner_maxy)

    # Boundary sampled at integer coordinates on the rectangle perimeter.
    boundary_pts = []
    lo = int(math.ceil(min(xmin, xmax)))
    hi = int(math.floor(max(xmin, xmax)))
    for x in range(lo, hi + 1):
        boundary_pts.append((float(x), ymin))
        boundary_pts.append((float(x), ymax))
    for y in range(lo, hi + 1):
        boundary_pts.append((xmin, float(y)))
        boundary_pts.append((xmax, float(y)))
    # Remove duplicates
    boundary_pts = list(dict.fromkeys(boundary_pts))

    pts = obstacles + boundary_pts

    def seg_clear(a, b):
        ax, ay = a
        bx, by = b
        # quick reject if endpoints outside strict interior
        if not inside(a) or not inside(b):
            return False
        dx, dy = bx - ax, by - ay
        seg2 = dx * dx + dy * dy
        if seg2 == 0:
            for px, py in pts:
                if (px - ax) ** 2 + (py - ay) ** 2 <= rr * rr:
                    return False
            return True
        # Sample densely by obstacle scale and geometry
        n = max(2, int(math.ceil(math.hypot(dx, dy) / max(0.1, rr / 2))))
        for i in range(n + 1):
            t = i / n
            x = ax + t * dx
            y = ay + t * dy
            if not inside((x, y)):
                return False
            for px, py in pts:
                # point-segment distance
                wx, wy = px - ax, py - ay
                tt = (wx * dx + wy * dy) / seg2
                tt = 0.0 if tt < 0.0 else 1.0 if tt > 1.0 else tt
                cx, cy = ax + tt * dx, ay + tt * dy
                if (px - cx) ** 2 + (py - cy) ** 2 <= rr * rr:
                    return False
        return True

    if seg_clear(start, goal):
        length = math.hypot(goal[0] - start[0], goal[1] - start[1])
        return {'path_xy': [list(start), list(goal)], 'length_m': length}

    # Grid A* in the strict interior.
    res = 0.25
    xs = []
    x = inner_minx
    while x <= inner_maxx + 1e-9:
        xs.append(round(x, 10))
        x += res
    ys = []
    y = inner_miny
    while y <= inner_maxy + 1e-9:
        ys.append(round(y, 10))
        y += res

    def snap(p):
        x, y = p
        sx = min(xs, key=lambda v: abs(v - x))
        sy = min(ys, key=lambda v: abs(v - y))
        return (sx, sy)

    s = snap(start)
    g = snap(goal)

    # Ensure snapped points are free and connected to actual endpoints.
    def point_free(p):
        return inside(p) and all((px - p[0]) ** 2 + (py - p[1]) ** 2 > rr * rr for px, py in pts)

    if not point_free(s):
        s = start
    if not point_free(g):
        g = goal

    motions = [(1,0,res),(-1,0,res),(0,1,res),(0,-1,res),(1,1,res*math.sqrt(2)),(1,-1,res*math.sqrt(2)),(-1,1,res*math.sqrt(2)),(-1,-1,res*math.sqrt(2))]

    def key(p):
        return (round(p[0], 6), round(p[1], 6))

    openh = []
    gscore = {key(s): 0.0}
    parent = {key(s): None}
    heapq.heappush(openh, (math.hypot(g[0]-s[0], g[1]-s[1]), 0.0, s))
    closed = set()
    goal_key = key(g)
    found = None
    while openh:
        f, gc, cur = heapq.heappop(openh)
        kcur = key(cur)
        if kcur in closed:
            continue
        closed.add(kcur)
        if math.hypot(cur[0]-g[0], cur[1]-g[1]) <= res * 0.51 and seg_clear(cur, g):
            parent[goal_key] = kcur
            found = g
            break
        for dx, dy, cost in motions:
            nxt = (round(cur[0]+dx*res, 10), round(cur[1]+dy*res, 10))
            kn = key(nxt)
            if kn in closed or not point_free(nxt):
                continue
            if not seg_clear(cur, nxt):
                continue
            ng = gc + cost
            if ng < gscore.get(kn, float('inf')):
                gscore[kn] = ng
                parent[kn] = kcur
                h = math.hypot(g[0]-nxt[0], g[1]-nxt[1])
                heapq.heappush(openh, (ng + h, ng, nxt))
    if found is None:
        # fallback waypoint routing around obstacles using start/goal y-offsets.
        ys_try = [inner_miny + rr, inner_maxy - rr, (inner_miny + inner_maxy) / 2]
        best = None
        for yy in ys_try:
            w1 = (start[0], yy)
            w2 = (goal[0], yy)
            if inside(w1) and inside(w2) and seg_clear(start, w1) and seg_clear(w1, w2) and seg_clear(w2, goal):
                cand = [start, w1, w2, goal]
                l = sum(math.hypot(cand[i+1][0]-cand[i][0], cand[i+1][1]-cand[i][1]) for i in range(len(cand)-1))
                best = (cand, l)
                break
        if best is None:
            raise RuntimeError('No path found')
        path, length = best
        return {'path_xy': [list(p) for p in path], 'length_m': length}

    # Reconstruct.
    path = [found]
    k = goal_key
    while k is not None:
        # the first appended is goal key if found, then parent chain.
        pk = parent.get(k)
        if pk is None:
            break
        # recover coordinate from key via stored parent chain not needed; use a map of coords from gscore? keep path nodes by scanning parent keys impossible.
        k = pk
        # reverse lookup from key to coordinate is approximate; use grid from key values
        path.append((k[0], k[1]))
    path = path[::-1]
    # Insert actual start/goal and smooth by shortcutting.
    if path[0] != start:
        path = [start] + path
    if path[-1] != goal:
        path = path + [goal]

    def shortcut(poly):
        changed = True
        while changed and len(poly) > 2:
            changed = False
            i = 0
            out = [poly[0]]
            while i < len(poly) - 1:
                j = len(poly) - 1
                while j > i + 1 and not seg_clear(poly[i], poly[j]):
                    j -= 1
                out.append(poly[j])
                i = j
            if len(out) < len(poly):
                changed = True
                poly = out
        return poly

    path = shortcut(path)
    length = sum(math.hypot(path[i+1][0]-path[i][0], path[i+1][1]-path[i][1]) for i in range(len(path)-1))
    return {'path_xy': [list(map(float, p)) for p in path], 'length_m': float(length)}
