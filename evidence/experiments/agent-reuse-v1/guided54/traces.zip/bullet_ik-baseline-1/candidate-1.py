import json, math
import pybullet as p
import pybullet_data
from public import scene


def solve(task):
    joint_angles = task["joint_angles"]
    target = task["target_xyz"]

    cid = p.connect(p.DIRECT)
    try:
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        robot = scene.create_arm(p)
        p.resetBasePositionAndOrientation(robot, [0, 0, 0], [0, 0, 0, 1])
        for i, q in enumerate(joint_angles):
            p.resetJointState(robot, i, q)
        p.performCollisionDetection()

        # Neutral joint limits, allow broad motion
        ll = [-10.0] * 7
        ul = [10.0] * 7
        jr = [20.0] * 7
        rest = list(joint_angles)
        jd = [0.01] * 7
        sol = p.calculateInverseKinematics(
            robot, 6, target,
            lowerLimits=ll, upperLimits=ul, jointRanges=jr, restPoses=rest,
            jointDamping=jd, maxNumIterations=200, residualThreshold=1e-12
        )
        sol = list(sol[:7])
        for i, q in enumerate(sol):
            p.resetJointState(robot, i, q)
        ee = p.getLinkState(robot, 6, computeForwardKinematics=True)[4]
        err = math.sqrt(sum((ee[i] - target[i]) ** 2 for i in range(3)))
        return {"joint_angles_rad": sol, "end_effector_xyz_m": list(ee), "position_error_m": err}
    finally:
        p.disconnect(cid)
