import math
import pybullet as p
from public import scene


def solve(task):
    q = list(task["joint_angles"])
    target = task["target_xyz"]
    cid = p.connect(p.DIRECT)
    try:
        robot = scene.create_arm(p)
        p.resetBasePositionAndOrientation(robot, [0, 0, 0], [0, 0, 0, 1])
        for i, v in enumerate(q):
            p.resetJointState(robot, i, v)

        def fk_and_jac(qvals):
            for i, v in enumerate(qvals):
                p.resetJointState(robot, i, v)
            ls = p.getLinkState(robot, 6, computeForwardKinematics=True)
            ee = ls[4]
            zero = [0.0] * 7
            jlin, jang = p.calculateJacobian(robot, 6, [0, 0, 0], qvals, zero, zero)
            return ee, jlin

        for _ in range(80):
            ee, jlin = fk_and_jac(q)
            err = [target[i] - ee[i] for i in range(3)]
            n = math.sqrt(sum(e*e for e in err))
            if n < 1e-4:
                break
            # damped least squares
            # J: 3x7
            JTJ = [[0.0]*7 for _ in range(7)]
            JTe = [0.0]*7
            for i in range(7):
                for k in range(3):
                    JTe[i] += jlin[k][i] * err[k]
                for j in range(7):
                    s = 0.0
                    for k in range(3):
                        s += jlin[k][i] * jlin[k][j]
                    JTJ[i][j] = s
                JTJ[i][i] += 1e-4
            # solve linear system
            import numpy as np
            dq = np.linalg.solve(np.array(JTJ), np.array(JTe))
            maxstep = max(abs(x) for x in dq)
            if maxstep > 0.2:
                dq = dq * (0.2 / maxstep)
            q = [q[i] + float(dq[i]) for i in range(7)]
        for i, v in enumerate(q):
            p.resetJointState(robot, i, v)
        ee = p.getLinkState(robot, 6, computeForwardKinematics=True)[4]
        err = math.sqrt(sum((ee[i]-target[i])**2 for i in range(3)))
        return {"joint_angles_rad": q, "end_effector_xyz_m": list(ee), "position_error_m": err}
    finally:
        p.disconnect(cid)
