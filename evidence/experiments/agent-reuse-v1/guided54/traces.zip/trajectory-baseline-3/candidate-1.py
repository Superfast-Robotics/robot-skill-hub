from ruckig import InputParameter, Ruckig, Trajectory, Result
import math


def solve(task):
    n = len(task["current_position"])
    inp = InputParameter(n)
    inp.current_position = list(task["current_position"])
    inp.current_velocity = list(task["current_velocity"])
    inp.current_acceleration = list(task["current_acceleration"])
    inp.target_position = list(task["target_position"])
    inp.target_velocity = list(task["target_velocity"])
    inp.target_acceleration = list(task["target_acceleration"])
    inp.max_velocity = list(task["max_velocity"])
    inp.max_acceleration = list(task["max_acceleration"])
    inp.max_jerk = list(task["max_jerk"])
    inp.min_velocity = [-abs(v) for v in task["max_velocity"]]
    inp.min_acceleration = [-abs(a) for a in task["max_acceleration"]]

    otg = Ruckig(n)
    traj = Trajectory(n)
    res = otg.calculate(inp, traj)
    if res == Result.ErrorInvalidInput:
        raise ValueError("Invalid input")
    duration = float(traj.duration)
    dt = float(task["dt"])

    # Determine sampling. Prefer spacing <= dt and exact endpoint.
    if duration == 0.0:
        times = [0.0, 0.0]
    else:
        intervals = max(1, math.ceil(duration / dt))
        samples = intervals + 1
        if samples > 3000:
            # Best effort under hard cap; keep exact endpoint and start.
            samples = 3000
            intervals = samples - 1
        times = [duration * i / intervals for i in range(intervals)] + [duration]
        # Ensure first sample exactly zero.
        times[0] = 0.0
        # If due to rounding the sequence has a non-increasing last interval, fix by clipping.
        for i in range(1, len(times)):
            if times[i] < times[i-1]:
                times[i] = times[i-1]

    pos = []
    vel = []
    acc = []
    for t in times:
        p, v, a = traj.at_time(t)
        pos.append([float(x) for x in p])
        vel.append([float(x) for x in v])
        acc.append([float(x) for x in a])

    return {
        "time_s": [float(t) for t in times],
        "position": pos,
        "velocity": vel,
        "acceleration": acc,
        "coordinate_type": task["coordinate_type"],
        "duration_s": duration,
    }


if __name__ == '__main__':
    task = {"current_position": [0.0, 0.0, 0.0], "current_velocity": [0.0, 0.0, 0.0], "current_acceleration": [0.0, 0.0, 0.0], "target_position": [0.8, -0.6, 0.35], "target_velocity": [0.0, 0.0, 0.0], "target_acceleration": [0.0, 0.0, 0.0], "max_velocity": [1.0, 1.0, 1.0], "max_acceleration": [2.0, 2.0, 2.0], "max_jerk": [4.0, 4.0, 4.0], "dt": 0.02, "coordinate_type": "revolute_rad"}
    out = solve(task)
    print(out['duration_s'], len(out['time_s']))
