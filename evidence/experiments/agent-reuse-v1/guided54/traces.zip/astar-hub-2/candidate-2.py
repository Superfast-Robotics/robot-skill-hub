import math
import heapq
import numpy as np


def solve(task):
    start = tuple(map(float, task["start"]))
    goal = tuple(map(float, task["goal"]))
    b0, b1 = task["bounds"]
    obstacles = [tuple(map(float, p)) for p in task["obstacles"]]
    r = float(task["robot_radius"])

    xmin, ymin = float(b0), float(b0)
    xmax, ymax = float(b1), float(b1)
    lo_x, hi_x = xmin + r, xmax - r
    lo_y, hi_y = ymin + r, ymax - r

    blocked = []
    for x in range(int(math.ceil(xmin)), int(math.floor(xmax)) + 1):
        blocked.append((float(x), ymin))
        blocked.append((float(x), ymax))
    for y in range(int(math.ceil(ymin)) + 1, int(math.floor(ymax))):
        blocked.append((xmin, float(y)))
        blocked.append((xmax, float(y)))
    blocked.extend(obstacles)

    res = max(0.25, min(0.5, r / 2.0))
    motions = [
        (1, 0, res), (-1, 0, res), (0, 1, res), (0, -1, res),
        (1, 1, math.sqrt(2) * res), (1, -1, math.sqrt(2) * res),
        (-1, 1, math.sqrt(2) * res), (-1, -1, math.sqrt(2) * res),
    ]

    nx = int(round((hi_x - lo_x) / res)) + 1
    ny = int(round((hi_y - lo_y) / res)) + 1

    def to_idx(p):
        return (int(round((p[0] - lo_x) / res)), int(round((p[1] - lo_y) / res)))

    def to_xy(ix, iy):
        return (lo_x + ix * res, lo_y + iy * res)

    def in_bounds_xy(x, y):
        return lo_x <= x <= hi_x and lo_y <= y <= hi_y

    def safe_point(x, y):
        if not in_bounds_xy(x, y):
            return False
        for ox, oy in blocked:
            if math.hypot(x - ox, y - oy) <= r - 1e-12:
                return False
        return True

    def safe_segment(a, b):
        ax, ay = a; bx, by = b
        dist = math.hypot(bx - ax, by - ay)
        steps = max(2, int(math.ceil(dist / (res / 3.0))))
        for i in range(steps + 1):
            t = i / steps
            x = ax + (bx - ax) * t
            y = ay + (by - ay) * t
            if not safe_point(x, y):
                return False
        return True

    if not safe_point(*start) or not safe_point(*goal):
        raise ValueError("start or goal collides")

    s = to_idx(start)
    g = to_idx(goal)

    open_heap = []
    gscore = {s: 0.0}
    parent = {s: None}
    heapq.heappush(open_heap, (math.hypot(goal[0] - start[0], goal[1] - start[1]), 0.0, s))
    closed = set()

    while open_heap:
        f, gc, cur = heapq.heappop(open_heap)
        if cur in closed:
            continue
        closed.add(cur)
        if cur == g:
            break
        cx, cy = to_xy(*cur)
        for dx, dy, cost in motions:
            nxt = (cur[0] + dx, cur[1] + dy)
            if not (0 <= nxt[0] < nx and 0 <= nxt[1] < ny):
                continue
            nxp, nyp = to_xy(*nxt)
            if not safe_segment((cx, cy), (nxp, nyp)):
                continue
            ng = gc + cost
            if ng + 1e-12 < gscore.get(nxt, float('inf')):
                gscore[nxt] = ng
                parent[nxt] = cur
                h = math.hypot(goal[0] - nxp, goal[1] - nyp)
                heapq.heappush(open_heap, (ng + h, ng, nxt))
    if g not in parent:
        # fallback via a horizontal or vertical dogleg around the wall/obstacles
        candidates = []
        for via_y in [lo_y, hi_y, (lo_y + hi_y) / 2.0, start[1], goal[1]]:
            p1, p2 = (start[0], via_y), (goal[0], via_y)
            if safe_segment(start, p1) and safe_segment(p1, p2) and safe_segment(p2, goal):
                candidates.append([start, p1, p2, goal])
        if not candidates:
            raise ValueError("no path found")
        path = min(candidates, key=lambda p: sum(math.hypot(p[i+1][0]-p[i][0], p[i+1][1]-p[i][1]) for i in range(len(p)-1)))
    else:
        rev = []
        cur = g
        while cur is not None:
            rev.append(to_xy(*cur))
            cur = parent[cur]
        path = list(reversed(rev))
        # replace endpoints with exact inputs if directly connectable
        if safe_segment(start, path[0]):
            path[0] = start
        else:
            path = [start] + path
        if safe_segment(path[-1], goal):
            path[-1] = goal
        else:
            path = path + [goal]

    # ensure exact start/goal and compress collinear interior points
    if path[0] != start:
        path = [start] + path
    if path[-1] != goal:
        path = path + [goal]

    comp = [path[0]]
    for p in path[1:]:
        comp.append(p)
        while len(comp) >= 3:
            a, b, c = comp[-3], comp[-2], comp[-1]
            cross = (b[0]-a[0])*(c[1]-b[1]) - (b[1]-a[1])*(c[0]-b[0])
            if abs(cross) < 1e-9 and safe_segment(a, c):
                comp.pop(-2)
            else:
                break
    length = sum(math.hypot(comp[i+1][0]-comp[i][0], comp[i+1][1]-comp[i][1]) for i in range(len(comp)-1))
    return {"path_xy": [[float(x), float(y)] for x, y in comp], "length_m": float(length)}
