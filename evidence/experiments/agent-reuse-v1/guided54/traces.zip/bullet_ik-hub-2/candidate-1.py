import json, math
import pybullet as p
import pybullet_data
from public.scene import create_arm


def _fk(angles):
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        robot = create_arm(p)
        for j, a in enumerate(angles):
            p.resetJointState(robot, j, a)
        ls = p.getLinkState(robot, 6, computeForwardKinematics=True)
        return list(ls[4])
    finally:
        p.disconnect()


def solve(task):
    target = task['target_xyz']
    seed = list(task['joint_angles'])
    cid = p.connect(p.DIRECT)
    try:
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        robot = create_arm(p)
        for j, a in enumerate(seed):
            p.resetJointState(robot, j, a)
        lower = [-3.141592653589793] * 7
        upper = [3.141592653589793] * 7
        ranges = [6.283185307179586] * 7
        rest = seed
        sol = p.calculateInverseKinematics(robot, 6, target, lowerLimits=lower, upperLimits=upper, jointRanges=ranges, restPoses=rest, maxNumIterations=200, residualThreshold=1e-12)
        sol = list(sol[:7])
        for j, a in enumerate(sol):
            p.resetJointState(robot, j, a)
        ee = p.getLinkState(robot, 6, computeForwardKinematics=True)[4]
        err = math.dist(ee, target)
        # one refinement from solution seed if needed
        if err > 2e-3:
            sol2 = p.calculateInverseKinematics(robot, 6, target, lowerLimits=lower, upperLimits=upper, jointRanges=ranges, restPoses=sol, maxNumIterations=400, residualThreshold=1e-14)
            sol = list(sol2[:7])
            for j, a in enumerate(sol):
                p.resetJointState(robot, j, a)
            ee = p.getLinkState(robot, 6, computeForwardKinematics=True)[4]
            err = math.dist(ee, target)
        return {"joint_angles_rad": [float(x) for x in sol], "end_effector_xyz_m": [float(x) for x in ee], "position_error_m": float(err)}
    finally:
        p.disconnect()
