from ruckig import InputParameter, Ruckig, Trajectory, Result
import math


def solve(task):
    n = len(task['current_position'])
    inp = InputParameter(n)
    inp.current_position = [float(x) for x in task['current_position']]
    inp.current_velocity = [float(x) for x in task['current_velocity']]
    inp.current_acceleration = [float(x) for x in task['current_acceleration']]
    inp.target_position = [float(x) for x in task['target_position']]
    inp.target_velocity = [float(x) for x in task['target_velocity']]
    inp.target_acceleration = [float(x) for x in task['target_acceleration']]
    inp.max_velocity = [float(x) for x in task['max_velocity']]
    inp.max_acceleration = [float(x) for x in task['max_acceleration']]
    inp.max_jerk = [float(x) for x in task['max_jerk']]
    r = Ruckig(n)
    traj = Trajectory(n)
    res = r.calculate(inp, traj)
    if res == Result.ErrorInvalidInput:
        raise ValueError('Invalid input')
    duration = float(traj.duration)
    dt = float(task['dt'])
    times = []
    t = 0.0
    # avoid accumulation error by using integer steps
    k = 0
    while t < duration - 1e-15:
        times.append(float(t))
        k += 1
        t = k * dt
        if len(times) > 2998:
            break
    if not times or abs(times[-1] - duration) > 1e-12:
        if duration > 0:
            times.append(duration)
    # ensure exact t=0 and exact completion time
    if times[0] != 0.0:
        times = [0.0] + times
    if abs(times[-1] - duration) > 1e-12:
        times.append(duration)
    pos, vel, acc = [], [], []
    for tt in times:
        p, v, a = traj.at_time(tt)
        pos.append([float(x) for x in p])
        vel.append([float(x) for x in v])
        acc.append([float(x) for x in a])
    return {
        'time_s': times,
        'position': pos,
        'velocity': vel,
        'acceleration': acc,
        'coordinate_type': task['coordinate_type'],
        'duration_s': duration,
    }


# quick test on dev input
inp = {"current_position": [0.0, 0.0, 0.0], "current_velocity": [0.0, 0.0, 0.0], "current_acceleration": [0.0, 0.0, 0.0], "target_position": [0.8, -0.6, 0.35], "target_velocity": [0.0, 0.0, 0.0], "target_acceleration": [0.0, 0.0, 0.0], "max_velocity": [1.0, 1.0, 1.0], "max_acceleration": [2.0, 2.0, 2.0], "max_jerk": [4.0, 4.0, 4.0], "dt": 0.02, "coordinate_type": "revolute_rad"}
out = solve(inp)
print(len(out['time_s']), out['time_s'][:3], out['time_s'][-3:])
print(out['duration_s'])
print(out['position'][-1])
