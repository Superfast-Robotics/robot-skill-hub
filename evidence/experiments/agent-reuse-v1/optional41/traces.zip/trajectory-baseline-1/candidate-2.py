import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup Ruckig
    ruckig = Ruckig(dof)
    trajectory = Trajectory(dof)

    # Setup input
    input_param = InputParameter(dof)
    input_param.current_position = current_position
    input_param.current_velocity = current_velocity
    input_param.current_acceleration = current_acceleration
    input_param.target_position = target_position
    input_param.target_velocity = target_velocity
    input_param.target_acceleration = target_acceleration
    input_param.max_velocity = max_velocity
    input_param.max_acceleration = max_acceleration
    input_param.max_jerk = max_jerk

    # Calculate the trajectory in an offline manner
    result = ruckig.calculate(input_param, trajectory)
    if result != Result.Working:
        raise RuntimeError(f"Ruckig calculation failed with result code {result}")

    duration_s = trajectory.duration
    if duration_s > 30.0:
        duration_s = 30.0

    max_samples = 3000
    n_samples = int(np.ceil(duration_s / dt)) + 1
    if n_samples > max_samples:
        n_samples = max_samples
        dt = duration_s / (n_samples - 1)

    time_s = []
    position = []
    velocity = []
    acceleration = []

    for i in range(n_samples):
        t = min(i * dt, duration_s)
        pos, vel, acc = trajectory.at_time(t)
        time_s.append(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    # Ensure last sample is exactly at duration_s
    if time_s[-1] < duration_s:
        pos, vel, acc = trajectory.at_time(duration_s)
        time_s.append(duration_s)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    # Convert to numpy arrays for numerical checks
    time_s = np.array(time_s)
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Check endpoints within 1e-6
    assert np.allclose(position[0], current_position, atol=1e-6)
    assert np.allclose(velocity[0], current_velocity, atol=1e-6)
    assert np.allclose(acceleration[0], current_acceleration, atol=1e-6)
    assert np.allclose(position[-1], target_position, atol=1e-6)
    assert np.allclose(velocity[-1], target_velocity, atol=1e-6)
    assert np.allclose(acceleration[-1], target_acceleration, atol=1e-6)

    # Check velocity, acceleration, jerk bounds
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]
    max_jerk_sampled = np.max(np.abs(jerk), axis=0)
    assert np.all(max_jerk_sampled <= np.array(max_jerk) + 1e-6)
    max_velocity_sampled = np.max(np.abs(velocity), axis=0)
    assert np.all(max_velocity_sampled <= np.array(max_velocity) + 1e-6)
    max_acceleration_sampled = np.max(np.abs(acceleration), axis=0)
    assert np.all(max_acceleration_sampled <= np.array(max_acceleration) + 1e-6)

    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": float(duration_s),
    }
