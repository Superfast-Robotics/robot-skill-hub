import math
import numpy as np
from sources.pythonrobotics.PathPlanning.AStar.a_star import AStarPlanner

def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    # We will create a grid map for A* planning.
    # The bounds are given as [min, max] for both x and y (square).
    # We need to include the boundary points as obstacles sampled at integer coordinates.
    # Also, obstacles are points that must be cleared by robot_radius.
    # We will create a list of obstacle points including:
    # - The given obstacles
    # - The integer sampled boundary points (all points on the boundary lines)
    
    min_bound = bounds[0]
    max_bound = bounds[1]
    
    # Create boundary obstacle points sampled at integer coordinates
    boundary_points = []
    for x in range(min_bound, max_bound + 1):
        boundary_points.append([x, min_bound])
        boundary_points.append([x, max_bound])
    for y in range(min_bound + 1, max_bound):
        boundary_points.append([min_bound, y])
        boundary_points.append([max_bound, y])
    
    # Combine given obstacles and boundary points
    all_obstacles = obstacles + boundary_points
    
    # Extract ox, oy for AStarPlanner
    ox = [p[0] for p in all_obstacles]
    oy = [p[1] for p in all_obstacles]
    
    # We choose a grid resolution smaller than 1 to allow finer path planning
    # but not too small to keep performance reasonable.
    resolution = 0.2
    
    # Initialize AStarPlanner with obstacles, resolution, and robot radius
    planner = AStarPlanner(ox, oy, resolution, robot_radius)
    
    # Plan path from start to goal
    rx, ry = planner.planning(start[0], start[1], goal[0], goal[1])
    
    # The planner returns path in reverse order (goal to start), reverse it
    path_xy = list(zip(rx, ry))
    path_xy.reverse()
    
    # Compute path length
    length_m = 0.0
    for i in range(1, len(path_xy)):
        length_m += math.dist(path_xy[i-1], path_xy[i])
    
    # Return result
    return {
        "path_xy": path_xy,
        "length_m": length_m
    }