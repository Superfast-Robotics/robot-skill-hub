import math
from typing import List

class AStarPlanner:
    def __init__(self, ox: List[float], oy: List[float], resolution: float, rr: float):
        self.resolution = resolution
        self.rr = rr
        self.min_x, self.min_y = 0, 0
        self.max_x, self.max_y = 0, 0
        self.obstacle_map = None
        self.x_width, self.y_width = 0, 0
        self.motion = self.get_motion_model()
        self.calc_obstacle_map(ox, oy)

    class Node:
        def __init__(self, x, y, cost, parent_index):
            self.x = x
            self.y = y
            self.cost = cost
            self.parent_index = parent_index

    def planning(self, sx, sy, gx, gy):
        start_node = self.Node(self.calc_xy_index(sx, self.min_x),
                               self.calc_xy_index(sy, self.min_y), 0.0, -1)
        goal_node = self.Node(self.calc_xy_index(gx, self.min_x),
                              self.calc_xy_index(gy, self.min_y), 0.0, -1)

        open_set, closed_set = dict(), dict()
        open_set[self.calc_grid_index(start_node)] = start_node

        while True:
            if len(open_set) == 0:
                break

            c_id = min(
                open_set,
                key=lambda o: open_set[o].cost + self.calc_heuristic(goal_node, open_set[o]))
            current = open_set[c_id]

            if current.x == goal_node.x and current.y == goal_node.y:
                goal_node.parent_index = current.parent_index
                goal_node.cost = current.cost
                break

            del open_set[c_id]
            closed_set[c_id] = current

            for i, _ in enumerate(self.motion):
                node = self.Node(current.x + self.motion[i][0],
                                 current.y + self.motion[i][1],
                                 current.cost + self.motion[i][2], c_id)
                n_id = self.calc_grid_index(node)

                if not self.verify_node(node):
                    continue

                if n_id in closed_set:
                    continue

                if n_id not in open_set:
                    open_set[n_id] = node
                else:
                    if open_set[n_id].cost > node.cost:
                        open_set[n_id] = node

        rx, ry = self.calc_final_path(goal_node, closed_set)
        return rx[::-1], ry[::-1]

    def calc_final_path(self, goal_node, closed_set):
        rx, ry = [self.calc_grid_position(goal_node.x, self.min_x)], [self.calc_grid_position(goal_node.y, self.min_y)]
        parent_index = goal_node.parent_index
        while parent_index != -1:
            n = closed_set[parent_index]
            rx.append(self.calc_grid_position(n.x, self.min_x))
            ry.append(self.calc_grid_position(n.y, self.min_y))
            parent_index = n.parent_index
        return rx, ry

    @staticmethod
    def calc_heuristic(n1, n2):
        w = 1.0
        d = w * math.hypot(n1.x - n2.x, n1.y - n2.y)
        return d

    def calc_grid_position(self, index, min_position):
        return index * self.resolution + min_position

    def calc_xy_index(self, position, min_pos):
        return round((position - min_pos) / self.resolution)

    def calc_grid_index(self, node):
        return (node.y - self.min_y) * self.x_width + (node.x - self.min_x)

    def verify_node(self, node):
        px = self.calc_grid_position(node.x, self.min_x)
        py = self.calc_grid_position(node.y, self.min_y)

        if px < self.min_x or py < self.min_y or px >= self.max_x or py >= self.max_y:
            return False

        if self.obstacle_map[node.x][node.y]:
            return False

        return True

    def calc_obstacle_map(self, ox, oy):
        # Expand map bounds to include robot radius clearance
        min_x = min(ox)
        max_x = max(ox)
        min_y = min(oy)
        max_y = max(oy)

        self.min_x = math.floor(min_x - self.rr)
        self.min_y = math.floor(min_y - self.rr)
        self.max_x = math.ceil(max_x + self.rr)
        self.max_y = math.ceil(max_y + self.rr)

        self.x_width = round((self.max_x - self.min_x) / self.resolution) + 1
        self.y_width = round((self.max_y - self.min_y) / self.resolution) + 1

        self.obstacle_map = [[False for _ in range(self.y_width)] for _ in range(self.x_width)]

        for ix in range(self.x_width):
            x = self.calc_grid_position(ix, self.min_x)
            for iy in range(self.y_width):
                y = self.calc_grid_position(iy, self.min_y)
                for iox, ioy in zip(ox, oy):
                    d = math.hypot(iox - x, ioy - y)
                    if d <= self.rr:
                        self.obstacle_map[ix][iy] = True
                        break

    @staticmethod
    def get_motion_model():
        motion = [[1, 0, 1],
                  [0, 1, 1],
                  [-1, 0, 1],
                  [0, -1, 1],
                  [-1, -1, math.sqrt(2)],
                  [-1, 1, math.sqrt(2)],
                  [1, -1, math.sqrt(2)],
                  [1, 1, math.sqrt(2)]]
        return motion


def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    # Inflate bounds by robot_radius to keep robot inside
    min_bound = bounds[0] + robot_radius
    max_bound = bounds[1] - robot_radius

    # Create boundary points sampled at integer coordinates
    boundary_points = []
    for x in range(bounds[0], bounds[1] + 1):
        boundary_points.append([x, bounds[0]])
        boundary_points.append([x, bounds[1]])
    for y in range(bounds[0] + 1, bounds[1]):
        boundary_points.append([bounds[0], y])
        boundary_points.append([bounds[1], y])

    # Combine obstacles and boundary points
    all_obstacles = obstacles + boundary_points

    # Separate x and y for AStarPlanner
    ox = [p[0] for p in all_obstacles]
    oy = [p[1] for p in all_obstacles]

    # Add start and goal to ox, oy to ensure map covers them
    ox.append(start[0])
    oy.append(start[1])
    ox.append(goal[0])
    oy.append(goal[1])

    # Use a grid resolution smaller than robot_radius for better clearance
    resolution = 0.5

    planner = AStarPlanner(ox, oy, resolution, robot_radius)

    # Clamp start and goal inside inflated bounds
    sx = min(max(start[0], min_bound), max_bound)
    sy = min(max(start[1], min_bound), max_bound)
    gx = min(max(goal[0], min_bound), max_bound)
    gy = min(max(goal[1], min_bound), max_bound)

    rx, ry = planner.planning(sx, sy, gx, gy)

    # If no path found, fallback to direct line
    if len(rx) == 0 or len(ry) == 0:
        path_xy = [start, goal]
        length_m = math.hypot(goal[0] - start[0], goal[1] - start[1])
        return {"path_xy": path_xy, "length_m": length_m}

    path_xy = [[x, y] for x, y in zip(rx, ry)]

    length_m = 0.0
    for i in range(1, len(path_xy)):
        length_m += math.hypot(path_xy[i][0] - path_xy[i-1][0], path_xy[i][1] - path_xy[i-1][1])

    return {"path_xy": path_xy, "length_m": length_m}
