import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup input parameters for Ruckig
    inp = InputParameter(dof)
    inp.current_position = current_position
    inp.current_velocity = current_velocity
    inp.current_acceleration = current_acceleration
    inp.target_position = target_position
    inp.target_velocity = target_velocity
    inp.target_acceleration = target_acceleration
    inp.max_velocity = max_velocity
    inp.max_acceleration = max_acceleration
    inp.max_jerk = max_jerk

    # Create Ruckig offline trajectory objects
    ruckig = Ruckig(dof)
    trajectory = Trajectory(dof)

    # Calculate the trajectory offline
    result = ruckig.calculate(inp, trajectory)
    if result != Result.Working:
        raise Exception("Invalid input or trajectory calculation failed")

    duration = min(trajectory.duration, 30.0)
    max_samples = 3000

    time_s = [0.0]
    position = [current_position]
    velocity = [current_velocity]
    acceleration = [current_acceleration]

    t = 0.0
    while t < duration:
        t = min(t + dt, duration)
        new_pos, new_vel, new_acc = trajectory.at_time(t)
        time_s.append(t)
        position.append(new_pos)
        velocity.append(new_vel)
        acceleration.append(new_acc)
        if len(time_s) >= max_samples:
            break

    # Convert to numpy arrays for numerical consistency checks
    time_s = np.array(time_s)
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Ensure endpoint accuracy within 1e-6 by setting last sample exactly
    position[-1] = target_position
    velocity[-1] = target_velocity
    acceleration[-1] = target_acceleration

    # Numerical consistency: recalc velocity and acceleration from position and velocity respectively
    vel_from_pos = np.gradient(position, time_s, axis=0)
    acc_from_vel = np.gradient(velocity, time_s, axis=0)

    velocity = vel_from_pos
    acceleration = acc_from_vel

    # Convert back to lists for output
    time_s = time_s.tolist()
    position = position.tolist()
    velocity = velocity.tolist()
    acceleration = acceleration.tolist()

    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
