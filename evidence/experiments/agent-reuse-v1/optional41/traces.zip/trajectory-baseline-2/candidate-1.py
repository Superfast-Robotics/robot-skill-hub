import numpy as np
from ruckig import InputParameter, OfflineTrajectory, Result

def solve(task):
    # Extract input parameters
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup Ruckig input
    input_param = InputParameter(dof)
    input_param.current_position = current_position
    input_param.current_velocity = current_velocity
    input_param.current_acceleration = current_acceleration
    input_param.target_position = target_position
    input_param.target_velocity = target_velocity
    input_param.target_acceleration = target_acceleration
    input_param.max_velocity = max_velocity
    input_param.max_acceleration = max_acceleration
    input_param.max_jerk = max_jerk

    # Create offline trajectory
    trajectory = OfflineTrajectory(input_param)

    # Sample trajectory
    time_s = [0.0]
    position = [current_position]
    velocity = [current_velocity]
    acceleration = [current_acceleration]

    t = 0.0
    duration = trajectory.duration
    max_samples = 3000
    max_duration = 30.0

    # Clamp duration to max_duration
    if duration > max_duration:
        duration = max_duration

    while t < duration:
        t = min(t + dt, duration)
        new_pos, new_vel, new_acc = trajectory.at_time(t)
        time_s.append(t)
        position.append(new_pos)
        velocity.append(new_vel)
        acceleration.append(new_acc)

        if len(time_s) >= max_samples:
            break

    # Convert lists to numpy arrays for numerical consistency checks
    time_s = np.array(time_s)
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Ensure endpoint accuracy within 1e-6
    # Fix last sample to exact target
    position[-1] = target_position
    velocity[-1] = target_velocity
    acceleration[-1] = target_acceleration

    # Check numerical consistency of derivatives
    # velocity from position
    vel_from_pos = np.gradient(position, time_s, axis=0)
    # acceleration from velocity
    acc_from_vel = np.gradient(velocity, time_s, axis=0)

    # Replace velocity and acceleration with numerically consistent values
    velocity = vel_from_pos
    acceleration = acc_from_vel

    # Convert back to lists
    time_s = time_s.tolist()
    position = position.tolist()
    velocity = velocity.tolist()
    acceleration = acceleration.tolist()

    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
