import numpy as np
import ruckig

def solve(task):
    # Extract inputs
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup Ruckig input and output
    input = ruckig.Input(dof)
    input.current_position = current_position
    input.current_velocity = current_velocity
    input.current_acceleration = current_acceleration
    input.target_position = target_position
    input.target_velocity = target_velocity
    input.target_acceleration = target_acceleration
    input.max_velocity = max_velocity
    input.max_acceleration = max_acceleration
    input.max_jerk = max_jerk

    # Create Ruckig offline trajectory
    otg = ruckig.OfflineTrajectory(dof)
    result = otg.calculate(input)
    if result != ruckig.Result.Working:
        raise RuntimeError("Ruckig failed to calculate trajectory")

    duration_s = otg.duration
    # Limit duration to max 30 seconds
    if duration_s > 30:
        duration_s = 30

    # Generate time samples with spacing <= dt including 0 and exact duration
    num_samples = int(np.ceil(duration_s / dt)) + 1
    time_s = np.linspace(0, duration_s, num_samples)

    # Prepare arrays for position, velocity, acceleration
    position = []
    velocity = []
    acceleration = []

    # Sample trajectory at each time
    for t in time_s:
        pos, vel, acc = otg.at_time(t)
        position.append(pos.tolist())
        velocity.append(vel.tolist())
        acceleration.append(acc.tolist())

    # Convert to numpy arrays for numerical consistency checks
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Check endpoint accuracy
    assert np.allclose(position[0], current_position, atol=1e-6)
    assert np.allclose(velocity[0], current_velocity, atol=1e-6)
    assert np.allclose(acceleration[0], current_acceleration, atol=1e-6)
    assert np.allclose(position[-1], target_position, atol=1e-6)
    assert np.allclose(velocity[-1], target_velocity, atol=1e-6)
    assert np.allclose(acceleration[-1], target_acceleration, atol=1e-6)

    # Check velocity, acceleration, jerk bounds
    max_velocity = np.array(max_velocity)
    max_acceleration = np.array(max_acceleration)
    max_jerk = np.array(max_jerk)

    # Velocity and acceleration bounds
    assert np.all(np.abs(velocity) <= max_velocity[:, None] + 1e-6)
    assert np.all(np.abs(acceleration) <= max_acceleration[:, None] + 1e-6)

    # Check jerk numerically
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]
    assert np.all(np.abs(jerk) <= max_jerk[:, None] + 1e-4)  # slightly relaxed tolerance for numerical diff

    # Limit samples to max 3000
    if len(time_s) > 3000:
        # Resample to 3000 points max
        time_s = np.linspace(0, duration_s, 3000)
        position = []
        velocity = []
        acceleration = []
        for t in time_s:
            pos, vel, acc = otg.at_time(t)
            position.append(pos.tolist())
            velocity.append(vel.tolist())
            acceleration.append(acc.tolist())

    return {
        "time_s": time_s.tolist(),
        "position": position if isinstance(position, list) else position.tolist(),
        "velocity": velocity if isinstance(velocity, list) else velocity.tolist(),
        "acceleration": acceleration if isinstance(acceleration, list) else acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration_s
    }
