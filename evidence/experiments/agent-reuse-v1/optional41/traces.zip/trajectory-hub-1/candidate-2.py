import numpy as np
import ruckig

def solve(task):
    dof = len(task["current_position"])

    # Create Ruckig offline trajectory
    otg = ruckig.OfflineTrajectory(dof)

    # Setup input
    input = ruckig.InputParameter(dof)
    input.current_position = task["current_position"]
    input.current_velocity = task["current_velocity"]
    input.current_acceleration = task["current_acceleration"]
    input.target_position = task["target_position"]
    input.target_velocity = task["target_velocity"]
    input.target_acceleration = task["target_acceleration"]
    input.max_velocity = task["max_velocity"]
    input.max_acceleration = task["max_acceleration"]
    input.max_jerk = task["max_jerk"]

    result = otg.calculate(input)
    if result != ruckig.Result.Working:
        raise RuntimeError("Ruckig failed to calculate trajectory")

    duration_s = otg.duration
    if duration_s > 30:
        duration_s = 30

    dt = task["dt"]
    # Generate time samples with spacing <= dt including 0 and exact duration
    num_samples = int(np.ceil(duration_s / dt)) + 1
    time_s = np.linspace(0, duration_s, num_samples)

    position = []
    velocity = []
    acceleration = []

    for t in time_s:
        pos, vel, acc = otg.at_time(t)
        position.append(pos.tolist())
        velocity.append(vel.tolist())
        acceleration.append(acc.tolist())

    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Check endpoint accuracy
    assert np.allclose(position[0], task["current_position"], atol=1e-6)
    assert np.allclose(velocity[0], task["current_velocity"], atol=1e-6)
    assert np.allclose(acceleration[0], task["current_acceleration"], atol=1e-6)
    assert np.allclose(position[-1], task["target_position"], atol=1e-6)
    assert np.allclose(velocity[-1], task["target_velocity"], atol=1e-6)
    assert np.allclose(acceleration[-1], task["target_acceleration"], atol=1e-6)

    max_velocity = np.array(task["max_velocity"])
    max_acceleration = np.array(task["max_acceleration"])
    max_jerk = np.array(task["max_jerk"])

    # Check velocity and acceleration bounds
    assert np.all(np.abs(velocity.T) <= max_velocity[:, None] + 1e-6)
    assert np.all(np.abs(acceleration.T) <= max_acceleration[:, None] + 1e-6)

    # Check jerk numerically
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]
    assert np.all(np.abs(jerk.T) <= max_jerk[:, None] + 1e-4)

    # Limit samples to max 3000
    if len(time_s) > 3000:
        time_s = np.linspace(0, duration_s, 3000)
        position = []
        velocity = []
        acceleration = []
        for t in time_s:
            pos, vel, acc = otg.at_time(t)
            position.append(pos.tolist())
            velocity.append(vel.tolist())
            acceleration.append(acc.tolist())

    return {
        "time_s": time_s.tolist(),
        "position": position if isinstance(position, list) else position.tolist(),
        "velocity": velocity if isinstance(velocity, list) else velocity.tolist(),
        "acceleration": acceleration if isinstance(acceleration, list) else acceleration.tolist(),
        "coordinate_type": task["coordinate_type"],
        "duration_s": duration_s
    }
