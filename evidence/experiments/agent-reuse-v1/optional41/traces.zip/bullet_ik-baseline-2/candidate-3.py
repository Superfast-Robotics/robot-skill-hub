import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    initial_joint_angles = task["joint_angles"]
    target_xyz = task["target_xyz"]

    physics_client = p.connect(p.DIRECT)
    robot = create_arm(p)

    # Initialize joints to the given initial angles
    for i in range(7):
        p.resetJointState(robot, i, initial_joint_angles[i])

    # Use PyBullet IK with maxNumIterations and residual threshold to improve accuracy
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz, maxNumIterations=1000, residualThreshold=1e-6)

    # Apply IK solution
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get end effector position
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]

    # Compute position error
    position_error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": position_error
    }
