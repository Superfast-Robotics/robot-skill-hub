import math

class AStarPlanner:

    def __init__(self, ox, oy, resolution, rr, bounds):
        self.resolution = resolution
        self.rr = rr
        self.min_x, self.min_y = bounds[0] + rr, bounds[0] + rr
        self.max_x, self.max_y = bounds[1] - rr, bounds[1] - rr
        self.x_width = round((self.max_x - self.min_x) / self.resolution) + 1
        self.y_width = round((self.max_y - self.min_y) / self.resolution) + 1
        self.motion = self.get_motion_model()
        self.calc_obstacle_map(ox, oy)

    class Node:
        def __init__(self, x, y, cost, parent_index):
            self.x = x
            self.y = y
            self.cost = cost
            self.parent_index = parent_index

    def planning(self, sx, sy, gx, gy):
        start_node = self.Node(self.calc_xy_index(sx, self.min_x),
                               self.calc_xy_index(sy, self.min_y), 0.0, -1)
        goal_node = self.Node(self.calc_xy_index(gx, self.min_x),
                              self.calc_xy_index(gy, self.min_y), 0.0, -1)

        open_set, closed_set = dict(), dict()
        open_set[self.calc_grid_index(start_node)] = start_node

        while True:
            if len(open_set) == 0:
                break

            c_id = min(open_set, key=lambda o: open_set[o].cost + self.calc_heuristic(goal_node, open_set[o]))
            current = open_set[c_id]

            if current.x == goal_node.x and current.y == goal_node.y:
                goal_node.parent_index = current.parent_index
                goal_node.cost = current.cost
                break

            del open_set[c_id]
            closed_set[c_id] = current

            for i, _ in enumerate(self.motion):
                node = self.Node(current.x + self.motion[i][0],
                                 current.y + self.motion[i][1],
                                 current.cost + self.motion[i][2], c_id)
                n_id = self.calc_grid_index(node)

                if not self.verify_node(node):
                    continue

                if n_id in closed_set:
                    continue

                if n_id not in open_set:
                    open_set[n_id] = node
                else:
                    if open_set[n_id].cost > node.cost:
                        open_set[n_id] = node

        rx, ry = self.calc_final_path(goal_node, closed_set)

        return rx, ry

    def calc_final_path(self, goal_node, closed_set):
        rx, ry = [self.calc_grid_position(goal_node.x, self.min_x)], [self.calc_grid_position(goal_node.y, self.min_y)]
        parent_index = goal_node.parent_index
        while parent_index != -1:
            n = closed_set[parent_index]
            rx.append(self.calc_grid_position(n.x, self.min_x))
            ry.append(self.calc_grid_position(n.y, self.min_y))
            parent_index = n.parent_index

        rx.reverse()
        ry.reverse()
        return rx, ry

    @staticmethod
    def calc_heuristic(n1, n2):
        w = 1.0
        d = w * math.hypot(n1.x - n2.x, n1.y - n2.y)
        return d

    def calc_grid_position(self, index, min_position):
        pos = index * self.resolution + min_position
        return pos

    def calc_xy_index(self, position, min_pos):
        return round((position - min_pos) / self.resolution)

    def calc_grid_index(self, node):
        return node.y * self.x_width + node.x

    def verify_node(self, node):
        if node.x < 0 or node.y < 0 or node.x >= self.x_width or node.y >= self.y_width:
            return False

        if self.obstacle_map[node.x][node.y]:
            return False

        return True

    def calc_obstacle_map(self, ox, oy):
        self.obstacle_map = [[False for _ in range(self.y_width)] for _ in range(self.x_width)]

        for ix in range(self.x_width):
            x = self.calc_grid_position(ix, self.min_x)
            for iy in range(self.y_width):
                y = self.calc_grid_position(iy, self.min_y)
                for iox, ioy in zip(ox, oy):
                    d = math.hypot(iox - x, ioy - y)
                    if d <= self.rr:
                        self.obstacle_map[ix][iy] = True
                        break

    @staticmethod
    def get_motion_model():
        motion = [[1, 0, 1],
                  [0, 1, 1],
                  [-1, 0, 1],
                  [0, -1, 1],
                  [-1, -1, math.sqrt(2)],
                  [-1, 1, math.sqrt(2)],
                  [1, -1, math.sqrt(2)],
                  [1, 1, math.sqrt(2)]]
        return motion


def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    min_bound, max_bound = bounds[0], bounds[1]

    # Clamp start and goal inside bounds minus robot_radius margin
    def clamp_point(p):
        return [
            min(max(p[0], min_bound + robot_radius), max_bound - robot_radius),
            min(max(p[1], min_bound + robot_radius), max_bound - robot_radius)
        ]

    start_clamped = clamp_point(start)
    goal_clamped = clamp_point(goal)

    # Create boundary obstacles at integer coordinates
    boundary_obstacles = []
    for x in range(min_bound, max_bound + 1):
        boundary_obstacles.append([x, min_bound])
        boundary_obstacles.append([x, max_bound])
    for y in range(min_bound + 1, max_bound):
        boundary_obstacles.append([min_bound, y])
        boundary_obstacles.append([max_bound, y])

    all_obstacles = obstacles + boundary_obstacles

    ox = [p[0] for p in all_obstacles]
    oy = [p[1] for p in all_obstacles]

    ox.append(start_clamped[0])
    oy.append(start_clamped[1])
    ox.append(goal_clamped[0])
    oy.append(goal_clamped[1])

    resolution = 0.1

    planner = AStarPlanner(ox, oy, resolution, robot_radius, bounds)

    rx, ry = planner.planning(start_clamped[0], start_clamped[1], goal_clamped[0], goal_clamped[1])

    path_xy = [[x, y] for x, y in zip(rx, ry)]

    if len(path_xy) < 2:
        # fallback direct path
        path_xy = [start_clamped, goal_clamped]

    length_m = 0.0
    for i in range(1, len(path_xy)):
        length_m += math.hypot(path_xy[i][0] - path_xy[i-1][0], path_xy[i][1] - path_xy[i-1][1])

    return {"path_xy": path_xy, "length_m": length_m}
