import math
from pythonrobotics.PathPlanning.AStar.a_star import AStarPlanner

def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    # Create obstacle points including boundary points sampled at integer coordinates
    ox = []
    oy = []

    # Add boundary points (integer sampled) as obstacles
    min_bound = bounds[0]
    max_bound = bounds[1]
    for x in range(min_bound, max_bound + 1):
        ox.append(x)
        oy.append(min_bound)
        ox.append(x)
        oy.append(max_bound)
    for y in range(min_bound, max_bound + 1):
        ox.append(min_bound)
        oy.append(y)
        ox.append(max_bound)
        oy.append(y)

    # Add given point obstacles
    for ob in obstacles:
        ox.append(ob[0])
        oy.append(ob[1])

    # Add start and goal to obstacle list to ensure map covers them
    ox.append(start[0])
    oy.append(start[1])
    ox.append(goal[0])
    oy.append(goal[1])

    # Choose grid resolution smaller than robot radius for finer path
    resolution = robot_radius / 2.0

    # Create AStar planner
    planner = AStarPlanner(ox, oy, resolution, robot_radius)

    # Plan path
    rx, ry = planner.planning(start[0], start[1], goal[0], goal[1])

    # Reverse path to start->goal order (AStar returns goal->start)
    rx = rx[::-1]
    ry = ry[::-1]

    path_xy = [[x, y] for x, y in zip(rx, ry)]

    # Compute path length
    length_m = 0.0
    for i in range(1, len(path_xy)):
        length_m += math.hypot(path_xy[i][0] - path_xy[i-1][0], path_xy[i][1] - path_xy[i-1][1])

    return {"path_xy": path_xy, "length_m": length_m}

# The solve function is now ready for testing.