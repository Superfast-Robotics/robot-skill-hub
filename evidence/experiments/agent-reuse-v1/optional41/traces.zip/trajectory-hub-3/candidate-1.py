from ruckig import InputParameter, Ruckig, Trajectory, Result
import numpy as np

def solve(task):
    # Extract input data
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Initialize Ruckig offline trajectory generator
    ruckig = Ruckig(dof)
    inp = InputParameter(dof)

    # Set input parameters
    inp.current_position = current_position
    inp.current_velocity = current_velocity
    inp.current_acceleration = current_acceleration

    inp.target_position = target_position
    inp.target_velocity = target_velocity
    inp.target_acceleration = target_acceleration

    inp.max_velocity = max_velocity
    inp.max_acceleration = max_acceleration
    inp.max_jerk = max_jerk

    # We do not set min_velocity or min_acceleration, assuming symmetric limits

    trajectory = Trajectory(dof)

    # Calculate the offline trajectory
    result = ruckig.calculate(inp, trajectory)
    if result != Result.Working:
        raise RuntimeError("Ruckig failed to calculate trajectory")

    duration = trajectory.duration
    if duration > 30.0:
        duration = 30.0  # Clamp duration to 30 seconds max

    # Generate time samples from 0 to duration with spacing <= dt
    # Ensure last sample is exactly at duration
    num_samples = int(np.ceil(duration / dt)) + 1
    if num_samples > 3000:
        num_samples = 3000
    time_s = np.linspace(0, duration, num_samples)

    position = []
    velocity = []
    acceleration = []

    for t in time_s:
        pos, vel, acc = trajectory.at_time(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Check endpoint accuracy within 1e-6
    assert np.allclose(position[0], current_position, atol=1e-6)
    assert np.allclose(velocity[0], current_velocity, atol=1e-6)
    assert np.allclose(acceleration[0], current_acceleration, atol=1e-6)
    assert np.allclose(position[-1], target_position, atol=1e-6)
    assert np.allclose(velocity[-1], target_velocity, atol=1e-6)
    assert np.allclose(acceleration[-1], target_acceleration, atol=1e-6)

    # Check velocity, acceleration, jerk bounds
    # Jerk is approximated numerically from acceleration samples
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]
    max_jerk_sampled = np.max(np.abs(jerk), axis=0)
    for i in range(dof):
        if max_jerk_sampled[i] > max_jerk[i] + 1e-6:
            raise RuntimeError(f"Jerk limit exceeded on axis {i}: {max_jerk_sampled[i]} > {max_jerk[i]}")

    max_velocity_sampled = np.max(np.abs(velocity), axis=0)
    for i in range(dof):
        if max_velocity_sampled[i] > max_velocity[i] + 1e-6:
            raise RuntimeError(f"Velocity limit exceeded on axis {i}: {max_velocity_sampled[i]} > {max_velocity[i]}")

    max_acceleration_sampled = np.max(np.abs(acceleration), axis=0)
    for i in range(dof):
        if max_acceleration_sampled[i] > max_acceleration[i] + 1e-6:
            raise RuntimeError(f"Acceleration limit exceeded on axis {i}: {max_acceleration_sampled[i]} > {max_acceleration[i]}")

    # Return results
    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
