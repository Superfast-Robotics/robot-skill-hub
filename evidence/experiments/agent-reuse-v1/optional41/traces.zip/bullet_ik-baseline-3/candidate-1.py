import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Start PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Initialize all seven joints from task
    initial_joint_angles = task["joint_angles"]
    for i in range(7):
        p.resetJointState(robot, i, initial_joint_angles[i])

    # Target position for link index 6
    target_xyz = task["target_xyz"]

    # Use PyBullet inverse kinematics to solve for joint angles
    # We only use position, no orientation
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Extract the first 7 joint angles from the solution
    joint_angles_rad = ik_solution[:7]

    # Set the robot joints to the IK solution
    for i in range(7):
        p.resetJointState(robot, i, joint_angles_rad[i])

    # Get the end effector position after IK
    link_state = p.getLinkState(robot, 6)
    end_effector_xyz_m = link_state[4]  # world position of the link frame

    # Calculate position error
    position_error_m = np.linalg.norm(np.array(end_effector_xyz_m) - np.array(target_xyz))

    # Disconnect PyBullet
    p.disconnect()

    # Return results
    return {
        "joint_angles_rad": list(joint_angles_rad),
        "end_effector_xyz_m": list(end_effector_xyz_m),
        "position_error_m": float(position_error_m)
    }
