import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    physicsClient = p.connect(p.DIRECT)
    robot = create_arm(p)

    initial_joint_angles = task["joint_angles"]
    target_xyz = task["target_xyz"]

    # Reset joints to initial angles
    for i, angle in enumerate(initial_joint_angles):
        p.resetJointState(robot, i, angle)

    # Define joint limits (wide range since none specified)
    lower_limits = [-3]*7
    upper_limits = [3]*7
    joint_ranges = [upper_limits[i] - lower_limits[i] for i in range(7)]
    rest_poses = initial_joint_angles

    # Calculate IK with null space to improve accuracy
    ik_solution = p.calculateInverseKinematics(
        robot, 6, target_xyz,
        lowerLimits=lower_limits,
        upperLimits=upper_limits,
        jointRanges=joint_ranges,
        restPoses=rest_poses,
        maxNumIterations=1000,
        residualThreshold=1e-6
    )

    joint_angles_rad = ik_solution[:7]

    # Apply IK solution
    for i, angle in enumerate(joint_angles_rad):
        p.resetJointState(robot, i, angle)

    # Get end effector position
    link_state = p.getLinkState(robot, 6)
    end_effector_xyz_m = link_state[4]

    # Compute position error
    position_error_m = np.linalg.norm(np.array(end_effector_xyz_m) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": list(joint_angles_rad),
        "end_effector_xyz_m": list(end_effector_xyz_m),
        "position_error_m": float(position_error_m)
    }
