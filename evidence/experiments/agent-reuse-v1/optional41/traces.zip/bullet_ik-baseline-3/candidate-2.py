import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    physicsClient = p.connect(p.DIRECT)
    robot = create_arm(p)

    # Initialize joints from task
    for i, angle in enumerate(task["joint_angles"]):
        p.resetJointState(robot, i, angle)

    target_xyz = task["target_xyz"]

    # Calculate inverse kinematics for link index 6
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    joint_angles_rad = ik_solution[:7]

    # Apply IK solution to robot
    for i, angle in enumerate(joint_angles_rad):
        p.resetJointState(robot, i, angle)

    # Get end effector position
    link_state = p.getLinkState(robot, 6)
    end_effector_xyz_m = link_state[4]

    # Compute position error
    position_error_m = np.linalg.norm(np.array(end_effector_xyz_m) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": list(joint_angles_rad),
        "end_effector_xyz_m": list(end_effector_xyz_m),
        "position_error_m": float(position_error_m)
    }
