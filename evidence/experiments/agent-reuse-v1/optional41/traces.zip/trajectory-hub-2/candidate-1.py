import numpy as np
import ruckig

def solve(task):
    # Extract inputs
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup Ruckig input
    input = ruckig.InputParameter(dof)
    input.current_position = current_position
    input.current_velocity = current_velocity
    input.current_acceleration = current_acceleration
    input.target_position = target_position
    input.target_velocity = target_velocity
    input.target_acceleration = target_acceleration
    input.max_velocity = max_velocity
    input.max_acceleration = max_acceleration
    input.max_jerk = max_jerk

    # Setup Ruckig OTG
    otg = ruckig.Ruckig(dof, dt)

    # Calculate minimum duration
    duration = otg.minimum_duration(input)
    # Limit duration to max 30 seconds
    duration = min(duration, 30.0)

    # We want to generate a trajectory offline with samples at most dt apart
    # Number of samples
    n_samples = int(np.ceil(duration / dt)) + 1
    if n_samples > 3000:
        n_samples = 3000
        dt = duration / (n_samples - 1)

    # Prepare output arrays
    time_s = []
    position = []
    velocity = []
    acceleration = []

    # Reinitialize OTG with possibly adjusted dt
    otg = ruckig.Ruckig(dof, dt)

    # Start trajectory generation
    input.current_position = current_position
    input.current_velocity = current_velocity
    input.current_acceleration = current_acceleration

    # Start trajectory
    result = otg.calculate(input)
    if result != ruckig.Result.Working:
        # If failed to start trajectory, fallback to zero motion
        time_s = [0.0, 0.0]
        position = [current_position, current_position]
        velocity = [current_velocity, current_velocity]
        acceleration = [current_acceleration, current_acceleration]
        return {
            "time_s": time_s,
            "position": position,
            "velocity": velocity,
            "acceleration": acceleration,
            "coordinate_type": coordinate_type,
            "duration_s": 0.0
        }

    time_s.append(0.0)
    position.append(list(input.current_position))
    velocity.append(list(input.current_velocity))
    acceleration.append(list(input.current_acceleration))

    t = 0.0
    while True:
        result = otg.update()
        if result == ruckig.Result.Finished:
            # Append final state
            time_s.append(t + dt)
            position.append(list(otg.current_position))
            velocity.append(list(otg.current_velocity))
            acceleration.append(list(otg.current_acceleration))
            break
        elif result != ruckig.Result.Working:
            # Something went wrong, break
            break
        t += dt
        time_s.append(t)
        position.append(list(otg.current_position))
        velocity.append(list(otg.current_velocity))
        acceleration.append(list(otg.current_acceleration))

        # Safety break if too long
        if t > 30.0:
            break

    duration_s = time_s[-1]

    # Ensure endpoint accuracy within 1e-6
    for i in range(dof):
        assert abs(position[-1][i] - target_position[i]) <= 1e-6, f"Position endpoint error too large for DOF {i}"
        assert abs(velocity[-1][i] - target_velocity[i]) <= 1e-6, f"Velocity endpoint error too large for DOF {i}"
        assert abs(acceleration[-1][i] - target_acceleration[i]) <= 1e-6, f"Acceleration endpoint error too large for DOF {i}"

    # Return results
    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration_s
    }
