import numpy as np
import ruckig

def solve(task):
    # Extract inputs
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Setup Ruckig input
    input = ruckig.InputParameter(dof)
    input.current_position = current_position
    input.current_velocity = current_velocity
    input.current_acceleration = current_acceleration
    input.target_position = target_position
    input.target_velocity = target_velocity
    input.target_acceleration = target_acceleration
    input.max_velocity = max_velocity
    input.max_acceleration = max_acceleration
    input.max_jerk = max_jerk

    # Setup Ruckig OTG
    otg = ruckig.Ruckig(dof, dt)

    # Calculate trajectory duration by repeatedly updating until finished
    # Start trajectory
    result = otg.calculate(input)
    if result != ruckig.Result.Working:
        # If failed to start trajectory, fallback to zero motion
        time_s = [0.0, 0.0]
        position = [current_position, current_position]
        velocity = [current_velocity, current_velocity]
        acceleration = [current_acceleration, current_acceleration]
        return {
            "time_s": time_s,
            "position": position,
            "velocity": velocity,
            "acceleration": acceleration,
            "coordinate_type": coordinate_type,
            "duration_s": 0.0
        }

    # Collect all states until finished to find duration
    states = []
    t = 0.0
    states.append((t, list(otg.current_position), list(otg.current_velocity), list(otg.current_acceleration)))
    while True:
        result = otg.update()
        t += dt
        states.append((t, list(otg.current_position), list(otg.current_velocity), list(otg.current_acceleration)))
        if result == ruckig.Result.Finished:
            break
        if result != ruckig.Result.Working:
            break
        if t > 30.0:
            break

    # Duration is last time
    duration = states[-1][0]

    # Resample trajectory with spacing <= dt and max 3000 samples
    n_samples = len(states)
    if n_samples > 3000:
        n_samples = 3000
    # If more samples than needed, resample linearly in time
    if n_samples < 2:
        n_samples = 2
    sample_times = np.linspace(0, duration, n_samples)

    # Interpolate position, velocity, acceleration for each DOF
    times = np.array([s[0] for s in states])
    positions = np.array([s[1] for s in states])
    velocities = np.array([s[2] for s in states])
    accelerations = np.array([s[3] for s in states])

    position_interp = np.zeros((n_samples, dof))
    velocity_interp = np.zeros((n_samples, dof))
    acceleration_interp = np.zeros((n_samples, dof))

    for i in range(dof):
        position_interp[:, i] = np.interp(sample_times, times, positions[:, i])
        velocity_interp[:, i] = np.interp(sample_times, times, velocities[:, i])
        acceleration_interp[:, i] = np.interp(sample_times, times, accelerations[:, i])

    # Check endpoint accuracy within 1e-6
    for i in range(dof):
        assert abs(position_interp[-1, i] - target_position[i]) <= 1e-6, f"Position endpoint error too large for DOF {i}"
        assert abs(velocity_interp[-1, i] - target_velocity[i]) <= 1e-6, f"Velocity endpoint error too large for DOF {i}"
        assert abs(acceleration_interp[-1, i] - target_acceleration[i]) <= 1e-6, f"Acceleration endpoint error too large for DOF {i}"

    # Convert to lists for output
    time_s = sample_times.tolist()
    position = position_interp.tolist()
    velocity = velocity_interp.tolist()
    acceleration = acceleration_interp.tolist()

    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
