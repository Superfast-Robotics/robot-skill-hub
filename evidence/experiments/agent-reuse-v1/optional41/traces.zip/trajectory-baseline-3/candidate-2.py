import numpy as np
from ruckig import InputParameter, Ruckig, Result

def solve(task):
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)
    otg = Ruckig(dof, dt)

    input_param = InputParameter(dof)
    input_param.current_position = current_position
    input_param.current_velocity = current_velocity
    input_param.current_acceleration = current_acceleration
    input_param.target_position = target_position
    input_param.target_velocity = target_velocity
    input_param.target_acceleration = target_acceleration
    input_param.max_velocity = max_velocity
    input_param.max_acceleration = max_acceleration
    input_param.max_jerk = max_jerk

    trajectory_positions = []
    trajectory_velocities = []
    trajectory_accelerations = []
    time_s = []

    trajectory_positions.append(current_position)
    trajectory_velocities.append(current_velocity)
    trajectory_accelerations.append(current_acceleration)
    time_s.append(0.0)

    current_state_pos = np.array(current_position)
    current_state_vel = np.array(current_velocity)
    current_state_acc = np.array(current_acceleration)

    input_param.current_position = current_state_pos.tolist()
    input_param.current_velocity = current_state_vel.tolist()
    input_param.current_acceleration = current_state_acc.tolist()

    max_duration = 30.0
    max_samples = 3000

    t = 0.0
    while True:
        result = otg.update(input_param)
        if result == Result.Error:
            raise RuntimeError("Ruckig update error")
        trajectory_positions.append(otg.current_position)
        trajectory_velocities.append(otg.current_velocity)
        trajectory_accelerations.append(otg.current_acceleration)
        t += dt
        time_s.append(t)

        input_param.current_position = otg.current_position
        input_param.current_velocity = otg.current_velocity
        input_param.current_acceleration = otg.current_acceleration

        if result == Result.Finished:
            break
        if t > max_duration:
            break
        if len(time_s) >= max_samples:
            break

    duration = time_s[-1]

    if duration < max_duration and result == Result.Finished:
        pos, vel, acc = otg.at_time(duration)
        if abs(duration - time_s[-1]) > 1e-12:
            time_s.append(duration)
            trajectory_positions.append(pos)
            trajectory_velocities.append(vel)
            trajectory_accelerations.append(acc)

    position = np.array(trajectory_positions)
    velocity = np.array(trajectory_velocities)
    acceleration = np.array(trajectory_accelerations)
    time_s = np.array(time_s)

    assert np.allclose(position[0], current_position, atol=1e-6)
    assert np.allclose(velocity[0], current_velocity, atol=1e-6)
    assert np.allclose(acceleration[0], current_acceleration, atol=1e-6)
    assert np.allclose(position[-1], target_position, atol=1e-6)
    assert np.allclose(velocity[-1], target_velocity, atol=1e-6)
    assert np.allclose(acceleration[-1], target_acceleration, atol=1e-6)

    jerk = np.diff(acceleration, axis=0) / dt
    max_vel = np.array(max_velocity)
    max_acc = np.array(max_acceleration)
    max_jrk = np.array(max_jerk)

    assert np.all(np.abs(velocity) <= max_vel + 1e-6)
    assert np.all(np.abs(acceleration) <= max_acc + 1e-6)
    assert np.all(np.abs(jerk) <= max_jrk + 1e-5)

    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
