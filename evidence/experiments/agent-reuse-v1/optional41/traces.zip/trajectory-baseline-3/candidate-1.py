import numpy as np
from ruckig import InputParameter, Ruckig, Result

def solve(task):
    # Extract input data
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Initialize Ruckig offline trajectory generator
    otg = Ruckig(dof, 0.02)  # dt is max control cycle, but we will sample finer

    # Setup input parameters
    input_param = InputParameter(dof)
    input_param.current_position = current_position
    input_param.current_velocity = current_velocity
    input_param.current_acceleration = current_acceleration
    input_param.target_position = target_position
    input_param.target_velocity = target_velocity
    input_param.target_acceleration = target_acceleration
    input_param.max_velocity = max_velocity
    input_param.max_acceleration = max_acceleration
    input_param.max_jerk = max_jerk

    # Generate offline trajectory
    trajectory = otg.calculate_offline(input_param)

    # Extract trajectory duration
    duration = trajectory.duration
    if duration > 30.0:
        duration = 30.0  # clamp duration to 30s max

    # We want to sample with spacing <= dt, include t=0 and t=duration
    # Calculate number of samples
    n_samples = int(np.ceil(duration / dt)) + 1
    if n_samples > 3000:
        n_samples = 3000
        dt = duration / (n_samples - 1)

    # Sample times
    time_s = np.linspace(0, duration, n_samples)

    # Prepare output arrays
    position = []
    velocity = []
    acceleration = []

    # Sample the trajectory
    for t in time_s:
        pos, vel, acc = trajectory.at_time(t)
        position.append(pos.tolist())
        velocity.append(vel.tolist())
        acceleration.append(acc.tolist())

    # Convert to numpy arrays for numerical consistency checks
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Check endpoint accuracy within 1e-6
    assert np.allclose(position[0], current_position, atol=1e-6)
    assert np.allclose(velocity[0], current_velocity, atol=1e-6)
    assert np.allclose(acceleration[0], current_acceleration, atol=1e-6)
    assert np.allclose(position[-1], target_position, atol=1e-6)
    assert np.allclose(velocity[-1], target_velocity, atol=1e-6)
    assert np.allclose(acceleration[-1], target_acceleration, atol=1e-6)

    # Check velocity, acceleration, jerk bounds
    # Jerk is not directly given, so approximate jerk by finite difference of acceleration
    jerk = np.diff(acceleration, axis=0) / dt

    max_vel = np.array(max_velocity)
    max_acc = np.array(max_acceleration)
    max_jrk = np.array(max_jerk)

    assert np.all(np.abs(velocity) <= max_vel[:, None].T + 1e-6)
    assert np.all(np.abs(acceleration) <= max_acc[:, None].T + 1e-6)
    assert np.all(np.abs(jerk) <= max_jrk[:, None].T + 1e-5)  # slightly relaxed for numerical diff

    # Return results
    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
