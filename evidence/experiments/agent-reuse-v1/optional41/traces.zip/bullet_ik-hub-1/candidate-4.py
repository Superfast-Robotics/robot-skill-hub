import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Connect to PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Set initial joint angles from task
    initial_joint_angles = task["joint_angles"]
    for i in range(7):
        p.resetJointState(robot, i, initial_joint_angles[i])

    # Target position for the end effector (link index 6)
    target_xyz = task["target_xyz"]

    # Define joint limits (from input schema)
    lower_limits = [-3.0]*7
    upper_limits = [3.0]*7

    # Use PyBullet inverse kinematics with joint limits and rest poses
    ik_solution = p.calculateInverseKinematics(
        bodyUniqueId=robot,
        endEffectorLinkIndex=6,
        targetPosition=target_xyz,
        lowerLimits=lower_limits,
        upperLimits=upper_limits,
        jointRanges=[6.0]*7,
        restPoses=initial_joint_angles,
        maxNumIterations=2000,
        residualThreshold=1e-8
    )

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the end effector position after applying IK solution
    link_state = p.getLinkState(robot, 6)
    end_effector_xyz = link_state[4]  # world position of link frame

    # Calculate position error
    position_error = np.linalg.norm(np.array(end_effector_xyz) - np.array(target_xyz))

    # Disconnect the physics client
    p.disconnect()

    # Return the results
    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_xyz),
        "position_error_m": float(position_error)
    }
