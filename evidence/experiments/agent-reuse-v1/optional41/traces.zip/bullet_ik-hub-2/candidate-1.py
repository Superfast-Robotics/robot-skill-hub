import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Start PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Initialize all seven joints from task input
    initial_joint_angles = task["joint_angles"]
    for i in range(7):
        p.resetJointState(robot, i, initial_joint_angles[i])

    # Target position for link index 6
    target_xyz = task["target_xyz"]

    # Use PyBullet inverse kinematics to solve for joint angles
    # We only want to solve position for link index 6
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the end effector position after applying IK
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]  # world position of the link frame

    # Calculate position error
    position_error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    # Disconnect the physics client
    p.disconnect()

    # Return the results
    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": position_error
    }
