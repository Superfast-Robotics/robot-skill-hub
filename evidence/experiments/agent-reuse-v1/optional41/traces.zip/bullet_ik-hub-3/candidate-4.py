import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    physicsClient = p.connect(p.DIRECT)
    robot = create_arm(p)

    initial_angles = task["joint_angles"]
    target_xyz = task["target_xyz"]

    # Reset joints to initial angles
    for i, angle in enumerate(initial_angles):
        p.resetJointState(robot, i, angle)

    # Joint limits and ranges (given problem constraints)
    lower_limits = [-3]*7
    upper_limits = [3]*7
    joint_ranges = [6]*7
    rest_poses = initial_angles

    # Calculate IK with rest poses to improve accuracy
    ik_solution = p.calculateInverseKinematics(
        robot, 6, target_xyz,
        lowerLimits=lower_limits,
        upperLimits=upper_limits,
        jointRanges=joint_ranges,
        restPoses=rest_poses,
        maxNumIterations=200,
        residualThreshold=1e-6
    )

    # Apply IK solution
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get end effector position
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]

    # Calculate position error
    error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": error
    }
