import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Start PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Set initial joint angles from task
    initial_angles = task["joint_angles"]
    for i in range(7):
        p.resetJointState(robot, i, initial_angles[i])

    # Target position for link index 6
    target_xyz = task["target_xyz"]

    # Use PyBullet inverse kinematics to find joint angles for link 6
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the end effector position after IK
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]  # worldLinkFramePosition

    # Calculate position error
    error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    # Disconnect PyBullet
    p.disconnect()

    # Return results
    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": error
    }
