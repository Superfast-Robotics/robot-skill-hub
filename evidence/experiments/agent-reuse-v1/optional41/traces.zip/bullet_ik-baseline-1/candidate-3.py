import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    physicsClient = p.connect(p.DIRECT)
    p.setGravity(0, 0, -9.81)

    robot = create_arm(p)

    initial_joint_angles = task["joint_angles"]
    target_xyz = task["target_xyz"]

    # Set initial joint states
    for i, angle in enumerate(initial_joint_angles):
        p.resetJointState(robot, i, angle)

    # Use calculateInverseKinematics with maxNumIterations and residual threshold
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz, maxNumIterations=1000, residualThreshold=1e-6)

    # Apply the IK solution
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the end effector position
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]

    position_error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": ik_solution[:7],
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": position_error
    }
