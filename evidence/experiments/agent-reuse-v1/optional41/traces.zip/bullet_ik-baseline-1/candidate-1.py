import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Start PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)
    p.setGravity(0, 0, -9.81)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Extract input joint angles and target position
    initial_joint_angles = task["joint_angles"]
    target_xyz = task["target_xyz"]

    # Set initial joint states
    for i, angle in enumerate(initial_joint_angles):
        p.resetJointState(robot, i, angle)

    # Solve inverse kinematics for link index 6 (7th joint) position
    # We only want position, no orientation constraints
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the end effector position after IK
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]  # worldLinkFramePosition

    # Calculate position error
    position_error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    # Disconnect PyBullet
    p.disconnect()

    # Return results
    return {
        "joint_angles_rad": ik_solution[:7],
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": position_error
    }
