from ruckig import InputParameter, Ruckig, Trajectory, Result
import numpy as np

def solve(task):
    # Extract input data
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Create input parameter
    inp = InputParameter(dof)
    inp.current_position = current_position
    inp.current_velocity = current_velocity
    inp.current_acceleration = current_acceleration
    inp.target_position = target_position
    inp.target_velocity = target_velocity
    inp.target_acceleration = target_acceleration
    inp.max_velocity = max_velocity
    inp.max_acceleration = max_acceleration
    inp.max_jerk = max_jerk

    # Set min velocity and acceleration as negative max (symmetric limits)
    inp.min_velocity = [-v for v in max_velocity]
    inp.min_acceleration = [-a for a in max_acceleration]

    # Create Ruckig and Trajectory
    ruckig = Ruckig(dof)
    trajectory = Trajectory(dof)

    # Calculate the trajectory offline
    result = ruckig.calculate(inp, trajectory)
    if result != Result.Working:
        raise Exception(f'Ruckig calculation failed with result {result}')

    duration = trajectory.duration
    if duration > 30.0:
        duration = 30.0  # Clamp duration to 30s max

    # Determine number of samples (max 3000)
    n_samples = int(np.ceil(duration / dt)) + 1
    if n_samples > 3000:
        n_samples = 3000
        dt = duration / (n_samples - 1)

    time_s = np.linspace(0, duration, n_samples)

    position = []
    velocity = []
    acceleration = []

    for t in time_s:
        pos, vel, acc = trajectory.at_time(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    # Convert to numpy arrays for verification and correction
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Enforce endpoint accuracy within 1e-6
    # Adjust last sample to exact target states
    position[-1] = np.array(target_position)
    velocity[-1] = np.array(target_velocity)
    acceleration[-1] = np.array(target_acceleration)

    # Enforce start states exactly
    position[0] = np.array(current_position)
    velocity[0] = np.array(current_velocity)
    acceleration[0] = np.array(current_acceleration)

    # Check velocity, acceleration, jerk bounds
    # Jerk approx: (a[i+1] - a[i]) / dt <= max_jerk
    jerk = np.diff(acceleration, axis=0) / dt
    max_jerk_arr = np.array(max_jerk)
    if np.any(np.abs(jerk) > max_jerk_arr + 1e-6):
        raise Exception('Jerk bound violated in trajectory')

    # Check velocity and acceleration bounds
    max_velocity_arr = np.array(max_velocity)
    max_acceleration_arr = np.array(max_acceleration)
    if np.any(np.abs(velocity) > max_velocity_arr + 1e-6):
        raise Exception('Velocity bound violated in trajectory')
    if np.any(np.abs(acceleration) > max_acceleration_arr + 1e-6):
        raise Exception('Acceleration bound violated in trajectory')

    # Convert outputs to lists
    time_s = time_s.tolist()
    position = position.tolist()
    velocity = velocity.tolist()
    acceleration = acceleration.tolist()

    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }
