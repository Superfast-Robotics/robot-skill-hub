from hub_runtime import run_recipe
def solve(task):
    # Use the preinstalled pybullet-ik-skill adapter for this exact task
    outputs = run_recipe('pybullet-ik-skill', task)
    return outputs
