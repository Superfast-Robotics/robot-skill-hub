import numpy as np
import math
import random

class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None

class RRT:
    def __init__(self, start, goal, bounds, obstacles, robot_radius, max_iter=5000, step_len=0.5, goal_sample_rate=0.1):
        self.start = Node(start[0], start[1])
        self.goal = Node(goal[0], goal[1])
        self.min_rand = bounds[0] + robot_radius
        self.max_rand = bounds[1] - robot_radius
        self.robot_radius = robot_radius
        self.obstacles = obstacles
        self.max_iter = max_iter
        self.step_len = step_len
        self.goal_sample_rate = goal_sample_rate
        self.node_list = [self.start]

    def planning(self):
        for i in range(self.max_iter):
            rnd_node = self.get_random_node()
            nearest_ind = self.get_nearest_node_index(self.node_list, rnd_node)
            nearest_node = self.node_list[nearest_ind]

            new_node = self.steer(nearest_node, rnd_node, self.step_len)

            if self.check_collision(nearest_node, new_node):
                self.node_list.append(new_node)

                if self.calc_dist_to_goal(new_node.x, new_node.y) <= self.step_len:
                    final_node = self.steer(new_node, self.goal, self.step_len)
                    if self.check_collision(new_node, final_node):
                        return self.generate_final_course(len(self.node_list) - 1)

        return None  # no path found

    def steer(self, from_node, to_node, extend_length=float('inf')):
        new_node = Node(from_node.x, from_node.y)
        d, theta = self.calc_distance_and_angle(new_node, to_node)

        extend_length = min(extend_length, d)

        new_node.x += extend_length * math.cos(theta)
        new_node.y += extend_length * math.sin(theta)

        new_node.parent = from_node

        return new_node

    def calc_distance_and_angle(self, from_node, to_node):
        dx = to_node.x - from_node.x
        dy = to_node.y - from_node.y
        d = math.hypot(dx, dy)
        theta = math.atan2(dy, dx)
        return d, theta

    def get_random_node(self):
        if random.random() > self.goal_sample_rate:
            rnd = Node(random.uniform(self.min_rand, self.max_rand), random.uniform(self.min_rand, self.max_rand))
        else:
            rnd = Node(self.goal.x, self.goal.y)
        return rnd

    def get_nearest_node_index(self, node_list, rnd_node):
        dlist = [(node.x - rnd_node.x)**2 + (node.y - rnd_node.y)**2 for node in node_list]
        min_index = dlist.index(min(dlist))
        return min_index

    def check_collision(self, node1, node2):
        # Check if the path between node1 and node2 is collision free
        x1, y1 = node1.x, node1.y
        x2, y2 = node2.x, node2.y

        dist = math.hypot(x2 - x1, y2 - y1)
        steps = max(int(dist / (self.robot_radius / 2)), 1)

        for i in range(steps + 1):
            t = i / steps
            x = x1 + t * (x2 - x1)
            y = y1 + t * (y2 - y1)

            if not self.is_in_bounds(x, y):
                return False

            if self.is_in_obstacle(x, y):
                return False

        return True

    def is_in_bounds(self, x, y):
        # Check if point is inside the bounds considering robot radius
        if x < self.min_rand or x > self.max_rand or y < self.min_rand or y > self.max_rand:
            return False
        return True

    def is_in_obstacle(self, x, y):
        # Check if point is inside any obstacle considering robot radius
        for (ox, oy) in self.obstacles:
            d = math.hypot(ox - x, oy - y)
            if d <= self.robot_radius:
                return True
        return False

    def calc_dist_to_goal(self, x, y):
        dx = x - self.goal.x
        dy = y - self.goal.y
        return math.hypot(dx, dy)

    def generate_final_course(self, goal_ind):
        path = []
        node = self.node_list[goal_ind]
        while node is not None:
            path.append([node.x, node.y])
            node = node.parent
        path.reverse()
        return path


def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    # Use RRT planner
    rrt = RRT(start, goal, bounds, obstacles, robot_radius)
    path = rrt.planning()

    if path is None:
        # No path found, return direct path if possible
        path = [start, goal]

    # Calculate path length
    length = 0.0
    for i in range(len(path) - 1):
        length += math.dist(path[i], path[i+1])

    return {"path_xy": path, "length_m": length}
