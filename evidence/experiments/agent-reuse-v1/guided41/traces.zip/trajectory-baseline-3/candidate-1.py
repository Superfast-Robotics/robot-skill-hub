from ruckig import InputParameter, Ruckig, Trajectory, Result
import numpy as np

def solve(task):
    # Extract input parameters
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Initialize Ruckig offline trajectory generator
    ruckig = Ruckig(dof)
    inp = InputParameter(dof)

    # Set input parameters
    inp.current_position = current_position
    inp.current_velocity = current_velocity
    inp.current_acceleration = current_acceleration
    inp.target_position = target_position
    inp.target_velocity = target_velocity
    inp.target_acceleration = target_acceleration
    inp.max_velocity = max_velocity
    inp.max_acceleration = max_acceleration
    inp.max_jerk = max_jerk

    # We do not set min_velocity or min_acceleration explicitly, assuming symmetric limits

    trajectory = Trajectory(dof)

    # Calculate the offline trajectory
    result = ruckig.calculate(inp, trajectory)
    if result != Result.Working:
        raise Exception("Ruckig failed to calculate trajectory")

    duration = trajectory.duration
    if duration > 30:
        duration = 30  # Clamp duration to 30 seconds max

    # Sample the trajectory at intervals <= dt, including t=0 and t=duration
    num_samples = int(np.ceil(duration / dt)) + 1
    if num_samples > 3000:
        num_samples = 3000
        dt = duration / (num_samples - 1)

    time_s = np.linspace(0, duration, num_samples)

    position = []
    velocity = []
    acceleration = []

    for t in time_s:
        pos, vel, acc = trajectory.at_time(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Validate endpoints within tolerance 1e-6
    eps = 1e-6
    assert np.allclose(position[0], current_position, atol=eps)
    assert np.allclose(velocity[0], current_velocity, atol=eps)
    assert np.allclose(acceleration[0], current_acceleration, atol=eps)
    assert np.allclose(position[-1], target_position, atol=eps)
    assert np.allclose(velocity[-1], target_velocity, atol=eps)
    assert np.allclose(acceleration[-1], target_acceleration, atol=eps)

    # Validate velocity, acceleration, and jerk bounds at sampled points
    # Jerk is numerically approximated from acceleration
    vel_max = np.array(max_velocity)
    acc_max = np.array(max_acceleration)
    jerk_max = np.array(max_jerk)

    # Check velocity and acceleration limits
    if not (np.all(np.abs(velocity) <= vel_max + eps) and np.all(np.abs(acceleration) <= acc_max + eps)):
        raise Exception("Velocity or acceleration limits exceeded")

    # Compute jerk numerically
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]
    if not np.all(np.abs(jerk) <= jerk_max + eps):
        raise Exception("Jerk limits exceeded")

    # Return results as lists for JSON serialization
    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration
    }