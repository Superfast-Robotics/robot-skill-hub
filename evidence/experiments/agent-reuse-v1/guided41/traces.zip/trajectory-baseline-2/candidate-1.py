from ruckig import InputParameter, Ruckig, Trajectory, Result
import numpy as np

def solve(task):
    # Parse input
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Create input parameters for Ruckig
    inp = InputParameter(dof)
    inp.current_position = current_position
    inp.current_velocity = current_velocity
    inp.current_acceleration = current_acceleration
    inp.target_position = target_position
    inp.target_velocity = target_velocity
    inp.target_acceleration = target_acceleration
    inp.max_velocity = max_velocity
    inp.max_acceleration = max_acceleration
    inp.max_jerk = max_jerk

    # Set min velocity and acceleration as negative max for symmetric limits
    inp.min_velocity = [-v for v in max_velocity]
    inp.min_acceleration = [-a for a in max_acceleration]

    # Initialize Ruckig offline trajectory generator
    ruckig = Ruckig(dof)
    trajectory = Trajectory(dof)

    # Calculate the trajectory offline
    result = ruckig.calculate(inp, trajectory)
    if result != Result.Working:
        raise Exception("Ruckig failed to calculate trajectory")

    duration = trajectory.duration
    # Limit duration to 30 seconds max
    duration = min(duration, 30.0)

    # Generate time samples from 0 to duration with spacing <= dt
    n_samples = int(np.ceil(duration / dt)) + 1
    if n_samples > 3000:
        n_samples = 3000
    time_s = np.linspace(0, duration, n_samples)

    # Sample trajectory states at each time
    position = []
    velocity = []
    acceleration = []

    for t in time_s:
        pos, vel, acc = trajectory.at_time(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Verify endpoint accuracy within 1e-6
    def close_enough(a, b):
        return np.all(np.abs(np.array(a) - np.array(b)) <= 1e-6)

    assert close_enough(position[0], current_position)
    assert close_enough(velocity[0], current_velocity)
    assert close_enough(acceleration[0], current_acceleration)
    assert close_enough(position[-1], target_position)
    assert close_enough(velocity[-1], target_velocity)
    assert close_enough(acceleration[-1], target_acceleration)

    # Verify velocity, acceleration, jerk bounds
    # Jerk approx by finite difference of acceleration
    jerk = np.diff(acceleration, axis=0) / np.diff(time_s)[:, None]

    # Check velocity limits
    for i in range(dof):
        assert np.all(np.abs(velocity[:, i]) <= max_velocity[i] + 1e-6)
    # Check acceleration limits
    for i in range(dof):
        assert np.all(np.abs(acceleration[:, i]) <= max_acceleration[i] + 1e-6)
    # Check jerk limits
    for i in range(dof):
        assert np.all(np.abs(jerk[:, i]) <= max_jerk[i] + 1e-5)

    # Return results as lists
    return {
        "time_s": time_s.tolist(),
        "position": position.tolist(),
        "velocity": velocity.tolist(),
        "acceleration": acceleration.tolist(),
        "coordinate_type": coordinate_type,
        "duration_s": duration,
    }