from hub_runtime import run_recipe

def solve(task):
    # Use the preinstalled ruckig-offline-trajectory recipe to generate the trajectory
    outputs = run_recipe('ruckig-offline-trajectory', task)
    return outputs
