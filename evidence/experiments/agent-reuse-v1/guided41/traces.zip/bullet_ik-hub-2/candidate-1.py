from hub_runtime import run_recipe

def solve(task):
    outputs = run_recipe('pybullet-ik-skill', task)
    return outputs
