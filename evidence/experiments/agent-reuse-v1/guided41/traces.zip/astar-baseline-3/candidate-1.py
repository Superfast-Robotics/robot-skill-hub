import math
import numpy as np

def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles = task["obstacles"]
    robot_radius = task["robot_radius"]

    class AStarPlanner:
        def __init__(self, ox, oy, resolution, rr, bounds):
            self.resolution = resolution
            self.rr = rr
            self.min_x, self.min_y = bounds[0], bounds[0]
            self.max_x, self.max_y = bounds[1], bounds[1]
            self.x_width = round((self.max_x - self.min_x) / self.resolution)
            self.y_width = round((self.max_y - self.min_y) / self.resolution)
            self.motion = self.get_motion_model()
            self.obstacle_map = [[False for _ in range(self.y_width)] for _ in range(self.x_width)]
            self.calc_obstacle_map(ox, oy)

        class Node:
            def __init__(self, x, y, cost, parent_index):
                self.x = x
                self.y = y
                self.cost = cost
                self.parent_index = parent_index

        def planning(self, sx, sy, gx, gy):
            start_node = self.Node(self.calc_xy_index(sx, self.min_x),
                                   self.calc_xy_index(sy, self.min_y), 0.0, -1)
            goal_node = self.Node(self.calc_xy_index(gx, self.min_x),
                                  self.calc_xy_index(gy, self.min_y), 0.0, -1)

            open_set, closed_set = dict(), dict()
            open_set[self.calc_grid_index(start_node)] = start_node

            while True:
                if len(open_set) == 0:
                    return [], []

                c_id = min(
                    open_set,
                    key=lambda o: open_set[o].cost + self.calc_heuristic(goal_node, open_set[o])
                )
                current = open_set[c_id]

                if current.x == goal_node.x and current.y == goal_node.y:
                    goal_node.parent_index = current.parent_index
                    goal_node.cost = current.cost
                    break

                del open_set[c_id]
                closed_set[c_id] = current

                for i, _ in enumerate(self.motion):
                    node = self.Node(current.x + self.motion[i][0],
                                     current.y + self.motion[i][1],
                                     current.cost + self.motion[i][2], c_id)
                    n_id = self.calc_grid_index(node)

                    if not self.verify_node(node):
                        continue
                    if n_id in closed_set:
                        continue
                    if n_id not in open_set:
                        open_set[n_id] = node
                    else:
                        if open_set[n_id].cost > node.cost:
                            open_set[n_id] = node

            rx, ry = self.calc_final_path(goal_node, closed_set)
            return rx, ry

        def calc_final_path(self, goal_node, closed_set):
            rx, ry = [self.calc_grid_position(goal_node.x, self.min_x)], [
                self.calc_grid_position(goal_node.y, self.min_y)]
            parent_index = goal_node.parent_index
            while parent_index != -1:
                n = closed_set[parent_index]
                rx.append(self.calc_grid_position(n.x, self.min_x))
                ry.append(self.calc_grid_position(n.y, self.min_y))
                parent_index = n.parent_index
            rx.reverse()
            ry.reverse()
            return rx, ry

        @staticmethod
        def calc_heuristic(n1, n2):
            w = 1.0
            d = w * math.hypot(n1.x - n2.x, n1.y - n2.y)
            return d

        def calc_grid_position(self, index, min_position):
            pos = index * self.resolution + min_position
            return pos

        def calc_xy_index(self, position, min_pos):
            return round((position - min_pos) / self.resolution)

        def calc_grid_index(self, node):
            return (node.y - self.min_y) * self.x_width + (node.x - self.min_x)

        def verify_node(self, node):
            px = self.calc_grid_position(node.x, self.min_x)
            py = self.calc_grid_position(node.y, self.min_y)

            if px < self.min_x or py < self.min_y or px >= self.max_x or py >= self.max_y:
                return False

            if self.obstacle_map[node.x][node.y]:
                return False

            return True

        def calc_obstacle_map(self, ox, oy):
            for ix in range(self.x_width):
                x = self.calc_grid_position(ix, self.min_x)
                for iy in range(self.y_width):
                    y = self.calc_grid_position(iy, self.min_y)
                    for iox, ioy in zip(ox, oy):
                        d = math.hypot(iox - x, ioy - y)
                        if d <= self.rr:
                            self.obstacle_map[ix][iy] = True
                            break

        @staticmethod
        def get_motion_model():
            motion = [[1, 0, 1],
                      [0, 1, 1],
                      [-1, 0, 1],
                      [0, -1, 1],
                      [-1, -1, math.sqrt(2)],
                      [-1, 1, math.sqrt(2)],
                      [1, -1, math.sqrt(2)],
                      [1, 1, math.sqrt(2)]]
            return motion

    ox = []
    oy = []
    for ob in obstacles:
        ox.append(ob[0])
        oy.append(ob[1])
    min_b, max_b = bounds[0], bounds[1]
    for x in range(min_b, max_b + 1):
        ox.append(x)
        oy.append(min_b)
        ox.append(x)
        oy.append(max_b)
    for y in range(min_b, max_b + 1):
        ox.append(min_b)
        oy.append(y)
        ox.append(max_b)
        oy.append(y)

    resolution = robot_radius / 2

    planner = AStarPlanner(ox, oy, resolution, robot_radius, bounds)
    rx, ry = planner.planning(start[0], start[1], goal[0], goal[1])

    if not rx or not ry:
        return {"path_xy": [], "length_m": 0.0}

    path_xy = [[x, y] for x, y in zip(rx, ry)]

    length_m = 0.0
    for i in range(1, len(path_xy)):
        length_m += math.hypot(path_xy[i][0] - path_xy[i-1][0], path_xy[i][1] - path_xy[i-1][1])

    return {"path_xy": path_xy, "length_m": length_m}
