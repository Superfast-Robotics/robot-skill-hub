import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    # Start PyBullet in DIRECT mode
    physicsClient = p.connect(p.DIRECT)
    p.setGravity(0, 0, -9.81)

    # Create the synthetic 7-axis arm
    robot = create_arm(p)

    # Initialize all 7 joints from task input
    initial_joints = task["joint_angles"]
    for i in range(7):
        p.resetJointState(robot, i, initial_joints[i])

    # Target position for the end effector (link index 6)
    target_xyz = task["target_xyz"]

    # Use PyBullet inverse kinematics to solve for joint angles
    # We only want to position the end effector (link 6) at target_xyz
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get the actual end effector position after applying IK
    state = p.getLinkState(robot, 6)
    end_effector_pos = state[4]  # worldLinkFramePosition

    # Calculate position error
    error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    # Disconnect PyBullet
    p.disconnect()

    # Return results
    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": float(error)
    }
