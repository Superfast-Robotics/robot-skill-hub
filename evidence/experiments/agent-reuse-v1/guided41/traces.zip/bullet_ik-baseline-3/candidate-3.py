import pybullet as p
import numpy as np
from public.scene import create_arm

def solve(task):
    physicsClient = p.connect(p.DIRECT)
    robot = create_arm(p)

    # Initialize joints
    for i, angle in enumerate(task["joint_angles"]):
        p.resetJointState(robot, i, angle)

    target_xyz = task["target_xyz"]

    # Solve IK for link 6
    ik_solution = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply IK solution
    for i in range(7):
        p.resetJointState(robot, i, ik_solution[i])

    # Get end effector position
    state = p.getLinkState(robot, 6)
    end_effector_pos = state[4]

    # Compute position error
    error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    p.disconnect()

    return {
        "joint_angles_rad": list(ik_solution[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": float(error)
    }
