from ruckig import Ruckig
import numpy as np

def solve(task):
    # Extract input parameters
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    degrees_of_freedom = len(current_position)

    # Initialize Ruckig with degrees of freedom and control cycle time
    ruckig = Ruckig(degrees_of_freedom, dt)

    # Setup input and output structures
    input_ = ruckig.InputParameter()
    output = ruckig.OutputParameter()

    # Set current state
    input_.current_position = current_position
    input_.current_velocity = current_velocity
    input_.current_acceleration = current_acceleration

    # Set target state
    input_.target_position = target_position
    input_.target_velocity = target_velocity
    input_.target_acceleration = target_acceleration

    # Set limits
    input_.max_velocity = max_velocity
    input_.max_acceleration = max_acceleration
    input_.max_jerk = max_jerk

    # Prepare arrays to store trajectory
    time_s = [0.0]
    position = [current_position]
    velocity = [current_velocity]
    acceleration = [current_acceleration]

    # Compute trajectory offline
    duration_s = 0.0
    max_duration = 30.0
    max_samples = 3000

    # Perform offline trajectory generation
    ruckig.prepare_offline_trajectory(input_)

    # Sample the trajectory
    while True:
        # Get current state
        pos = output.new_position
        vel = output.new_velocity
        acc = output.new_acceleration
        t = output.trajectory_time

        # Append to arrays
        time_s.append(t)
        position.append(pos)
        velocity.append(vel)
        acceleration.append(acc)

        # Check if trajectory finished
        if output.trajectory_finished:
            duration_s = t
            break

        # Advance trajectory
        ruckig.update(output)

        # Limit samples
        if len(time_s) > max_samples:
            break

    # Convert lists to arrays
    time_s = np.array(time_s)
    position = np.array(position)
    velocity = np.array(velocity)
    acceleration = np.array(acceleration)

    # Resample if dt is too large to keep spacing <= dt
    # Already guaranteed by Ruckig with dt control cycle

    # Ensure final time is included exactly
    if time_s[-1] < duration_s:
        time_s = np.append(time_s, duration_s)
        position = np.vstack([position, output.new_position])
        velocity = np.vstack([velocity, output.new_velocity])
        acceleration = np.vstack([acceleration, output.new_acceleration])

    # Convert to lists for JSON serialization
    time_s = time_s.tolist()
    position = position.tolist()
    velocity = velocity.tolist()
    acceleration = acceleration.tolist()

    # Return results
    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration_s
    }
