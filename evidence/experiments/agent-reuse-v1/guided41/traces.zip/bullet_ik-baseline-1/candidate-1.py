import pybullet as p
import numpy as np
from public import scene

def solve(task):
    # Connect to PyBullet in DIRECT mode (headless)
    physics_client = p.connect(p.DIRECT)

    # Create the synthetic 7-axis arm
    robot = scene.create_arm(p)

    # Initialize all 7 joints from task input
    initial_joint_angles = task["joint_angles"]
    for i, angle in enumerate(initial_joint_angles):
        p.resetJointState(robot, i, angle)

    # Target position for the end effector (link index 6)
    target_xyz = task["target_xyz"]

    # Compute inverse kinematics for link index 6 position
    # No orientation constraint
    joint_angles = p.calculateInverseKinematics(robot, 6, target_xyz)

    # Apply the IK solution to the robot
    for i in range(7):
        p.resetJointState(robot, i, joint_angles[i])

    # Get the actual end effector position after applying IK
    link_state = p.getLinkState(robot, 6)
    end_effector_pos = link_state[4]  # world position of link 6

    # Compute position error
    position_error = np.linalg.norm(np.array(end_effector_pos) - np.array(target_xyz))

    # Disconnect from PyBullet
    p.disconnect()

    # Return results as required
    return {
        "joint_angles_rad": list(joint_angles[:7]),
        "end_effector_xyz_m": list(end_effector_pos),
        "position_error_m": float(position_error)
    }
