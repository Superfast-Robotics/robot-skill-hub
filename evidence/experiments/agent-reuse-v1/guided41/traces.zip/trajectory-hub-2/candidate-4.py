from ruckig import Ruckig, InputParameter
import numpy as np

def solve(task):
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    ruckig = Ruckig(dof, dt)

    input_param = InputParameter(dof)
    input_param.current_position = current_position
    input_param.current_velocity = current_velocity
    input_param.current_acceleration = current_acceleration
    input_param.target_position = target_position
    input_param.target_velocity = target_velocity
    input_param.target_acceleration = target_acceleration
    input_param.max_velocity = max_velocity
    input_param.max_acceleration = max_acceleration
    input_param.max_jerk = max_jerk

    time_s = [0.0]
    position = [current_position.copy()]
    velocity = [current_velocity.copy()]
    acceleration = [current_acceleration.copy()]

    time = 0.0
    max_duration = 30.0
    max_samples = 3000

    result, output = ruckig.update(input_param)

    while result == 0:
        time += dt
        if time > max_duration or len(time_s) >= max_samples:
            break

        time_s.append(time)
        position.append(output.position.copy())
        velocity.append(output.velocity.copy())
        acceleration.append(output.acceleration.copy())

        result, output = ruckig.update()

    duration_s = time_s[-1]

    pos_err = np.max(np.abs(np.array(position[-1]) - np.array(target_position)))
    vel_err = np.max(np.abs(np.array(velocity[-1]) - np.array(target_velocity)))
    acc_err = np.max(np.abs(np.array(acceleration[-1]) - np.array(target_acceleration)))

    if pos_err > 1e-6 or vel_err > 1e-6 or acc_err > 1e-6:
        time_s.append(duration_s)
        position.append(target_position)
        velocity.append(target_velocity)
        acceleration.append(target_acceleration)

    position = [list(p) for p in position]
    velocity = [list(v) for v in velocity]
    acceleration = [list(a) for a in acceleration]

    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration_s
    }
