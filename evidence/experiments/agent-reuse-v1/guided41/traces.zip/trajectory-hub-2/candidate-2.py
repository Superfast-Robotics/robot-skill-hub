from ruckig import Ruckig, InputParameter
import numpy as np

def solve(task):
    # Extract inputs
    current_position = task["current_position"]
    current_velocity = task["current_velocity"]
    current_acceleration = task["current_acceleration"]
    target_position = task["target_position"]
    target_velocity = task["target_velocity"]
    target_acceleration = task["target_acceleration"]
    max_velocity = task["max_velocity"]
    max_acceleration = task["max_acceleration"]
    max_jerk = task["max_jerk"]
    dt = task["dt"]
    coordinate_type = task["coordinate_type"]

    dof = len(current_position)

    # Initialize Ruckig with degrees of freedom and control cycle time
    ruckig = Ruckig(dof, dt)

    # Create input parameter object
    ruckig_input = InputParameter(dof)
    ruckig_input.current_position = current_position
    ruckig_input.current_velocity = current_velocity
    ruckig_input.current_acceleration = current_acceleration
    ruckig_input.target_position = target_position
    ruckig_input.target_velocity = target_velocity
    ruckig_input.target_acceleration = target_acceleration
    ruckig_input.max_velocity = max_velocity
    ruckig_input.max_acceleration = max_acceleration
    ruckig_input.max_jerk = max_jerk

    # Generate offline trajectory
    offline_trajectory = ruckig.generate_offline_trajectory(ruckig_input)

    # Extract trajectory data
    time_s = offline_trajectory.time
    position = offline_trajectory.position
    velocity = offline_trajectory.velocity
    acceleration = offline_trajectory.acceleration
    duration_s = offline_trajectory.duration

    # Convert numpy arrays to lists
    time_s = time_s.tolist()
    position = position.tolist()
    velocity = velocity.tolist()
    acceleration = acceleration.tolist()

    # Return results
    return {
        "time_s": time_s,
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "coordinate_type": coordinate_type,
        "duration_s": duration_s
    }
