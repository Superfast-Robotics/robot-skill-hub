from hub_runtime import run_recipe

def solve(task):
    # Use the prepared pythonrobotics-astar-planner recipe to solve the path planning task
    outputs = run_recipe('pythonrobotics-astar-planner', task)
    return outputs
