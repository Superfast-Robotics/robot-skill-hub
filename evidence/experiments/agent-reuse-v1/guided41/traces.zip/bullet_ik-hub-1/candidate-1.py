from hub_runtime import run_recipe

def solve(task):
    # Use the prepared recipe from the hub for the exact task
    outputs = run_recipe('pybullet-ik-skill', task)
    return outputs
