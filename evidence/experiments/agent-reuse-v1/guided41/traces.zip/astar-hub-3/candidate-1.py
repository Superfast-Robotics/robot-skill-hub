import numpy as np
from math import sqrt

# Adapted from pythonrobotics PathPlanning/RRT/rrt.py with modifications for input/output schema
# and circular robot clearance handling.

class RRT:
    def __init__(self, start, goal, obstacle_list, rand_area, robot_radius, max_iter=500):
        self.start = Node(start[0], start[1])
        self.end = Node(goal[0], goal[1])
        self.min_rand = rand_area[0][0]
        self.max_rand = rand_area[1][0]
        self.robot_radius = robot_radius
        self.max_iter = max_iter
        self.obstacle_list = obstacle_list
        self.node_list = [self.start]

    def planning(self):
        for i in range(self.max_iter):
            rnd = self.get_random_point()
            nearest_ind = self.get_nearest_node_index(self.node_list, rnd)
            nearest_node = self.node_list[nearest_ind]

            new_node = self.steer(nearest_node, rnd, 1.0)

            if self.check_collision(new_node, self.obstacle_list, self.robot_radius):
                self.node_list.append(new_node)

            if self.calc_dist_to_goal(self.node_list[-1].x, self.node_list[-1].y) <= 1.0:
                final_node = self.steer(self.node_list[-1], [self.end.x, self.end.y], 1.0)
                if self.check_collision(final_node, self.obstacle_list, self.robot_radius):
                    return self.generate_final_course(len(self.node_list) - 1)

        return None  # no path found

    def steer(self, from_node, to_point, extend_length=float('inf')):
        new_node = Node(from_node.x, from_node.y)
        d, theta = self.calc_distance_and_angle(new_node, to_point)

        extend_length = min(extend_length, d)

        new_node.x += extend_length * np.cos(theta)
        new_node.y += extend_length * np.sin(theta)
        new_node.parent = from_node

        return new_node

    def calc_dist_to_goal(self, x, y):
        dx = x - self.end.x
        dy = y - self.end.y
        return sqrt(dx ** 2 + dy ** 2)

    def get_random_point(self):
        return [np.random.uniform(self.min_rand, self.max_rand), np.random.uniform(self.min_rand, self.max_rand)]

    def get_nearest_node_index(self, node_list, rnd):
        dlist = [(node.x - rnd[0]) ** 2 + (node.y - rnd[1]) ** 2 for node in node_list]
        minind = dlist.index(min(dlist))
        return minind

    def check_collision(self, node, obstacle_list, robot_radius):
        if node.x < self.min_rand + robot_radius or node.x > self.max_rand - robot_radius:
            return False
        if node.y < self.min_rand + robot_radius or node.y > self.max_rand - robot_radius:
            return False

        for (ox, oy, size) in obstacle_list:
            dx = ox - node.x
            dy = oy - node.y
            d = sqrt(dx * dx + dy * dy)
            if d <= size + robot_radius:
                return False

        return True

    def generate_final_course(self, goal_ind):
        path = []
        node = self.node_list[goal_ind]
        while node.parent is not None:
            path.append([node.x, node.y])
            node = node.parent
        path.append([node.x, node.y])
        return path[::-1]

    @staticmethod
    def calc_distance_and_angle(from_node, to_point):
        dx = to_point[0] - from_node.x
        dy = to_point[1] - from_node.y
        d = sqrt(dx ** 2 + dy ** 2)
        theta = np.arctan2(dy, dx)
        return d, theta


class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None


def solve(task):
    start = task["start"]
    goal = task["goal"]
    bounds = task["bounds"]
    obstacles_points = task["obstacles"]
    robot_radius = task["robot_radius"]

    # Convert bounds to 2D area [[min_x, min_y], [max_x, max_y]]
    rand_area = [[bounds[0], bounds[0]], [bounds[1], bounds[1]]]

    # Convert point obstacles to circular obstacles with radius = robot_radius
    obstacle_list = [[ox, oy, robot_radius] for (ox, oy) in obstacles_points]

    # Seed numpy random for reproducibility
    np.random.seed(0)

    rrt = RRT(start, goal, obstacle_list, rand_area, robot_radius, max_iter=3000)
    path = rrt.planning()

    if path is None:
        # No path found, return direct line if collision free
        direct_clear = True
        for (ox, oy, size) in obstacle_list:
            # Check if line from start to goal intersects obstacle circle with clearance
            # Use point-line distance formula
            px, py = ox, oy
            x1, y1 = start
            x2, y2 = goal
            line_mag = sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
            if line_mag == 0:
                direct_clear = False
                break
            u = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (line_mag ** 2)
            u = max(0, min(1, u))
            ix = x1 + u * (x2 - x1)
            iy = y1 + u * (y2 - y1)
            dist = sqrt((px - ix) ** 2 + (py - iy) ** 2)
            if dist <= size + robot_radius:
                direct_clear = False
                break
        if direct_clear:
            path = [start, goal]
        else:
            # Return empty path and length 0 if no path found
            return {"path_xy": [], "length_m": 0}

    # Calculate path length
    length = 0
    for i in range(len(path) - 1):
        length += sqrt((path[i+1][0] - path[i][0]) ** 2 + (path[i+1][1] - path[i][1]) ** 2)

    return {"path_xy": path, "length_m": length}
