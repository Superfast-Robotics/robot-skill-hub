def solve(task):
    from hub_runtime import run_recipe
    outputs = run_recipe('ruckig-offline-trajectory', task)
    return outputs
