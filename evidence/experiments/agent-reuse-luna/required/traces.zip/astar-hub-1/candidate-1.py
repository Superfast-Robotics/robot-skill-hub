from hub_runtime import run_recipe

def solve(task):
    outputs = run_recipe('pythonrobotics-astar-planner', task)
    return outputs
