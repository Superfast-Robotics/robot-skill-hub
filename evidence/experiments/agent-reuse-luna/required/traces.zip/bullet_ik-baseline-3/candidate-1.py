import sys, math
import numpy as np
import pybullet as p
sys.path.insert(0,'/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=list(map(float,task['joint_angles']))
        for i,v in enumerate(q0): p.resetJointState(robot,i,v)
        target=list(map(float,task['target_xyz']))
        out=p.calculateInverseKinematics(robot,6,target,maxNumIterations=1000,residualThreshold=1e-10,
             jointDamping=[0.01]*7)
        for i,v in enumerate(out[:7]): p.resetJointState(robot,i,v)
        xyz=p.getLinkState(robot,6,computeForwardKinematics=1)[4]
        return {'joint_angles_rad':[float(x) for x in out[:7]],'end_effector_xyz_m':list(map(float,xyz)), 'position_error_m':float(np.linalg.norm(np.array(xyz)-target))}
    finally:p.disconnect(cid)
