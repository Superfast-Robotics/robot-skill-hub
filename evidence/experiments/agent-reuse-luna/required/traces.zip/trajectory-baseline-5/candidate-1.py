import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    a={k:[float(x) for x in task[k]] for k in keys}
    n=len(a['current_position'])
    inp=InputParameter(n)
    for k,v in a.items(): setattr(inp,k,v)
    otg=Ruckig(n)
    traj=Trajectory(n)
    res=otg.calculate(inp,traj)
    if res != Result.Working and res != Result.Finished:
        raise ValueError('Ruckig failed: '+str(res))
    T=float(traj.duration)
    if T>30+1e-9: raise ValueError('duration exceeds limit')
    dt=float(task['dt'])
    # Include all regular samples, followed by exact completion.
    count=int(np.floor(T/dt + 1e-12))
    ts=[i*dt for i in range(count+1)]
    if not ts or ts[-1] < T-1e-12:
        ts.append(T)
    else:
        ts[-1]=T
    if len(ts)<2:
        ts=[0.0,T]
    p=[]; v=[]; acc=[]
    for t in ts:
        pp,vv,aa=traj.at_time(float(t))
        p.append([float(x) for x in pp]); v.append([float(x) for x in vv]); acc.append([float(x) for x in aa])
    # enforce endpoints exactly (Ruckig endpoint eval generally does too)
    p[0]=a['current_position'].copy(); v[0]=a['current_velocity'].copy(); acc[0]=a['current_acceleration'].copy()
    p[-1]=a['target_position'].copy(); v[-1]=a['target_velocity'].copy(); acc[-1]=a['target_acceleration'].copy()
    return {'time_s':ts,'position':p,'velocity':v,'acceleration':acc,'coordinate_type':task['coordinate_type'],'duration_s':T}
