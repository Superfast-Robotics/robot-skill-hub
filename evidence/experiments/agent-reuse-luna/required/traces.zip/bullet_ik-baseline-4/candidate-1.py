import os, sys, math
import numpy as np
import pybullet as p

def solve(task):
    if '/public' not in sys.path: sys.path.append('/public')
    import scene
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],dtype=float)
        target=np.asarray(task['target_xyz'],dtype=float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        ik=p.calculateInverseKinematics(robot,6,target.tolist(),restPoses=q0.tolist(),jointDamping=[0.05]*7,maxNumIterations=500,residualThreshold=1e-10)
        q=np.asarray(ik[:7],dtype=float)
        def fk(qv):
            for i,x in enumerate(qv): p.resetJointState(robot,i,float(x))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
        xyz=fk(q)
        if np.linalg.norm(xyz-target)>0.001:
            from scipy.optimize import least_squares
            res=least_squares(lambda x: fk(x)-target,q,max_nfev=300,ftol=1e-13,xtol=1e-13,gtol=1e-13)
            q=res.x
            xyz=fk(q)
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':xyz.tolist(),'position_error_m':float(np.linalg.norm(xyz-target))}
    finally: p.disconnect(cid)
