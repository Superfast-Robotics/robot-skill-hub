import math, heapq
import numpy as np

def solve(task):
    from hub_runtime import run_recipe
    outputs = run_recipe('pythonrobotics-astar-planner', task)
    r=float(task['robot_radius']); lo,hi=map(float,task['bounds']); bx=by=hi-lo
    start=np.array(task['start'],dtype=float)-lo; goal=np.array(task['goal'],dtype=float)-lo
    obs=np.array(task['obstacles'],dtype=float).reshape((-1,2))-lo
    eps=1e-7
    if not (r+eps < start[0] < bx-r-eps and r+eps < start[1] < by-r-eps and r+eps < goal[0] < bx-r-eps and r+eps < goal[1] < by-r-eps):
        raise ValueError('No path satisfying strict boundary clearance')
    def clear(a,b):
        if min(a[0],b[0]) <= r+eps or max(a[0],b[0]) >= bx-r-eps or min(a[1],b[1]) <= r+eps or max(a[1],b[1]) >= by-r-eps: return False
        if len(obs):
            v=b-a; den=float(v@v); t=np.clip(((obs-a)@v)/den,0,1) if den else np.zeros(len(obs))
            d=obs-(a+t[:,None]*v)
            if np.any(np.einsum('ij,ij->i',d,d) < (r+eps)**2): return False
        return True
    def path_ok(p):
        p=np.asarray(p,float)
        return len(p)>=2 and np.all(np.isfinite(p)) and np.linalg.norm(p[0]-start)<1e-6 and np.linalg.norm(p[-1]-goal)<1e-6 and all(clear(p[i],p[i+1]) for i in range(len(p)-1))
    cand=outputs.get('path_xy') if isinstance(outputs,dict) else None
    path=None
    if cand is not None:
        c=np.asarray(cand,float)-lo
        if len(c)>=2 and np.linalg.norm(c[0]-start)<1e-6 and np.linalg.norm(c[-1]-goal)<1e-6 and path_ok(c): path=c.tolist()
    if path is None and clear(start,goal): path=[start.tolist(),goal.tolist()]
    if path is None:
        for h in (0.25,0.12,0.06):
            x0=r+2*eps; x1=bx-r-2*eps; y0=r+2*eps; y1=by-r-2*eps
            nx=int(math.floor((x1-x0)/h))+1; ny=int(math.floor((y1-y0)/h))+1
            xs=x0+np.arange(nx)*h; ys=y0+np.arange(ny)*h
            blocked=np.zeros((nx,ny),dtype=bool)
            if len(obs):
                for i in range(nx):
                    d=obs[None,:,:]-np.column_stack((np.full(ny,xs[i]),ys))[:,None,:]
                    blocked[i]=np.any(np.einsum('ijk,ijk->ij',d,d) < (r+eps)**2,axis=1)
            def coord(i,j): return np.array([xs[i],ys[j]])
            heap=[]; costs={}; parents={}; closed=set(); goal_parent=None
            si=int(round((start[0]-x0)/h)); sj=int(round((start[1]-y0)/h))
            for i in range(max(0,si-2),min(nx,si+3)):
                for j in range(max(0,sj-2),min(ny,sj+3)):
                    q=coord(i,j); dist=float(np.linalg.norm(q-start))
                    if dist <= 2.0*h+1e-9 and not blocked[i,j] and clear(start,q):
                        key=(i,j); costs[key]=dist; parents[key]=None
                        heapq.heappush(heap,(dist+float(np.linalg.norm(goal-q)),dist,key))
            if not heap: continue
            while heap:
                _,g,(i,j)=heapq.heappop(heap); key=(i,j)
                if key in closed or g>costs.get(key,1e99)+1e-10: continue
                closed.add(key); p=coord(i,j)
                if np.linalg.norm(p-goal)<=2.0*h+1e-9 and clear(p,goal): goal_parent=key; break
                for di,dj in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
                    ii=i+di; jj=j+dj
                    if ii<0 or ii>=nx or jj<0 or jj>=ny or blocked[ii,jj]: continue
                    nk=(ii,jj)
                    if nk in closed: continue
                    q=coord(ii,jj)
                    if not clear(p,q): continue
                    ng=g+float(np.linalg.norm(q-p))
                    if ng+1e-12 < costs.get(nk,1e99):
                        costs[nk]=ng; parents[nk]=key
                        heapq.heappush(heap,(ng+float(np.linalg.norm(goal-q)),ng,nk))
            if goal_parent is not None:
                rev=[]; k=goal_parent
                while k is not None: rev.append(coord(*k).tolist()); k=parents[k]
                rev.reverse(); p=[start.tolist()]+rev+[goal.tolist()]
                simp=[p[0]]; i=0
                while i<len(p)-1:
                    j=len(p)-1
                    while j>i+1 and not clear(np.array(p[i]),np.array(p[j])): j-=1
                    simp.append(p[j]); i=j
                if path_ok(simp): path=simp; break
        if path is None: raise ValueError('No collision-free path found')
    path=[[float(x+lo),float(y+lo)] for x,y in path]
    length=sum(math.dist(path[i],path[i+1]) for i in range(len(path)-1))
    return {'path_xy': path, 'length_m': float(length)}