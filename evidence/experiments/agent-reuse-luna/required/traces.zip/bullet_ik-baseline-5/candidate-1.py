import numpy as np, pybullet as p
from scipy.optimize import least_squares

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        import scene
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],dtype=float)
        target=np.asarray(task['target_xyz'],dtype=float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        def fk(q):
            for j,v in enumerate(q): p.resetJointState(robot,j,float(v))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
        # PyBullet IK initial call
        try:
            sol=np.asarray(p.calculateInverseKinematics(robot,6,target.tolist(),maxNumIterations=500,residualThreshold=1e-10)[:7])
        except Exception:
            sol=q0.copy()
        candidates=[q0,sol]
        bestq=sol.copy(); best=np.linalg.norm(fk(bestq)-target)
        for start in candidates:
            r=least_squares(lambda q: fk(q)-target,start,bounds=(-100,100),max_nfev=400,ftol=1e-12,xtol=1e-12,gtol=1e-12)
            e=np.linalg.norm(fk(r.x)-target)
            if e<best: best=e; bestq=r.x.copy()
        pos=fk(bestq); err=float(np.linalg.norm(pos-target))
        return {'joint_angles_rad':bestq.tolist(),'end_effector_xyz_m':pos.tolist(),'position_error_m':err}
    finally: p.disconnect(cid)