import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals={k:np.asarray(task[k],dtype=float) for k in keys}
    n=len(vals['current_position'])
    inp=InputParameter(n)
    for k,v in vals.items(): setattr(inp,k,v.tolist())
    if np.any(vals['max_velocity']<=0) or np.any(vals['max_acceleration']<=0) or np.any(vals['max_jerk']<=0):
        raise ValueError('limits must be positive')
    otg=Ruckig(n)
    traj=Trajectory(n)
    result=otg.calculate(inp,traj)
    if result<0: raise ValueError('Ruckig could not generate trajectory')
    duration=float(traj.duration)
    if duration>30: raise ValueError('trajectory exceeds 30 seconds')
    dt=float(task['dt'])
    count=max(1,int(np.ceil(duration/dt)))
    times=np.linspace(0.0,duration,count+1)
    positions=[]; velocities=[]; accelerations=[]
    for t in times:
        p,v,a=traj.at_time(float(t))
        positions.append(p); velocities.append(v); accelerations.append(a)
    # preserve exact input boundary states
    positions[0]=vals['current_position'].tolist()
    velocities[0]=vals['current_velocity'].tolist()
    accelerations[0]=vals['current_acceleration'].tolist()
    positions[-1]=vals['target_position'].tolist()
    velocities[-1]=vals['target_velocity'].tolist()
    accelerations[-1]=vals['target_acceleration'].tolist()
    return {'time_s':times.tolist(),'position':positions,'velocity':velocities,'acceleration':accelerations,'coordinate_type':task['coordinate_type'],'duration_s':duration}