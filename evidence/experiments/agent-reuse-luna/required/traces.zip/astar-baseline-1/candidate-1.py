import math, heapq
import numpy as np
from scipy.spatial import cKDTree

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    lo,hi=map(float,task['bounds']); r=float(task['robot_radius'])
    if not (lo < start[0] < hi and lo < start[1] < hi and lo < goal[0] < hi and lo < goal[1] < hi):
        raise ValueError('start and goal must be strictly inside bounds')
    # Integer-sampled boundary points, together with the point obstacles.
    bpts=[]
    for k in range(int(math.ceil(lo)), int(math.floor(hi))+1):
        bpts.extend([(float(k),lo),(float(k),hi),(lo,float(k)),(hi,float(k))])
    obs=np.asarray(list(task['obstacles'])+bpts,dtype=float).reshape((-1,2))
    tree=cKDTree(obs) if len(obs) else None
    def valid_pt(p):
        if not (lo < p[0] < hi and lo < p[1] < hi): return False
        return tree is None or tree.query(p)[0] >= r-1e-9
    def visible(a,b):
        # Entire segment lies inside the open rectangular bounds if endpoints do.
        if not (lo < a[0] < hi and lo < a[1] < hi and lo < b[0] < hi and lo < b[1] < hi): return False
        if tree is None:return True
        d=b-a; L=float(np.linalg.norm(d)); mid=(a+b)*.5
        inds=tree.query_ball_point(mid, L*.5+r+1e-9)
        if inds:
            q=obs[inds]
            if L == 0: ds=np.linalg.norm(q-a,axis=1)
            else:
                t=np.clip(((q-a)@d)/(L*L),0.,1.)
                ds=np.linalg.norm(q-(a+t[:,None]*d),axis=1)
            if np.any(ds < r-1e-9): return False
        return True
    if not valid_pt(start) or not valid_pt(goal): raise ValueError('endpoint is not collision-free')
    if visible(start,goal):
        pts=[start.tolist(),goal.tolist()]
        return {'path_xy':pts,'length_m':float(np.linalg.norm(goal-start))}

    # A* over progressively refined free-space grids. Exact segment checks prevent
    # diagonal corner cutting; endpoint connectors preserve the requested poses.
    for res in (0.2,0.1,0.05,0.025):
        nx=int(math.floor((hi-lo)/res+1e-9))+1
        if nx*nx>3000000: continue
        def xy(node): return np.array([lo+node[0]*res,lo+node[1]*res])
        # Grid nodes strictly inside bounds are potential roadmap vertices.
        def candidates(p):
            ix=int(round((p[0]-lo)/res)); iy=int(round((p[1]-lo)/res))
            rad=2
            out=[]
            for i in range(max(0,ix-rad),min(nx,ix+rad+1)):
                for j in range(max(0,iy-rad),min(nx,iy+rad+1)):
                    q=xy((i,j))
                    if valid_pt(q) and visible(p,q): out.append((i,j))
            return out
        srcs=candidates(start); goals=set(candidates(goal))
        if not srcs or not goals: continue
        gscore={}; parent={}; heap=[]
        for n in srcs:
            c=float(np.linalg.norm(xy(n)-start))
            if c<gscore.get(n,float('inf')):
                gscore[n]=c; parent[n]=None
                heapq.heappush(heap,(c+float(np.linalg.norm(xy(n)-goal)),c,n))
        found=None
        # integer offsets with 8-connectivity
        moves=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
        while heap:
            f,g,n=heapq.heappop(heap)
            if g>gscore.get(n,float('inf'))+1e-12: continue
            if n in goals:
                found=n; break
            p=xy(n)
            for di,dj in moves:
                m=(n[0]+di,n[1]+dj)
                if m[0]<0 or m[1]<0 or m[0]>=nx or m[1]>=nx: continue
                q=xy(m)
                if not valid_pt(q) or not visible(p,q): continue
                ng=g+res*math.hypot(di,dj)
                if ng+1e-12<gscore.get(m,float('inf')):
                    gscore[m]=ng; parent[m]=n
                    heapq.heappush(heap,(ng+float(np.linalg.norm(q-goal)),ng,m))
        if found is None: continue
        nodes=[]; cur=found
        while cur is not None:
            nodes.append(cur); cur=parent[cur]
        nodes.reverse()
        raw=[start]+[xy(n) for n in nodes]+[goal]
        # Greedily shortcut while retaining continuous collision safety.
        simp=[raw[0]]; i=0
        while i<len(raw)-1:
            j=len(raw)-1
            while j>i+1 and not visible(raw[i],raw[j]): j-=1
            simp.append(raw[j]); i=j
        arr=np.asarray(simp)
        length=float(np.linalg.norm(np.diff(arr,axis=0),axis=1).sum())
        return {'path_xy':arr.tolist(),'length_m':length}
    raise ValueError('no collision-free path found')