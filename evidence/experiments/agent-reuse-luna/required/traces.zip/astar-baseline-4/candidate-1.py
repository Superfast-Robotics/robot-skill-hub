import math, heapq
import numpy as np
from scipy.spatial import cKDTree

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    bx,by=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    eps=1e-8
    if not (0 < start[0] < bx and 0 < start[1] < by and 0 < goal[0] < bx and 0 < goal[1] < by):
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    # The rectangular boundary is sampled at integer coordinates; keeping the
    # whole path outside its radius-offset rectangle is a conservative guarantee.
    lo=r+eps; hi_x=bx-r-eps; hi_y=by-r-eps
    tree=cKDTree(obs) if len(obs) else None
    def valid_point(p):
        if not (p[0]>0 and p[0]<bx and p[1]>0 and p[1]<by): return False
        # Actual walls are at least as restrictive as the sampled boundary.
        if p[0] <= r+eps or p[1] <= r+eps or p[0] >= bx-r-eps or p[1] >= by-r-eps: return False
        if tree is not None and tree.query(p,k=1)[0] <= r+eps: return False
        return True
    def clear(a,b):
        # Convex inset guarantees continuous clearance from every map edge.
        if min(a[0],b[0]) <= r+eps or max(a[0],b[0]) >= bx-r-eps or min(a[1],b[1]) <= r+eps or max(a[1],b[1]) >= by-r-eps: return False
        if tree is None: return True
        mid=(a+b)*0.5; half=float(np.linalg.norm(b-a))*0.5
        cand=tree.query_ball_point(mid, r+half+eps)
        if not cand: return True
        q=obs[cand]; d=b-a
        den=float(np.dot(d,d))
        if den==0: return bool(np.all(np.linalg.norm(q-a,axis=1)>r+eps))
        t=np.clip(((q-a)@d)/den,0.,1.)
        closest=a+t[:,None]*d
        return bool(np.all(np.linalg.norm(q-closest,axis=1)>r+eps))
    if not valid_point(start) or not valid_point(goal):
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    if clear(start,goal):
        pp=[start.tolist(),goal.tolist()]
        return {'path_xy':pp,'length_m':float(np.linalg.norm(goal-start))}
    # Fine regular lattice, with exact endpoints connected to nearby lattice nodes.
    step=0.1
    nx=int(math.floor(bx/step+1e-9))+1; ny=int(math.floor(by/step+1e-9))+1
    xs=np.arange(nx,dtype=float)*step; ys=np.arange(ny,dtype=float)*step
    X,Y=np.meshgrid(xs,ys)
    pts=np.column_stack((X.ravel(),Y.ravel()))
    free=(pts[:,0]>r+eps)&(pts[:,0]<bx-r-eps)&(pts[:,1]>r+eps)&(pts[:,1]<by-r-eps)
    if tree is not None:
        free &= tree.query(pts,k=1)[0] > r+eps
    free=free.reshape((ny,nx))
    def index_near(p):
        ix=int(round(p[0]/step)); iy=int(round(p[1]/step))
        out=[]
        for y in range(max(0,iy-2),min(ny,iy+3)):
            for x in range(max(0,ix-2),min(nx,ix+3)):
                if free[y,x]:
                    q=np.array([x*step,y*step])
                    if clear(p,q): out.append((y*nx+x,float(np.linalg.norm(q-p))))
        return out
    sconn=index_near(start); gconn=dict(index_near(goal))
    if not sconn or not gconn:
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    n=nx*ny; inf=float('inf'); dist=np.full(n,inf); parent=np.full(n,-2,dtype=np.int64)
    heap=[]
    for idx,cost in sconn:
        if cost<dist[idx]:
            dist[idx]=cost; parent[idx]=-1; heapq.heappush(heap,(cost+np.linalg.norm(np.array([idx%nx*step,idx//nx*step])-goal),cost,idx))
    goal_id=-1; best=inf
    moves=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
    while heap:
        f,g,u=heapq.heappop(heap)
        if g!=dist[u]: continue
        if f>=best: break
        if u in gconn:
            vxy=np.array([(u%nx)*step,(u//nx)*step]); total=g+gconn[u]
            if total<best and clear(vxy,goal): best=total; goal_id=u
        y,x=divmod(u,nx); a=np.array([x*step,y*step])
        for dx,dy in moves:
            xx=x+dx; yy=y+dy
            if xx<0 or xx>=nx or yy<0 or yy>=ny or not free[yy,xx]: continue
            v=yy*nx+xx
            b=np.array([xx*step,yy*step])
            ng=g+step*(math.sqrt(2) if dx and dy else 1.)
            if ng+1e-12<dist[v] and clear(a,b):
                dist[v]=ng; parent[v]=u
                h=math.hypot(goal[0]-b[0],goal[1]-b[1])
                heapq.heappush(heap,(ng+h,ng,v))
    if goal_id<0:
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    rev=[]; u=goal_id
    while u>=0:
        rev.append([(u%nx)*step,(u//nx)*step]); u=int(parent[u])
    rev.reverse(); raw=[start]+[np.asarray(p) for p in rev]+[goal]
    # Greedy line-of-sight shortcutting preserves exact continuous clearance.
    smooth=[raw[0]]; i=0
    while i<len(raw)-1:
        j=len(raw)-1
        while j>i+1 and not clear(raw[i],raw[j]): j-=1
        smooth.append(raw[j]); i=j
    path=[p.tolist() for p in smooth]
    length=sum(float(np.linalg.norm(smooth[i+1]-smooth[i])) for i in range(len(smooth)-1))
    return {'path_xy':path,'length_m':length}
