import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals={k:[float(x) for x in task[k]] for k in keys}
    n=len(vals['current_position'])
    inp=InputParameter(n)
    for k,v in vals.items(): setattr(inp,k,v)
    r=Ruckig(n); tr=Trajectory(n)
    result=r.calculate(inp,tr)
    if result == Result.ErrorInvalidInput:
        raise ValueError('Invalid trajectory input')
    T=float(tr.duration)
    dt=float(task['dt'])
    if T <= 1e-12:
        times=[0.0,0.0]
    else:
        count=int(np.ceil(T/dt))
        times=np.linspace(0.0,T,count+1).tolist()
    pos=[]; vel=[]; acc=[]
    for t in times:
        p,v,a=tr.at_time(t)
        pos.append([float(x) for x in p]); vel.append([float(x) for x in v]); acc.append([float(x) for x in a])
    # Pin endpoints exactly as supplied, avoiding tiny solver roundoff.
    for group,k in [(pos,'target_position'),(vel,'target_velocity'),(acc,'target_acceleration')]:
        group[-1]=vals[k].copy()
    pos[0]=vals['current_position'].copy(); vel[0]=vals['current_velocity'].copy(); acc[0]=vals['current_acceleration'].copy()
    return {'time_s':times,'position':pos,'velocity':vel,'acceleration':acc,'coordinate_type':task['coordinate_type'],'duration_s':T}
