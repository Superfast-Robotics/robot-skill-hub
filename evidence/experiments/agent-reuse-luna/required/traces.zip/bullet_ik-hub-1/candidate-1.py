def solve(task):
    from hub_runtime import run_recipe
    outputs = run_recipe('pybullet-ik-skill', task)
    return outputs
