import os, sys, math
import numpy as np
import pybullet as p
sys.path.insert(0, '/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],float)
        target=np.asarray(task['target_xyz'],float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        lo=[-math.pi]*7; hi=[math.pi]*7; ranges=[2*math.pi]*7
        try:
            sol=p.calculateInverseKinematics(robot,6,targetPosition=target.tolist(),lowerLimits=lo,upperLimits=hi,jointRanges=ranges,restPoses=q0.tolist(),jointDamping=[0.01]*7,maxNumIterations=1000,residualThreshold=1e-8)
        except TypeError:
            sol=p.calculateInverseKinematics(robot,6,target.tolist(),maxNumIterations=1000,residualThreshold=1e-8)
        q=np.asarray(sol[:7],float)
        for i,x in enumerate(q): p.resetJointState(robot,i,float(x))
        pos=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
        err=float(np.linalg.norm(pos-target))
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':pos.tolist(),'position_error_m':err}
    finally: p.disconnect(cid)
