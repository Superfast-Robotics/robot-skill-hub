import sys, numpy as np, pybullet as p
sys.path.insert(0,'/public'); import scene

def solve(task):
 cid=p.connect(p.DIRECT)
 try:
  b=scene.create_arm(p); q0=task['joint_angles']; t=task['target_xyz']
  for i,q in enumerate(q0):p.resetJointState(b,i,q)
  print('start',p.getLinkState(b,6,computeForwardKinematics=True)[4],file=sys.stderr)
  for mode in range(2):
   if mode==0: s=p.calculateInverseKinematics(b,6,t,maxNumIterations=1000,residualThreshold=1e-9)
   else:s=p.calculateInverseKinematics(b,6,t,lowerLimits=[-3.14]*7,upperLimits=[3.14]*7,jointRanges=[6.28]*7,restPoses=q0,maxNumIterations=1000,residualThreshold=1e-9)
   for i,q in enumerate(s):p.resetJointState(b,i,q)
   pos=p.getLinkState(b,6,computeForwardKinematics=True)[4]; print('mode',mode,s,pos,np.linalg.norm(np.array(pos)-t),file=sys.stderr)
  q=list(s); pos=list(pos)
  return {'joint_angles_rad':q,'end_effector_xyz_m':pos,'position_error_m':float(np.linalg.norm(np.array(pos)-t))}
 finally:p.disconnect(cid)
