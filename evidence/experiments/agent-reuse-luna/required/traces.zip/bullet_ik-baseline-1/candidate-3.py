import os,sys,math
import numpy as np, pybullet as p
from scipy.optimize import least_squares
sys.path.insert(0,'/public'); import scene

def solve(task):
 cid=p.connect(p.DIRECT)
 try:
  b=scene.create_arm(p); q0=np.array(task['joint_angles']); t=np.array(task['target_xyz'])
  def fk(q):
   for j,x in enumerate(q): p.resetJointState(b,j,float(x))
   return np.array(p.getLinkState(b,6,computeForwardKinematics=True)[4])
  res=least_squares(lambda q:fk(q)-t,q0,method='lm',max_nfev=3000,ftol=1e-14,xtol=1e-14,gtol=1e-14)
  pos=fk(res.x); print('DEBUG',res.x,pos,np.linalg.norm(pos-t),res.message,file=sys.stderr)
  return {'joint_angles_rad':res.x.tolist(),'end_effector_xyz_m':pos.tolist(),'position_error_m':float(np.linalg.norm(pos-t))}
 finally:p.disconnect(cid)
