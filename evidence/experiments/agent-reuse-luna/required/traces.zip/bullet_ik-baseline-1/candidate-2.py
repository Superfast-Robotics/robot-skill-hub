import os, sys, math
import numpy as np
import pybullet as p
from scipy.optimize import least_squares
sys.path.insert(0, '/public'); import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],float); target=np.asarray(task['target_xyz'],float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        def fk(q):
            for i,x in enumerate(q): p.resetJointState(robot,i,float(x))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4],float)
        def fun(q): return np.r_[fk(q)-target, 1e-5*(q-q0)]
        r=least_squares(fun,q0,method='trf',max_nfev=1500,ftol=1e-13,xtol=1e-13,gtol=1e-13)
        q=r.x
        pos=fk(q); err=float(np.linalg.norm(pos-target))
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':pos.tolist(),'position_error_m':err}
    finally: p.disconnect(cid)
