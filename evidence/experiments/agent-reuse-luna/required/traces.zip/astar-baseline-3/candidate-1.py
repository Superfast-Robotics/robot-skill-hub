import numpy as np, math, heapq
from scipy.spatial import cKDTree

def solve(task):
    s=np.asarray(task['start'],dtype=float); g=np.asarray(task['goal'],dtype=float)
    lo,hi=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    if not (lo < s[0] < hi and lo < s[1] < hi and lo < g[0] < hi and lo < g[1] < hi):
        return {'path_xy': [], 'length_m': 0.0}
    # Boundary is represented by its specified integer-sampled points.
    ints=np.arange(math.ceil(lo), math.floor(hi)+1, dtype=float)
    if len(ints):
        bpts=np.vstack((np.column_stack((ints,np.full(len(ints),lo))),
                        np.column_stack((ints,np.full(len(ints),hi))),
                        np.column_stack((np.full(len(ints),lo),ints)),
                        np.column_stack((np.full(len(ints),hi),ints))))
    else: bpts=np.empty((0,2))
    pts=np.vstack((obs,bpts)) if len(obs) or len(bpts) else np.empty((0,2))
    tree=cKDTree(pts) if len(pts) else None
    R=r+1e-9
    def point_ok(p):
        return (lo < p[0] < hi and lo < p[1] < hi and
                (tree is None or tree.query(p)[0] >= R))
    def segment_ok(a,b):
        if not (lo < a[0] < hi and lo < a[1] < hi and lo < b[0] < hi and lo < b[1] < hi): return False
        if tree is None:return True
        d=b-a; L2=float(d@d)
        mid=(a+b)*.5
        cand=tree.query_ball_point(mid, R+math.sqrt(L2)*.5+1e-10)
        if not cand:return True
        q=pts[cand]-a
        if L2 <= 1e-24: ds=np.einsum('ij,ij->i',q,q)
        else:
            t=np.clip(q@d/L2,0.0,1.0)
            v=q-t[:,None]*d
            ds=np.einsum('ij,ij->i',v,v)
        return bool(np.all(ds >= R*R))
    if not point_ok(s) or not point_ok(g):
        return {'path_xy': [], 'length_m': 0.0}
    if segment_ok(s,g):
        path=[s,g]
    else:
        step=0.1
        n=int(math.floor((hi-lo)/step+1e-9))
        axis=lo+step*np.arange(1,n,dtype=float)
        # Keep strictly interior even in the presence of floating point rounding.
        axis=axis[(axis>lo+1e-10)&(axis<hi-1e-10)]
        nx=len(axis); ny=nx
        if nx==0:return {'path_xy': [], 'length_m': 0.0}
        X,Y=np.meshgrid(axis,axis,indexing='ij')
        grid=np.column_stack((X.ravel(),Y.ravel()))
        if tree is None: safe=np.ones(len(grid),dtype=bool)
        else: safe=tree.query(grid,k=1)[0] >= R
        safe=safe.reshape((nx,ny))
        # Virtual endpoint attachment radius accommodates arbitrary endpoint phase.
        attach=0.51
        start_candidates=[]; goal_candidates=[]
        for p,arr in ((s,start_candidates),(g,goal_candidates)):
            ix0=max(0,int(np.searchsorted(axis,p[0]-attach,side='left')))
            ix1=min(nx,int(np.searchsorted(axis,p[0]+attach,side='right')))
            iy0=max(0,int(np.searchsorted(axis,p[1]-attach,side='left')))
            iy1=min(ny,int(np.searchsorted(axis,p[1]+attach,side='right')))
            for ix in range(ix0,ix1):
                for iy in range(iy0,iy1):
                    if safe[ix,iy]:
                        q=np.array([axis[ix],axis[iy]])
                        if np.linalg.norm(q-p)<=attach+1e-10 and segment_ok(p,q): arr.append((ix,iy))
        if not start_candidates or not goal_candidates:
            return {'path_xy': [], 'length_m': 0.0}
        goalset=set(goal_candidates)
        N=nx*ny
        inf=float('inf'); dist=np.full(N,inf); parent=np.full(N,-2,dtype=np.int64)
        heap=[]
        for ix,iy in start_candidates:
            k=ix*ny+iy; cost=float(np.linalg.norm(grid[k]-s))
            if cost<dist[k]:
                dist[k]=cost; parent[k]=-1
                heapq.heappush(heap,(cost+float(np.linalg.norm(grid[k]-g)),cost,k))
        found=-1
        moves=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
        while heap:
            f,du,k=heapq.heappop(heap)
            if du!=dist[k]:continue
            ix,iy=divmod(k,ny)
            if (ix,iy) in goalset and segment_ok(grid[k],g):
                found=k;break
            a=grid[k]
            for dx,dy in moves:
                jx=ix+dx; jy=iy+dy
                if jx<0 or jx>=nx or jy<0 or jy>=ny or not safe[jx,jy]: continue
                j=jx*ny+jy; b=grid[j]
                if not segment_ok(a,b):continue
                nd=du+step*(math.sqrt(2) if dx and dy else 1.0)
                if nd+1e-12<dist[j]:
                    dist[j]=nd;parent[j]=k
                    heapq.heappush(heap,(nd+float(np.linalg.norm(b-g)),nd,j))
        if found<0:return {'path_xy': [], 'length_m': 0.0}
        rev=[]; k=found
        while k>=0:
            rev.append(grid[k].copy()); k=int(parent[k])
        rev.reverse()
        # Remove grid stair-steps with collision-checked line-of-sight shortcuts.
        raw=[s]+rev+[g]
        path=[raw[0]]; i=0
        while i<len(raw)-1:
            j=len(raw)-1
            while j>i+1 and not segment_ok(raw[i],raw[j]): j-=1
            path.append(raw[j]); i=j
    # Convert to plain numerical JSON-compatible values and report polyline length.
    result=[[float(p[0]),float(p[1])] for p in path]
    length=sum(math.hypot(result[i+1][0]-result[i][0],result[i+1][1]-result[i][1]) for i in range(len(result)-1))
    return {'path_xy':result,'length_m':float(length)}