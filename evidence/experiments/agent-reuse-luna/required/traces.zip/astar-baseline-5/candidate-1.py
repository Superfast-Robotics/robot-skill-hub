def solve(task):
    import math, heapq
    import numpy as np
    from scipy.spatial import cKDTree

    start = np.asarray(task['start'], dtype=float)
    goal = np.asarray(task['goal'], dtype=float)
    W, H = map(float, task['bounds'])
    r = float(task['robot_radius'])
    if not (0 < start[0] < W and 0 < start[1] < H and 0 < goal[0] < W and 0 < goal[1] < H):
        return {'path_xy': [start.tolist(), goal.tolist()], 'length_m': float(np.linalg.norm(goal-start))}
    obs = np.asarray(task['obstacles'], dtype=float).reshape((-1,2))
    # Integer-sampled perimeter points, together with the supplied point obstacles.
    boundary=[]
    for x in range(int(math.floor(W))+1):
        boundary.extend([[float(x),0.0],[float(x),H]])
    for y in range(int(math.floor(H))+1):
        boundary.extend([[0.0,float(y)],[W,float(y)]])
    points = np.vstack([obs, np.asarray(boundary, dtype=float)]) if len(obs) else np.asarray(boundary,dtype=float)
    tree = cKDTree(points)
    clearance = r + 1e-8

    def clear(a,b):
        mid=(a+b)*0.5
        half=float(np.linalg.norm(b-a))*0.5
        ids=tree.query_ball_point(mid, clearance+half+1e-10)
        if not ids: return True
        q=points[ids]
        v=b-a
        vv=float(v@v)
        if vv <= 1e-28:
            ds=np.linalg.norm(q-a,axis=1)
        else:
            t=np.clip(((q-a)@v)/vv,0.0,1.0)
            ds=np.linalg.norm(q-(a+t[:,None]*v),axis=1)
        return bool(np.all(ds >= clearance))

    if not clear(start,start) or not clear(goal,goal):
        # The requested endpoints themselves are in collision; retain a numerical response.
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    h=0.1
    nx=int(round(W/h))+1; ny=int(round(H/h))+1
    xs=np.arange(nx,dtype=float)*h; ys=np.arange(ny,dtype=float)*h
    # Actual bounds should be within floating point tolerance.
    X,Y=np.meshgrid(xs,ys)
    coords=np.column_stack((X.ravel(),Y.ravel()))
    inside=(coords[:,0]>0)&(coords[:,0]<W)&(coords[:,1]>0)&(coords[:,1]<H)
    d,_=tree.query(coords,k=1)
    free=inside & (d >= clearance)
    N=len(coords); sid=N; gid=N+1
    allcoords=np.vstack((coords,start,goal))
    # Connect endpoint to nearby free grid nodes; segment validation is exact.
    def endpoint_links(p):
        # radius encompasses at least the nearest lattice points, and gives a few alternatives
        lo=np.floor(p/h).astype(int)
        ix0=max(0,lo[0]-4); ix1=min(nx-1,lo[0]+4)
        iy0=max(0,lo[1]-4); iy1=min(ny-1,lo[1]+4)
        links=[]
        for iy in range(iy0,iy1+1):
            for ix in range(ix0,ix1+1):
                idx=iy*nx+ix
                if free[idx] and np.linalg.norm(coords[idx]-p) <= 0.42 and clear(p,coords[idx]):
                    links.append(idx)
        return links
    slinks=endpoint_links(start); glinks=endpoint_links(goal)
    goal_set=set(glinks)
    # Direct segment is a possible immediate solution.
    if clear(start,goal):
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    if not slinks or not glinks:
        # Smaller lattice catches narrow local access configurations.
        pass
    inf=float('inf'); dist=np.full(N+2,inf); parent=np.full(N+2,-1,dtype=np.int64)
    dist[sid]=0.0
    heap=[(float(np.linalg.norm(start-goal)),sid)]
    closed=np.zeros(N+2,dtype=bool)
    edge_cache={}
    moves=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
    found=False
    while heap:
        f,u=heapq.heappop(heap)
        if closed[u]: continue
        if u==gid:
            found=True; break
        closed[u]=True
        if u==sid:
            candidates=slinks
        elif u==gid:
            continue
        else:
            iy,ix=divmod(u,nx)
            candidates=[]
            for dx,dy in moves:
                xx=ix+dx; yy=iy+dy
                if 0<=xx<nx and 0<=yy<ny:
                    v=yy*nx+xx
                    if free[v]: candidates.append(v)
            if u in goal_set: candidates.append(gid)
        for v in candidates:
            if closed[v]: continue
            if v==gid:
                a=goal; b=coords[u] if u<N else start
            elif u==sid:
                a=start; b=coords[v]
            else:
                a=coords[u]; b=coords[v]
            key=(u,v) if u<v else (v,u)
            ok=edge_cache.get(key)
            if ok is None:
                ok=clear(a,b); edge_cache[key]=ok
            if not ok: continue
            w=float(np.linalg.norm(a-b))
            nd=dist[u]+w
            if nd+1e-12 < dist[v]:
                dist[v]=nd; parent[v]=u
                heur=float(np.linalg.norm((goal if v==gid else coords[v])-goal))
                heapq.heappush(heap,(nd+heur,v))
    if not found:
        return {'path_xy':[start.tolist(),goal.tolist()], 'length_m':float(np.linalg.norm(goal-start))}
    ids=[]; cur=gid
    while cur!=-1:
        ids.append(cur); cur=int(parent[cur])
    ids=ids[::-1]
    path=[allcoords[i].copy() for i in ids]
    # Greedy string-pulling preserves exact continuous clearance.
    simp=[path[0]]; i=0
    while i < len(path)-1:
        j=len(path)-1
        while j>i+1 and not clear(path[i],path[j]): j-=1
        simp.append(path[j]); i=j
    # Remove duplicate consecutive vertices and calculate length.
    out=[]
    for p in simp:
        if not out or np.linalg.norm(p-out[-1])>1e-10: out.append(p)
    if len(out)==1: out.append(out[0].copy())
    length=sum(float(np.linalg.norm(out[i+1]-out[i])) for i in range(len(out)-1))
    return {'path_xy':[p.tolist() for p in out], 'length_m':length}
