def solve(task):
    from hub_runtime import run_recipe
    outputs = run_recipe('pythonrobotics-astar-planner', task)
    return outputs
