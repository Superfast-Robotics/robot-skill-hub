import pybullet as p, sys, numpy as np
sys.path.insert(0,'/public'); import scene

def solve(task):
 c=p.connect(p.DIRECT); r=scene.create_arm(p); init=task['joint_angles']; [p.resetJointState(r,j,x) for j,x in enumerate(init)]; t=task['target_xyz']; q=p.calculateInverseKinematics(r,6,t,maxNumIterations=1000,residualThreshold=1e-9); [p.resetJointState(r,j,x) for j,x in enumerate(q[:7])]; xyz=p.getLinkState(r,6,computeForwardKinematics=True)[4]; print('Q',q,'XYZ',xyz,'target',t,'err',np.linalg.norm(np.array(xyz)-t)); p.disconnect(c); return {'joint_angles_rad':list(q[:7]),'end_effector_xyz_m':list(xyz),'position_error_m':float(np.linalg.norm(np.array(xyz)-t))}
