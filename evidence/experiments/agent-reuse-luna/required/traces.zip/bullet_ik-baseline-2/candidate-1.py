import pybullet as p, sys, json, numpy as np
sys.path.insert(0,'/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        init=np.asarray(task['joint_angles'],dtype=float)
        for j,x in enumerate(init): p.resetJointState(robot,j,float(x))
        target=list(map(float,task['target_xyz']))
        lower=[-100.]*7; upper=[100.]*7; ranges=[200.]*7
        sol=p.calculateInverseKinematics(robot,6,target,lowerLimits=lower,upperLimits=upper,jointRanges=ranges,restPoses=init.tolist(),maxNumIterations=1000,residualThreshold=1e-9)
        q=np.asarray(sol[:7])
        for j,x in enumerate(q): p.resetJointState(robot,j,float(x))
        xyz=np.array(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':xyz.tolist(),'position_error_m':float(np.linalg.norm(xyz-target))}
    finally: p.disconnect(cid)
