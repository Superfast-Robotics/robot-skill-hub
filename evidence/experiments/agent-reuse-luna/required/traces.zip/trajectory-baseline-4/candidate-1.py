import math
import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals={k:[float(x) for x in task[k]] for k in keys}
    n=len(vals['current_position'])
    inp=InputParameter(n)
    for k,v in vals.items(): setattr(inp,k,v)
    # Symmetric limits per requested max magnitudes
    inp.min_velocity=[-abs(x) for x in vals['max_velocity']]
    inp.min_acceleration=[-abs(x) for x in vals['max_acceleration']]
    otg=Ruckig(n)
    traj=Trajectory(n)
    result=otg.calculate(inp,traj)
    if result != Result.Working and result != Result.Finished:
        raise ValueError('Ruckig could not generate a feasible trajectory')
    dur=float(traj.duration)
    dt=float(task['dt'])
    if dur <= 1e-12:
        dur=dt
        times=np.array([0.,dur])
    else:
        # Use dt-grid and exact final point, preserving maximum sample spacing.
        count=int(math.ceil(dur/dt))
        times=np.linspace(0.0,dur,count+1)
    pos=[]; vel=[]; acc=[]
    for t in times:
        p,v,a=traj.at_time(float(t))
        pos.append([float(x) for x in p]); vel.append([float(x) for x in v]); acc.append([float(x) for x in a])
    if float(traj.duration) <= 1e-12:
        pos[-1]=list(vals['target_position']);vel[-1]=list(vals['target_velocity']);acc[-1]=list(vals['target_acceleration'])
    # snap end values to the specified boundary states to remove numerical residue
    else:
        pos[-1]=list(vals['target_position']);vel[-1]=list(vals['target_velocity']);acc[-1]=list(vals['target_acceleration'])
    pos[0]=list(vals['current_position']);vel[0]=list(vals['current_velocity']);acc[0]=list(vals['current_acceleration'])
    return {'time_s':[float(x) for x in times], 'position':pos, 'velocity':vel, 'acceleration':acc, 'coordinate_type':task['coordinate_type'], 'duration_s':float(dur)}