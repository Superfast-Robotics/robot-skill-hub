import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals={k:np.asarray(task[k],dtype=float) for k in keys}
    n=len(vals['current_position'])
    if any(v.shape != (n,) for v in vals.values()): raise ValueError('inconsistent axis lengths')
    if np.any(vals['max_velocity']<=0) or np.any(vals['max_acceleration']<=0) or np.any(vals['max_jerk']<=0): raise ValueError('limits must be positive')
    dt=float(task['dt'])
    inp=InputParameter(n)
    for src,dst in [('current_position','current_position'),('current_velocity','current_velocity'),('current_acceleration','current_acceleration'),('target_position','target_position'),('target_velocity','target_velocity'),('target_acceleration','target_acceleration'),('max_velocity','max_velocity'),('max_acceleration','max_acceleration'),('max_jerk','max_jerk')]:
        setattr(inp,dst,vals[src].tolist())
    otg=Ruckig(n)
    traj=Trajectory(n)
    result=otg.calculate(inp,traj)
    if result < 0: raise ValueError('Ruckig could not generate a valid trajectory')
    duration=float(traj.duration)
    if duration>30+1e-9: raise ValueError('trajectory exceeds 30 seconds')
    if duration <= 1e-12:
        times=[0.,0.]
    else:
        count=int(np.floor(duration/dt+1e-12))
        times=[i*dt for i in range(count+1)]
        if duration-times[-1] > 1e-10: times.append(duration)
        else: times[-1]=duration
        if len(times)<2: times=[0.,duration]
    if len(times)>3000: raise ValueError('too many samples')
    ps=[];vs=[];acs=[]
    for t in times:
        p,v,a=traj.at_time(float(t))
        ps.append(list(map(float,p)));vs.append(list(map(float,v)));acs.append(list(map(float,a)))
    # Explicitly preserve boundary values against library roundoff.
    ps[0]=vals['current_position'].tolist(); vs[0]=vals['current_velocity'].tolist(); acs[0]=vals['current_acceleration'].tolist()
    ps[-1]=vals['target_position'].tolist(); vs[-1]=vals['target_velocity'].tolist(); acs[-1]=vals['target_acceleration'].tolist()
    return {'time_s':times,'position':ps,'velocity':vs,'acceleration':acs,'coordinate_type':task['coordinate_type'],'duration_s':duration}
