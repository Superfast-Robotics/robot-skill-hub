import math, heapq
import numpy as np

def solve(task):
    start = np.asarray(task['start'], dtype=float)
    goal = np.asarray(task['goal'], dtype=float)
    bounds = task['bounds']
    lo, hi = float(bounds[0]), float(bounds[1])
    rad = float(task['robot_radius'])
    obs = np.asarray(task['obstacles'], dtype=float).reshape((-1, 2))
    # Strictly maintain a small numerical clearance beyond the requested radius.
    clearance = rad + 1e-7
    margin = clearance + 1e-7
    if (np.any(start <= lo + margin) or np.any(start >= hi - margin) or
        np.any(goal <= lo + margin) or np.any(goal >= hi - margin)):
        return {'path_xy': [], 'length_m': 0.0}
    if len(obs):
        if np.any(np.sum((obs-start)**2, axis=1) <= clearance**2) or np.any(np.sum((obs-goal)**2, axis=1) <= clearance**2):
            return {'path_xy': [], 'length_m': 0.0}
    if np.array_equal(start, goal):
        return {'path_xy': [start.tolist(), goal.tolist()], 'length_m': 0.0}

    def seg_clear(a, b):
        d = b-a
        dd = float(d@d)
        if len(obs):
            t = np.clip(((obs-a)@d)/dd, 0.0, 1.0) if dd > 0 else np.zeros(len(obs))
            q = a + t[:,None]*d
            if np.any(np.sum((obs-q)**2, axis=1) <= clearance**2):
                return False
        # The inset rectangle is convex, so endpoint checks suffice.
        return (np.all(a > lo+margin) and np.all(a < hi-margin) and
                np.all(b > lo+margin) and np.all(b < hi-margin))

    route = None
    for step in (0.2, 0.1, 0.05):
        low, high = lo+margin, hi-margin
        xs = np.arange(low, high + step*0.25, step)
        ys = np.arange(low, high + step*0.25, step)
        xs = xs[xs < high]
        ys = ys[ys < high]
        nx, ny = len(xs), len(ys)
        if nx == 0 or ny == 0: continue
        X, Y = np.meshgrid(xs, ys, indexing='ij')
        valid = np.ones((nx,ny), dtype=bool)
        if len(obs):
            # Rasterize forbidden centers in chunks to limit temporary memory.
            pts = np.column_stack((X.ravel(),Y.ravel()))
            vv = np.ones(len(pts), dtype=bool)
            for k in range(0, len(pts), 20000):
                p = pts[k:k+20000]
                ds = p[:,None,:]-obs[None,:,:]
                vv[k:k+len(p)] = np.all(np.sum(ds*ds,axis=2) > clearance**2, axis=1)
            valid = vv.reshape((nx,ny))
        # Endpoint connector candidates, selected with increasing reach.
        def candidates(p):
            ii, jj = np.where(valid)
            if len(ii)==0: return []
            dd = (xs[ii]-p[0])**2 + (ys[jj]-p[1])**2
            order = np.argsort(dd)
            out=[]
            for z in order:
                i,j=int(ii[z]),int(jj[z])
                if dd[z] > (max(0.65, 4*step))**2: break
                q=np.array([xs[i],ys[j]])
                if seg_clear(p,q): out.append((i,j,math.sqrt(float(dd[z]))))
                if len(out)>=32: break
            return out
        sc, gc = candidates(start), candidates(goal)
        if not sc or not gc: continue
        # A* over 8-connected grid; every traversed segment is checked continuously.
        dirs=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
        dist=np.full((nx,ny), np.inf)
        parent=np.full((nx,ny,2), -1, dtype=np.int32)
        heap=[]
        for i,j,cost in sc:
            if cost < dist[i,j]:
                dist[i,j]=cost
                heapq.heappush(heap,(cost+math.hypot(xs[i]-goal[0],ys[j]-goal[1]),cost,i,j))
        goals={(i,j):c for i,j,c in gc}
        best=math.inf; bestnode=None
        while heap:
            f,g,i,j=heapq.heappop(heap)
            if g != dist[i,j]: continue
            if f >= best: break
            if (i,j) in goals:
                val=g+goals[(i,j)]
                if val < best: best=val; bestnode=(i,j)
            a=np.array([xs[i],ys[j]])
            for di,dj in dirs:
                u,v=i+di,j+dj
                if u<0 or u>=nx or v<0 or v>=ny or not valid[u,v]: continue
                b=np.array([xs[u],ys[v]])
                ng=g+math.hypot(b[0]-a[0],b[1]-a[1])
                if ng+1e-12 < dist[u,v] and seg_clear(a,b):
                    dist[u,v]=ng
                    parent[u,v]=[i,j]
                    h=math.hypot(xs[u]-goal[0],ys[v]-goal[1])
                    heapq.heappush(heap,(ng+h,ng,u,v))
        if bestnode is not None:
            rev=[]; cur=bestnode
            while cur is not None:
                i,j=cur; rev.append([xs[i],ys[j]])
                pi,pj=parent[i,j]
                cur=None if pi<0 else (int(pi),int(pj))
            rev.reverse()
            route=[start.tolist()]+rev+[goal.tolist()]
            # Greedy visibility shortcutting, retaining only continuously clear segments.
            pts=[np.asarray(p,float) for p in route]
            simp=[pts[0]]; i=0
            while i<len(pts)-1:
                j=len(pts)-1
                while j>i+1 and not seg_clear(pts[i],pts[j]): j-=1
                simp.append(pts[j]); i=j
            route=[p.tolist() for p in simp]
            # Defensive validation of all output segments.
            if all(seg_clear(np.asarray(a),np.asarray(b)) for a,b in zip(route[:-1],route[1:])):
                break
            route=None
    if route is None:
        return {'path_xy': [], 'length_m': 0.0}
    length=sum(math.dist(a,b) for a,b in zip(route[:-1],route[1:]))
    return {'path_xy': route, 'length_m': float(length)}