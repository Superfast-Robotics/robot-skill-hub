import math, sys
import numpy as np
import pybullet as p
sys.path.insert(0,'/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],dtype=float)
        target=np.asarray(task['target_xyz'],dtype=float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        lo=[-math.pi]*7; hi=[math.pi]*7; ranges=[2*math.pi]*7
        best=None
        # Try null-space IK seeded using given configuration, then refine by local Jacobian.
        for seed in [q0, np.zeros(7)]:
            for i,q in enumerate(seed): p.resetJointState(robot,i,float(q))
            res=p.calculateInverseKinematics(robot,6,target.tolist(),lowerLimits=lo,upperLimits=hi,jointRanges=ranges,restPoses=seed.tolist(),maxNumIterations=300,residualThreshold=1e-8)
            q=np.asarray(res[:7],float)
            for i,v in enumerate(q): p.resetJointState(robot,i,float(v))
            # Finite difference LM refinement, preserving the unrestricted revolute joint values.
            for it in range(200):
                xyz=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
                err=target-xyz
                en=np.linalg.norm(err)
                if en<1e-7: break
                eps=1e-5
                J=np.empty((3,7))
                for j in range(7):
                    v=q[j]
                    p.resetJointState(robot,j,float(v+eps))
                    xp=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
                    p.resetJointState(robot,j,float(v-eps))
                    xm=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
                    p.resetJointState(robot,j,float(v))
                    J[:,j]=(xp-xm)/(2*eps)
                dq=J.T@np.linalg.solve(J@J.T+1e-8*np.eye(3),err)
                norm=np.linalg.norm(dq)
                if norm>.3: dq*=.3/norm
                q+=dq
                for j,v in enumerate(q): p.resetJointState(robot,j,float(v))
            xyz=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
            errn=float(np.linalg.norm(target-xyz))
            if best is None or errn<best[0]: best=(errn,q.copy(),xyz.copy())
        return {'joint_angles_rad':best[1].tolist(),'end_effector_xyz_m':best[2].tolist(),'position_error_m':best[0]}
    finally:p.disconnect(cid)
