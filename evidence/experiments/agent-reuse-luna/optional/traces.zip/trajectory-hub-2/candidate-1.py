import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys=['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals={k:list(map(float,task[k])) for k in keys}
    n=len(vals['current_position'])
    inp=InputParameter(n)
    for k,v in vals.items(): setattr(inp,k,v)
    otg=Ruckig(n)
    traj=Trajectory(n)
    result=otg.calculate(inp,traj)
    if result != Result.Working and result != Result.Finished:
        raise ValueError('Ruckig failed: '+str(result))
    duration=float(traj.duration)
    if duration>30: raise ValueError('duration exceeds limit')
    dt=float(task['dt'])
    count=int(np.floor(duration/dt))
    times=[i*dt for i in range(count+1)]
    if not times or times[-1] < duration-1e-12: times.append(duration)
    else: times[-1]=duration
    # guard exact completion and avoid duplicates
    times=sorted(set(times))
    if len(times)<2:
        times=[0.0,duration]
    states=[traj.at_time(t) for t in times]
    p=[list(map(float,s[0])) for s in states]
    v=[list(map(float,s[1])) for s in states]
    a=[list(map(float,s[2])) for s in states]
    # Explicit exact endpoint states avoid numerical residuals from library.
    p[0]=vals['current_position'];v[0]=vals['current_velocity'];a[0]=vals['current_acceleration']
    p[-1]=vals['target_position'];v[-1]=vals['target_velocity'];a[-1]=vals['target_acceleration']
    return {'time_s':list(map(float,times)), 'position':p,'velocity':v,'acceleration':a,'coordinate_type':task['coordinate_type'],'duration_s':duration}
