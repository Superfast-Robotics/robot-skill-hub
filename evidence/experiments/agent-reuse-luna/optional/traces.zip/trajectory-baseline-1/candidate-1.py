import math
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys = ['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    arrays = {k: [float(x) for x in task[k]] for k in keys}
    n=len(arrays['current_position'])
    if any(len(v)!=n for v in arrays.values()):
        raise ValueError('All axis arrays must have the same length')
    dt=float(task['dt'])
    inp=InputParameter(n)
    inp.current_position=arrays['current_position']
    inp.current_velocity=arrays['current_velocity']
    inp.current_acceleration=arrays['current_acceleration']
    inp.target_position=arrays['target_position']
    inp.target_velocity=arrays['target_velocity']
    inp.target_acceleration=arrays['target_acceleration']
    inp.max_velocity=arrays['max_velocity']
    inp.max_acceleration=arrays['max_acceleration']
    inp.max_jerk=arrays['max_jerk']
    otg=Ruckig(n)
    traj=Trajectory(n)
    result=otg.calculate(inp,traj)
    if result != Result.Working and result != Result.Finished:
        raise ValueError(f'Ruckig could not calculate trajectory: {result}')
    duration=float(traj.duration)
    if duration > 30.0 + 1e-9:
        raise ValueError('Trajectory duration exceeds 30 seconds')
    if duration <= 1e-14:
        times=[0.0,0.0]
    else:
        intervals=max(1,int(math.ceil(duration/dt-1e-12)))
        if intervals+1>3000:
            intervals=2999
            if duration/intervals > dt+1e-12:
                raise ValueError('Cannot satisfy both sample count and spacing limits')
        times=[duration*i/intervals for i in range(intervals+1)]
    pos=[]; vel=[]; acc=[]
    for t in times:
        p,v,a=traj.at_time(t)
        pos.append([float(x) for x in p]); vel.append([float(x) for x in v]); acc.append([float(x) for x in a])
    pos[0]=arrays['current_position'][:]
    vel[0]=arrays['current_velocity'][:]
    acc[0]=arrays['current_acceleration'][:]
    pos[-1]=arrays['target_position'][:]
    vel[-1]=arrays['target_velocity'][:]
    acc[-1]=arrays['target_acceleration'][:]
    return {'time_s':times,'position':pos,'velocity':vel,'acceleration':acc,'coordinate_type':task['coordinate_type'],'duration_s':duration}
