import json, math
import numpy as np
import pybullet as p
from scipy.optimize import least_squares

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],dtype=float)
        target=np.asarray(task['target_xyz'],dtype=float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        def fk(q):
            for i,v in enumerate(q): p.resetJointState(robot,i,float(v))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4],dtype=float)
        # IK seeds include initial configuration and the native Bullet solution.
        seeds=[q0.copy()]
        try:
            sol=p.calculateInverseKinematics(robot,6,target.tolist(),maxNumIterations=300,residualThreshold=1e-8)
            if len(sol)>=7: seeds.insert(0,np.asarray(sol[:7],dtype=float))
        except Exception: pass
        best=None
        for seed in seeds:
            lo=seed-2*math.pi; hi=seed+2*math.pi
            res=least_squares(lambda q: fk(q)-target,seed,bounds=(lo,hi),max_nfev=250,xtol=1e-12,ftol=1e-12,gtol=1e-12,diff_step=1e-5)
            err=np.linalg.norm(fk(res.x)-target)
            if best is None or err<best[0]: best=(err,res.x.copy())
            if err<1e-6: break
        err,q=best
        xyz=fk(q)
        return {'joint_angles_rad':[float(x) for x in q], 'end_effector_xyz_m':[float(x) for x in xyz], 'position_error_m':float(np.linalg.norm(xyz-target))}
    finally: p.disconnect(cid)
