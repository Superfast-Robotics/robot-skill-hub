import json, sys, math
import numpy as np

def solve(task):
    import pybullet as p
    if '/public' not in sys.path: sys.path.append('/public')
    from scene import create_arm
    cid=p.connect(p.DIRECT)
    try:
        robot=create_arm(p)
        q0=list(map(float,task['joint_angles']))
        for i,q in enumerate(q0): p.resetJointState(robot,i,q)
        target=list(map(float,task['target_xyz']))
        ik=p.calculateInverseKinematics(robot,6,target,maxNumIterations=500,residualThreshold=1e-10)
        for i,q in enumerate(ik[:7]): p.resetJointState(robot,i,q)
        pos=p.getLinkState(robot,6,computeForwardKinematics=True)[4]
        err=float(np.linalg.norm(np.array(pos)-target))
        return {'joint_angles_rad':[float(x) for x in ik[:7]],'end_effector_xyz_m':[float(x) for x in pos],'position_error_m':err}
    finally: p.disconnect(cid)
