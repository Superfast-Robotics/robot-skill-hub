import math
import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    keys = ['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    vals = {k: [float(x) for x in task[k]] for k in keys}
    n = len(vals['current_position'])
    inp = InputParameter(n)
    for k,v in vals.items():
        setattr(inp,k,v)
    otg = Ruckig(n)
    traj = Trajectory(n)
    result = otg.calculate(inp,traj)
    if result not in (Result.Working, Result.Finished):
        raise ValueError('Ruckig could not calculate trajectory')
    duration = float(traj.duration)
    if duration > 30.0 + 1e-9:
        raise ValueError('trajectory exceeds 30 seconds')
    dt = float(task['dt'])
    count = max(1, int(math.ceil(duration/dt)))
    if count + 1 > 3000:
        raise ValueError('too many samples')
    times = np.linspace(0.0, duration, count+1).tolist()
    pos, vel, acc = [], [], []
    for t in times:
        p,v,a = traj.at_time(t)
        pos.append([float(x) for x in p]); vel.append([float(x) for x in v]); acc.append([float(x) for x in a])
    pos[0] = vals['current_position'][:]; vel[0] = vals['current_velocity'][:]; acc[0] = vals['current_acceleration'][:]
    pos[-1] = vals['target_position'][:]; vel[-1] = vals['target_velocity'][:]; acc[-1] = vals['target_acceleration'][:]
    return {'time_s':times,'position':pos,'velocity':vel,'acceleration':acc,'coordinate_type':task['coordinate_type'],'duration_s':duration}