import math, heapq
import numpy as np

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    lo,hi=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    # Integer-sampled points on the four sides of the square map.
    bpts=[]
    for k in range(int(math.ceil(lo)),int(math.floor(hi))+1):
        bpts.extend(((lo,float(k)),(hi,float(k)),(float(k),lo),(float(k),hi)))
    pts=np.vstack((obs,np.asarray(bpts,dtype=float))) if len(obs) else np.asarray(bpts,dtype=float)
    def seg_clear(a,b):
        if min(a[0],b[0])<=lo or max(a[0],b[0])>=hi or min(a[1],b[1])<=lo or max(a[1],b[1])>=hi:
            return False
        if not len(pts): return True
        v=b-a; vv=float(np.dot(v,v))
        if vv == 0: d2=np.sum((pts-a)**2,axis=1)
        else:
            t=np.clip(((pts-a)@v)/vv,0.,1.)
            q=a+t[:,None]*v
            d2=np.sum((pts-q)**2,axis=1)
        return bool(np.all(d2 > (r+1e-9)**2))
    if not (lo<start[0]<hi and lo<start[1]<hi and lo<goal[0]<hi and lo<goal[1]<hi):
        raise ValueError('start and goal must be strictly inside bounds')
    if seg_clear(start,goal):
        path=[start.tolist(),goal.tolist()]
        return {'path_xy':path,'length_m':float(np.linalg.norm(goal-start))}
    for step in (0.25,0.15,0.10,0.075,0.05):
        nx=int(math.floor((hi-lo)/step))+1; ny=nx
        xs=lo+np.arange(nx,dtype=float)*step; ys=xs.copy()
        margin=step*math.sqrt(2)/2 + 2e-9
        threshold=r+margin
        valid=np.ones((ny,nx),dtype=bool)
        valid[0,:]=False; valid[:,0]=False
        valid[:,xs>=hi]=False; valid[ys>=hi,:]=False
        flat=np.argwhere(valid)
        for off in range(0,len(flat),5000):
            ij=flat[off:off+5000]
            xy=np.column_stack((xs[ij[:,1]],ys[ij[:,0]]))
            if len(pts):
                d2=np.sum((xy[:,None,:]-pts[None,:,:])**2,axis=2)
                good=np.min(d2,axis=1)>threshold*threshold
                valid[ij[:,0],ij[:,1]]=good
        def attachments(p):
            ix=int(round((p[0]-lo)/step)); iy=int(round((p[1]-lo)/step)); out=[]
            for j in range(max(0,iy-2),min(ny,iy+3)):
                for i in range(max(0,ix-2),min(nx,ix+3)):
                    if valid[j,i]:
                        q=np.array([xs[i],ys[j]])
                        if np.linalg.norm(q-p)<=2.1*step and seg_clear(p,q):
                            out.append((j*nx+i,float(np.linalg.norm(q-p))))
            return out
        sa=attachments(start); ga=attachments(goal)
        if not sa or not ga: continue
        gmap={idx:cost for idx,cost in ga}
        n=nx*ny; dist=np.full(n,np.inf); parent=np.full(n,-2,dtype=np.int64)
        heap=[]
        for idx,cost in sa:
            if cost<dist[idx]:
                dist[idx]=cost; parent[idx]=-1
                j,i=divmod(idx,nx)
                heapq.heappush(heap,(cost+math.hypot(xs[i]-goal[0],ys[j]-goal[1]),cost,idx))
        moves=((1,0),(0,1),(-1,0),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
        found=None
        while heap:
            f,g,idx=heapq.heappop(heap)
            if g!=dist[idx]: continue
            if idx in gmap:
                found=idx; break
            j,i=divmod(idx,nx)
            for di,dj in moves:
                ni=i+di; nj=j+dj
                if ni<0 or ni>=nx or nj<0 or nj>=ny or not valid[nj,ni]: continue
                niid=nj*nx+ni; ng=g+step*(math.sqrt(2) if di and dj else 1.)
                if ng+1e-12<dist[niid]:
                    dist[niid]=ng; parent[niid]=idx
                    heapq.heappush(heap,(ng+math.hypot(xs[ni]-goal[0],ys[nj]-goal[1]),ng,niid))
        if found is None: continue
        ids=[]; cur=found
        while cur!=-1 and cur!=-2:
            ids.append(cur); cur=int(parent[cur])
        ids.reverse()
        raw=[start]
        raw.extend(np.array([xs[k%nx],ys[k//nx]]) for k in ids)
        raw.append(goal)
        smooth=[raw[0]]; i=0
        while i<len(raw)-1:
            j=len(raw)-1
            while j>i+1 and not seg_clear(raw[i],raw[j]): j-=1
            smooth.append(raw[j]); i=j
        arr=np.asarray(smooth)
        return {'path_xy':arr.tolist(),'length_m':float(np.sum(np.linalg.norm(np.diff(arr,axis=0),axis=1)))}
    raise RuntimeError('No collision-free path found')