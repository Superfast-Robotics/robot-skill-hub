import math, heapq
import numpy as np

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    bx,by=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    # Integer-sampled perimeter of the rectangular map.
    bpts=[]
    for y in range(int(math.floor(by))+1):
        bpts.extend(((0.,float(y)),(bx,float(y))))
    for x in range(int(math.floor(bx))+1):
        bpts.extend(((float(x),0.),(float(x),by)))
    pts=np.vstack((obs,np.asarray(bpts,dtype=float))) if len(obs) else np.asarray(bpts,dtype=float)
    def seg_clear(a,b):
        if min(a[0],b[0])<=0 or max(a[0],b[0])>=bx or min(a[1],b[1])<=0 or max(a[1],b[1])>=by:
            return False
        if not len(pts): return True
        v=b-a; vv=float(np.dot(v,v))
        if vv == 0: d2=np.sum((pts-a)**2,axis=1)
        else:
            t=np.clip(((pts-a)@v)/vv,0.,1.)
            q=a+t[:,None]*v
            d2=np.sum((pts-q)**2,axis=1)
        return bool(np.all(d2 > (r+1e-9)**2))
    if not (0<start[0]<bx and 0<start[1]<by and 0<goal[0]<bx and 0<goal[1]<by):
        raise ValueError('start and goal must be strictly inside bounds')
    if seg_clear(start,goal):
        path=[start.tolist(),goal.tolist()]
        return {'path_xy':path,'length_m':float(np.linalg.norm(goal-start))}

    # Refine the lattice if a coarser, conservatively inflated search cannot connect.
    for step in (0.25,0.15,0.10,0.075,0.05):
        nx=int(math.floor(bx/step))+1; ny=int(math.floor(by/step))+1
        xs=np.arange(nx,dtype=float)*step; ys=np.arange(ny,dtype=float)*step
        # Keep a margin at grid vertices so every neighboring lattice segment is clear.
        margin=step*math.sqrt(2)/2 + 2e-9
        threshold=r+margin
        valid=np.ones((ny,nx),dtype=bool)
        valid[0,:]=False; valid[:,0]=False
        valid[xs>=bx,:]=False if False else valid[xs>=bx,:] # no-op; apply axis masks below
        valid[:,xs>=bx]=False
        valid[ys>=by,:]=False
        # Batched exact point clearance against obstacles and sampled boundary.
        flat=np.argwhere(valid)
        for off in range(0,len(flat),5000):
            ij=flat[off:off+5000]
            xy=np.column_stack((xs[ij[:,1]],ys[ij[:,0]]))
            if len(pts):
                d2=np.sum((xy[:,None,:]-pts[None,:,:])**2,axis=2)
                good=np.min(d2,axis=1)>threshold*threshold
                valid[ij[:,0],ij[:,1]]=good
        # Attach exact start/goal to nearby valid lattice vertices.
        def attachments(p):
            ix=int(round(p[0]/step)); iy=int(round(p[1]/step)); out=[]
            for j in range(max(0,iy-2),min(ny,iy+3)):
                for i in range(max(0,ix-2),min(nx,ix+3)):
                    if valid[j,i]:
                        q=np.array([xs[i],ys[j]])
                        if np.linalg.norm(q-p)<=2.1*step and seg_clear(p,q):
                            out.append((j*nx+i,float(np.linalg.norm(q-p))))
            return out
        sa=attachments(start); ga=attachments(goal)
        if not sa or not ga: continue
        gmap={idx:cost for idx,cost in ga}
        n=nx*ny; dist=np.full(n,np.inf); parent=np.full(n,-2,dtype=np.int64)
        heap=[]
        for idx,cost in sa:
            if cost<dist[idx]:
                dist[idx]=cost; parent[idx]=-1
                j,i=divmod(idx,nx)
                h=math.hypot(xs[i]-goal[0],ys[j]-goal[1])
                heapq.heappush(heap,(cost+h,cost,idx))
        moves=((1,0),(0,1),(-1,0),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
        found=None
        while heap:
            f,g,idx=heapq.heappop(heap)
            if g!=dist[idx]: continue
            if idx in gmap:
                found=idx; break
            j,i=divmod(idx,nx)
            for di,dj in moves:
                ni=i+di; nj=j+dj
                if ni<0 or ni>=nx or nj<0 or nj>=ny or not valid[nj,ni]: continue
                niid=nj*nx+ni; ng=g+step*(math.sqrt(2) if di and dj else 1.)
                if ng+1e-12<dist[niid]:
                    dist[niid]=ng; parent[niid]=idx
                    h=math.hypot(xs[ni]-goal[0],ys[nj]-goal[1])
                    heapq.heappush(heap,(ng+h,ng,niid))
        if found is None: continue
        ids=[]; cur=found
        while cur!=-1 and cur!=-2:
            ids.append(cur); cur=int(parent[cur])
        ids.reverse()
        raw=[start]
        raw.extend(np.array([xs[k%nx],ys[k//nx]]) for k in ids)
        raw.append(goal)
        # Greedy line-of-sight simplification, with exact continuous checks.
        smooth=[raw[0]]; i=0
        while i<len(raw)-1:
            j=len(raw)-1
            while j>i+1 and not seg_clear(raw[i],raw[j]): j-=1
            smooth.append(raw[j]); i=j
        arr=np.asarray(smooth)
        length=float(np.sum(np.linalg.norm(np.diff(arr,axis=0),axis=1)))
        return {'path_xy':arr.tolist(),'length_m':length}
    raise RuntimeError('No collision-free path found')