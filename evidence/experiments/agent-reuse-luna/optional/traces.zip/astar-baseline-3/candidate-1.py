import numpy as np, math, heapq
from scipy.spatial import cKDTree

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    W,H=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    eps=1e-7
    low=np.array([r+eps,r+eps]); high=np.array([W-r-eps,H-r-eps])
    if np.any(start<=low-eps) or np.any(start>=np.array([W-r-eps,H-r-eps])+eps) or np.any(goal<=low-eps) or np.any(goal>=np.array([W-r-eps,H-r-eps])+eps):
        raise ValueError('endpoint outside safe bounds')
    tree=cKDTree(obs) if len(obs) else None
    def point_ok(p):
        if np.any(p < low) or np.any(p > high): return False
        return tree is None or tree.query(p,k=1)[0] >= r+eps
    def segment_ok(a,b):
        if np.any(a < low) or np.any(a > high) or np.any(b < low) or np.any(b > high): return False
        if tree is None: return True
        d=b-a; L=float(np.linalg.norm(d))
        mid=(a+b)*0.5
        inds=tree.query_ball_point(mid,r+L*0.5+eps)
        if not inds:return True
        q=obs[inds]
        if L==0: ds=np.linalg.norm(q-a,axis=1)
        else:
            t=np.clip(((q-a)@d)/(L*L),0,1)
            ds=np.linalg.norm(q-(a+t[:,None]*d),axis=1)
        return bool(np.all(ds >= r+eps))
    if not point_ok(start) or not point_ok(goal): raise ValueError('endpoint collides')
    if segment_ok(start,goal):
        path=[start.tolist(),goal.tolist()]
        return {'path_xy':path,'length_m':float(np.linalg.norm(goal-start))}
    step=0.1
    nx=int(math.floor((high[0]-low[0])/step+1e-9))+1
    ny=int(math.floor((high[1]-low[1])/step+1e-9))+1
    xs=low[0]+np.arange(nx)*step; ys=low[1]+np.arange(ny)*step
    if tree is None: valid=np.ones((nx,ny),dtype=bool)
    else:
        # query in chunks to limit peak temporary memory
        valid=np.empty(nx*ny,dtype=bool)
        for s in range(0,nx*ny,50000):
            ids=np.arange(s,min(s+50000,nx*ny)); ii=ids//ny; jj=ids%ny
            pts=np.column_stack((xs[ii],ys[jj]))
            valid[s:s+len(ids)]=tree.query(pts,k=1)[0] >= r+eps
        valid=valid.reshape((nx,ny))
    def coord(i,j): return np.array([xs[i],ys[j]])
    def connectors(p):
        i0=int(round((p[0]-low[0])/step)); j0=int(round((p[1]-low[1])/step))
        out=[]
        for i in range(max(0,i0-3),min(nx,i0+4)):
            for j in range(max(0,j0-3),min(ny,j0+4)):
                if valid[i,j]:
                    q=coord(i,j)
                    if np.linalg.norm(q-p)<=0.26 and segment_ok(p,q): out.append((i,j,float(np.linalg.norm(q-p))))
        return out
    starts=connectors(start); goals=connectors(goal)
    if not starts or not goals: raise ValueError('no grid connector')
    # Goal connectors as mapping of grid cell to exact terminal edge cost.
    gmap={(i,j):d for i,j,d in goals}
    dist=np.full((nx,ny),np.inf); parent_i=np.full((nx,ny),-1,dtype=np.int32); parent_j=np.full((nx,ny),-1,dtype=np.int32)
    heap=[]
    for i,j,d in starts:
        if d<dist[i,j]:
            dist[i,j]=d
            heapq.heappush(heap,(d+float(np.linalg.norm(coord(i,j)-goal)),d,i,j))
    moves=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    best=math.inf; end=None
    while heap:
        f,g,i,j=heapq.heappop(heap)
        if g!=dist[i,j]: continue
        if f>=best: break
        if (i,j) in gmap:
            val=g+gmap[(i,j)]
            if val<best: best=val; end=(i,j)
        p=coord(i,j)
        for di,dj in moves:
            ii=i+di; jj=j+dj
            if ii<0 or ii>=nx or jj<0 or jj>=ny or not valid[ii,jj]: continue
            ng=g+step*(math.sqrt(2) if di and dj else 1.0)
            if ng+1e-12>=dist[ii,jj]: continue
            q=coord(ii,jj)
            if not segment_ok(p,q): continue
            dist[ii,jj]=ng; parent_i[ii,jj]=i; parent_j[ii,jj]=j
            heapq.heappush(heap,(ng+float(np.linalg.norm(q-goal)),ng,ii,jj))
    if end is None: raise ValueError('no path found')
    chain=[]; i,j=end
    while i>=0:
        chain.append(coord(i,j)); pi,pj=parent_i[i,j],parent_j[i,j]
        if pi<0: break
        i,j=int(pi),int(pj)
    chain.reverse(); raw=[start]+chain+[goal]
    # Greedily remove intermediate nodes where the entire segment remains valid.
    simp=[raw[0]]; a=0
    while a<len(raw)-1:
        b=len(raw)-1
        while b>a+1 and not segment_ok(raw[a],raw[b]): b-=1
        simp.append(raw[b]); a=b
    length=sum(float(np.linalg.norm(simp[k+1]-simp[k])) for k in range(len(simp)-1))
    return {'path_xy':[p.tolist() for p in simp], 'length_m':length}
