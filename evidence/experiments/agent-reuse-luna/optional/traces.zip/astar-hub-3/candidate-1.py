import math, heapq
import numpy as np
from scipy.spatial import cKDTree

def solve(task):
    start = np.asarray(task['start'], dtype=float)
    goal = np.asarray(task['goal'], dtype=float)
    bx, by = map(float, task['bounds'])
    r = float(task['robot_radius'])
    obs = np.asarray(task['obstacles'], dtype=float).reshape((-1, 2))
    eps = 1e-9
    # Conservative clearance from the complete rectangular boundary is safe for
    # the integer-sampled boundary as well.
    lo = np.array([r + eps, r + eps])
    hi = np.array([bx-r-eps, by-r-eps])
    if np.any(start <= 0) or np.any(start >= [bx,by]) or np.any(goal <= 0) or np.any(goal >= [bx,by]):
        raise ValueError('start and goal must be strictly inside bounds')
    if np.any(start < lo-1e-8) or np.any(start > hi+1e-8) or np.any(goal < lo-1e-8) or np.any(goal > hi+1e-8):
        raise ValueError('start or goal lacks boundary clearance')
    tree = cKDTree(obs) if len(obs) else None
    def clear_segment(a,b):
        if tree is None: return True
        mid=(a+b)*0.5
        rad=r+float(np.linalg.norm(b-a))*0.5+1e-10
        ids=tree.query_ball_point(mid,rad)
        if not ids: return True
        q=obs[ids]
        d=b-a
        dd=float(np.dot(d,d))
        if dd == 0:
            dist=np.linalg.norm(q-a,axis=1)
        else:
            t=np.clip(((q-a)@d)/dd,0.0,1.0)
            dist=np.linalg.norm(q-(a+t[:,None]*d),axis=1)
        return bool(np.all(dist >= r-1e-10))
    if clear_segment(start,goal):
        path=[start.tolist(),goal.tolist()]
        return {'path_xy':path,'length_m':float(np.linalg.norm(goal-start))}
    h=0.1
    nx=int(math.floor(bx/h))+1; ny=int(math.floor(by/h))+1
    xs=np.arange(nx,dtype=float)*h; ys=np.arange(ny,dtype=float)*h
    valid=(xs[:,None] >= lo[0]) & (xs[:,None] <= hi[0]) & (ys[None,:] >= lo[1]) & (ys[None,:] <= hi[1])
    if tree is not None:
        xx,yy=np.meshgrid(xs,ys,indexing='ij')
        dists=tree.query(np.column_stack((xx.ravel(),yy.ravel())),k=1)[0].reshape((nx,ny))
        valid &= dists >= r-1e-10
    # Grid connector candidates near endpoint, retained only if their entire edge is clear.
    def connectors(p):
        ix=int(round(p[0]/h)); iy=int(round(p[1]/h)); out=[]
        for i in range(max(0,ix-4),min(nx,ix+5)):
            for j in range(max(0,iy-4),min(ny,iy+5)):
                if valid[i,j]:
                    q=np.array([xs[i],ys[j]])
                    if np.linalg.norm(q-p) <= 0.42 and clear_segment(p,q):
                        out.append((j*nx+i,float(np.linalg.norm(q-p))))
        return out
    sc=connectors(start); gc=dict(connectors(goal))
    if not sc or not gc:
        raise ValueError('unable to connect endpoint to safe planning grid')
    n=nx*ny
    costs=np.full(n,np.inf); parent=np.full(n,-2,dtype=np.int64)
    heap=[]
    for idx,c in sc:
        if c<costs[idx]:
            costs[idx]=c; parent[idx]=-1
            x=(idx%nx)*h; y=(idx//nx)*h
            heapq.heappush(heap,(c+math.hypot(goal[0]-x,goal[1]-y),c,idx))
    motions=[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    finished=None
    while heap:
        f,g,u=heapq.heappop(heap)
        if g > costs[u]+1e-12: continue
        i=u%nx; j=u//nx
        p=np.array([xs[i],ys[j]])
        if u in gc and clear_segment(p,goal):
            finished=u; break
        for di,dj in motions:
            ni=i+di; nj=j+dj
            if ni<0 or ni>=nx or nj<0 or nj>=ny or not valid[ni,nj]: continue
            v=nj*nx+ni
            q=np.array([xs[ni],ys[nj]])
            step=h*math.hypot(di,dj)
            ng=g+step
            if ng+1e-12 >= costs[v]: continue
            if not clear_segment(p,q): continue
            costs[v]=ng; parent[v]=u
            heapq.heappush(heap,(ng+math.hypot(goal[0]-q[0],goal[1]-q[1]),ng,v))
    if finished is None:
        raise ValueError('no collision-free path found')
    ids=[]; u=finished
    while u!=-1:
        ids.append(u); u=int(parent[u])
    ids.reverse()
    raw=[start.copy()]
    raw += [np.array([(u%nx)*h,(u//nx)*h]) for u in ids]
    raw.append(goal.copy())
    # Greedy line-of-sight shortcutting, with exact continuous segment checks.
    simp=[raw[0]]; i=0
    while i<len(raw)-1:
        j=len(raw)-1
        while j>i+1 and not clear_segment(raw[i],raw[j]): j-=1
        simp.append(raw[j]); i=j
    path=[p.tolist() for p in simp]
    length=sum(float(np.linalg.norm(simp[k+1]-simp[k])) for k in range(len(simp)-1))
    return {'path_xy':path,'length_m':float(length)}