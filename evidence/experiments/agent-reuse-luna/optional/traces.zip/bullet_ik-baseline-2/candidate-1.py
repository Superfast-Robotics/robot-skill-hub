import pybullet as p, numpy as np, sys
sys.path.insert(0,'/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],float)
        target=np.asarray(task['target_xyz'],float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        # use IK with seed
        sol=p.calculateInverseKinematics(robot,6,target.tolist(), restPoses=q0.tolist(), maxNumIterations=300, residual לע=1e-8)
    finally: p.disconnect(cid)
    return {}
