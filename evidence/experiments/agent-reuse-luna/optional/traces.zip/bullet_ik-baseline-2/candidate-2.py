import pybullet as p, numpy as np, sys
sys.path.insert(0,'/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],float)
        target=np.asarray(task['target_xyz'],float)
        for i,q in enumerate(q0): p.resetJointState(robot,i,float(q))
        sol=p.calculateInverseKinematics(robot,6,target.tolist(), restPoses=q0.tolist(), maxNumIterations=500, residualThreshold=1e-10, jointDamping=[0.02]*7)
        q=np.asarray(sol[:7],float)
        for i,v in enumerate(q): p.resetJointState(robot,i,float(v))
        xyz=np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
        err=float(np.linalg.norm(xyz-target))
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':xyz.tolist(),'position_error_m':err}
    finally: p.disconnect(cid)
