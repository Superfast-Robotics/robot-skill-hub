import math

def solve(task):
    from ruckig import InputParameter, Ruckig, Trajectory, Result
    n = len(task['current_position'])
    inp = InputParameter(n)
    fields = ['current_position','current_velocity','current_acceleration','target_position','target_velocity','target_acceleration','max_velocity','max_acceleration','max_jerk']
    for f in fields:
        setattr(inp, f, [float(x) for x in task[f]])
    # Use symmetric bounds as specified by per-axis maxima.
    inp.min_velocity = [-float(x) for x in task['max_velocity']]
    inp.min_acceleration = [-float(x) for x in task['max_acceleration']]
    otg = Ruckig(n)
    traj = Trajectory(n)
    result = otg.calculate(inp, traj)
    if result != Result.Working and result != Result.Finished:
        raise ValueError('Ruckig could not calculate a feasible trajectory')
    T = float(traj.duration)
    if not math.isfinite(T) or T <= 0 or T > 30:
        raise ValueError('trajectory duration outside requested range')
    dt = float(task['dt'])
    count = max(1, int(math.ceil(T/dt)))
    if count+1 > 3000:
        raise ValueError('too many samples')
    times = [T*i/count for i in range(count+1)]
    positions=[]; velocities=[]; accelerations=[]
    for t in times:
        p,v,a = traj.at_time(t)
        positions.append([float(x) for x in p])
        velocities.append([float(x) for x in v])
        accelerations.append([float(x) for x in a])
    # Enforce the requested exact boundary values against endpoint numerical roundoff.
    positions[0] = [float(x) for x in task['current_position']]
    velocities[0] = [float(x) for x in task['current_velocity']]
    accelerations[0] = [float(x) for x in task['current_acceleration']]
    positions[-1] = [float(x) for x in task['target_position']]
    velocities[-1] = [float(x) for x in task['target_velocity']]
    accelerations[-1] = [float(x) for x in task['target_acceleration']]
    return {'time_s':times,'position':positions,'velocity':velocities,'acceleration':accelerations,'coordinate_type':task['coordinate_type'],'duration_s':T}