import numpy as np
import pybullet as p
import sys
sys.path.insert(0, '/public')
import scene

def solve(task):
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'], dtype=float)
        target=np.asarray(task['target_xyz'], dtype=float)
        for j,v in enumerate(q0): p.resetJointState(robot,j,float(v))
        def fk(q):
            for j,v in enumerate(q): p.resetJointState(robot,j,float(v))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4],dtype=float)
        # Damped least squares, with line search and adaptive damping.
        q=q0.copy(); lam=1e-3
        pos=fk(q); err=target-pos
        for it in range(300):
            nerr=np.linalg.norm(err)
            if nerr < 2e-6: break
            h=1e-5
            J=np.empty((3,7))
            for k in range(7):
                qt=q.copy(); qt[k]+=h
                J[:,k]=(fk(qt)-pos)/h
            # damped pseudoinverse
            step=J.T @ np.linalg.solve(J@J.T + lam*lam*np.eye(3), err)
            sn=np.linalg.norm(step)
            if sn>0.5: step*=0.5/sn
            improved=False
            for scale in (1.,.5,.25,.125,.0625,.03125):
                qn=q+scale*step
                pn=fk(qn); en=target-pn
                if np.linalg.norm(en)<nerr:
                    q,pos,err=qn,pn,en
                    lam=max(1e-6,lam*.5)
                    improved=True
                    break
            if not improved:
                lam=min(1.,lam*10)
                if lam>=1.: break
        pos=fk(q)
        # normalize angles to principal values to keep a compact valid solution
        q=(q+np.pi)%(2*np.pi)-np.pi
        pos=fk(q)
        error=float(np.linalg.norm(pos-target))
        return {'joint_angles_rad':q.tolist(),'end_effector_xyz_m':pos.tolist(),'position_error_m':error}
    finally: p.disconnect(cid)