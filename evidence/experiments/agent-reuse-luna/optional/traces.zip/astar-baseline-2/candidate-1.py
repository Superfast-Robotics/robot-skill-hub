import math, heapq
import numpy as np
from scipy.spatial import cKDTree

def solve(task):
    start=np.asarray(task['start'],dtype=float); goal=np.asarray(task['goal'],dtype=float)
    lo,hi=map(float,task['bounds']); r=float(task['robot_radius'])
    obs=np.asarray(task['obstacles'],dtype=float).reshape((-1,2))
    # The boundary is the integer-sampled perimeter, treated just like point obstacles.
    bd=[]
    for x in range(math.ceil(lo),math.floor(hi)+1):
        bd.extend(((float(x),lo),(float(x),hi)))
    for y in range(math.ceil(lo),math.floor(hi)+1):
        bd.extend(((lo,float(y)),(hi,float(y))))
    allobs=np.vstack((obs,np.asarray(bd,dtype=float)))
    tree=cKDTree(allobs)
    eps=1e-8
    def segment_ok(a,b):
        if min(a[0],b[0]) <= lo or max(a[0],b[0]) >= hi or min(a[1],b[1]) <= lo or max(a[1],b[1]) >= hi:
            return False
        d=b-a; L2=float(d@d)
        mid=(a+b)*.5
        cand=tree.query_ball_point(mid,r+math.sqrt(L2)*.5+1e-10)
        if cand:
            q=allobs[cand]
            if L2 < 1e-24: ds=np.linalg.norm(q-a,axis=1)
            else:
                t=np.clip(((q-a)@d)/L2,0.,1.)
                ds=np.linalg.norm(q-(a+t[:,None]*d),axis=1)
            if np.any(ds <= r+eps): return False
        return True
    if not (lo < start[0] < hi and lo < start[1] < hi and lo < goal[0] < hi and lo < goal[1] < hi):
        raise ValueError('start/goal outside bounds')
    if not segment_ok(start,start) or not segment_ok(goal,goal): raise ValueError('invalid endpoint')
    if segment_ok(start,goal):
        p=[start,goal]
        return {'path_xy':[v.tolist() for v in p], 'length_m':float(np.linalg.norm(goal-start))}
    for step in (.25,.12,.06,.03):
        # Uniform grid strictly inside bounds.
        xs=np.arange(lo+step*.5,hi,step)
        ys=np.arange(lo+step*.5,hi,step)
        xx,yy=np.meshgrid(xs,ys,indexing='xy')
        pts=np.column_stack((xx.ravel(),yy.ravel()))
        d,_=tree.query(pts,k=1)
        valid=(d > r+eps) & (pts[:,0]>lo) & (pts[:,0]<hi) & (pts[:,1]>lo) & (pts[:,1]<hi)
        ny,nx=len(ys),len(xs)
        valid=valid.reshape(ny,nx)
        # Connect endpoint to nearby lattice cells with collision-free segments.
        def nearby(p):
            ix=int(round((p[0]-(lo+step*.5))/step)); iy=int(round((p[1]-(lo+step*.5))/step))
            out=[]
            for rad in (2,4):
                for j in range(max(0,iy-rad),min(ny,iy+rad+1)):
                    for i in range(max(0,ix-rad),min(nx,ix+rad+1)):
                        if valid[j,i]:
                            q=np.array([xs[i],ys[j]])
                            if np.linalg.norm(q-p)<=step*(rad+0.8) and segment_ok(p,q):
                                out.append((j*nx+i,float(np.linalg.norm(q-p))))
                if out: break
            return out
        seeds=nearby(start); ends=dict(nearby(goal))
        if not seeds or not ends: continue
        N=nx*ny
        g=np.full(N,np.inf); prev=np.full(N,-1,dtype=np.int64)
        heap=[]
        for idx,c in seeds:
            if c<g[idx]:
                g[idx]=c; heapq.heappush(heap,(c+np.linalg.norm(pts[idx]-goal),c,idx))
        found=-1
        offsets=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
        while heap:
            f,gu,u=heapq.heappop(heap)
            if gu != g[u]: continue
            if u in ends:
                found=u; break
            j,i=divmod(u,nx); a=pts[u]
            for dj,di in offsets:
                jj,ii=j+dj,i+di
                if jj<0 or jj>=ny or ii<0 or ii>=nx or not valid[jj,ii]: continue
                v=jj*nx+ii; b=pts[v]
                if not segment_ok(a,b): continue
                ng=gu+float(np.linalg.norm(b-a))
                if ng+1e-12 < g[v]:
                    g[v]=ng; prev[v]=u
                    heapq.heappush(heap,(ng+float(np.linalg.norm(b-goal)),ng,v))
        if found<0: continue
        ids=[]; u=found
        while u>=0:
            ids.append(u); u=int(prev[u])
        ids.reverse()
        raw=[start]+[pts[u] for u in ids]+[goal]
        # Greedy line-of-sight simplification preserves exact continuous clearance.
        simp=[raw[0]]; i=0
        while i<len(raw)-1:
            j=len(raw)-1
            while j>i+1 and not segment_ok(raw[i],raw[j]): j-=1
            simp.append(raw[j]); i=j
        length=sum(float(np.linalg.norm(simp[k+1]-simp[k])) for k in range(len(simp)-1))
        if len(simp)<=2048:
            return {'path_xy':[v.tolist() for v in simp], 'length_m':length}
    raise ValueError('no feasible path found')