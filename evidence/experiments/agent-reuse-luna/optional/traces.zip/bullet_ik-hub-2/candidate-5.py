import sys, numpy as np

def solve(task):
 import pybullet as p
 if '/public' not in sys.path: sys.path.insert(0,'/public')
 import scene
 cid=p.connect(p.DIRECT)
 try:
  r=scene.create_arm(p)
  q0=task['joint_angles']; target=task['target_xyz']
  for i,v in enumerate(q0): p.resetJointState(r,i,float(v))
  q=p.calculateInverseKinematics(r,6,target,maxNumIterations=1000,residualThreshold=1e-8)
  for i,v in enumerate(q[:7]): p.resetJointState(r,i,float(v))
  pos=p.getLinkState(r,6,computeForwardKinematics=True)[4]
  err=float(np.linalg.norm(np.asarray(pos)-np.asarray(target)))
  return {'joint_angles_rad':[float(x) for x in q[:7]],'end_effector_xyz_m':[float(x) for x in pos],'position_error_m':err}
 finally: p.disconnect(cid)
