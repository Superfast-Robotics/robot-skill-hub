import math,sys,numpy as np
from scipy.optimize import least_squares
def solve(task):
 import pybullet as p
 sys.path.insert(0,'/public'); import scene
 cid=p.connect(p.DIRECT); robot=scene.create_arm(p); q0=np.array(task['joint_angles']); target=np.array(task['target_xyz'])
 def fk(q):
  for j,v in enumerate(q): p.resetJointState(robot,j,float(v))
  return np.array(p.getLinkState(robot,6,computeForwardKinematics=True)[4])
 def f(q): return fk(q)-target
 print('initial',fk(q0), 'target',target)
 res=least_squares(f,q0,method='trf',max_nfev=1000,ftol=1e-14,xtol=1e-14,gtol=1e-14)
 print('res',res.x, f(res.x),res.message,res.nfev)
 raise ValueError(repr((res.x.tolist(),fk(res.x).tolist(),np.linalg.norm(f(res.x)))))