import sys,numpy as np

def solve(task):
 import pybullet as p
 sys.path.insert(0,'/public'); import scene
 c=p.connect(p.DIRECT); r=scene.create_arm(p)
 q0=task['joint_angles']; target=task['target_xyz']
 for i,v in enumerate(q0):p.resetJointState(r,i,v)
 poses=p.calculateInverseKinematics(r,6,target,maxNumIterations=1000,residualThreshold=1e-8)
 for i,v in enumerate(poses[:7]):p.resetJointState(r,i,v)
 state=p.getLinkState(r,6)
 raise ValueError(repr((poses,state[4],np.linalg.norm(np.array(state[4])-target))))