import math, sys
import numpy as np
from scipy.optimize import least_squares

def solve(task):
    import pybullet as p
    if '/public' not in sys.path: sys.path.insert(0, '/public')
    import scene
    cid=p.connect(p.DIRECT)
    try:
        robot=scene.create_arm(p)
        q0=np.asarray(task['joint_angles'],dtype=float); target=np.asarray(task['target_xyz'],dtype=float)
        def fk(q):
            for j,v in enumerate(q): p.resetJointState(robot,j,float(v))
            return np.asarray(p.getLinkState(robot,6,computeForwardKinematics=True)[4],dtype=float)
        def fun(q): return fk(q)-target
        best=q0.copy(); besterr=float(np.linalg.norm(fun(best)))
        starts=[q0, q0+np.array([0,.7,-.6,.5,.4,-.5,.3]), q0+np.array([.8,-.6,.7,-.7,.5,.6,-.8]), q0+np.array([-1.,.5,.8,.4,-.7,.5,.6])]
        for st in starts:
            res=least_squares(fun,st,method='trf',max_nfev=500,ftol=1e-12,xtol=1e-12,gtol=1e-12)
            e=float(np.linalg.norm(fun(res.x)))
            if e<besterr: best,besterr=res.x.copy(),e
            if besterr<5e-5: break
        q=((best+math.pi)%(2*math.pi))-math.pi
        pos=fk(q); err=float(np.linalg.norm(pos-target))
        return {'joint_angles_rad':[float(x) for x in q], 'end_effector_xyz_m':[float(x) for x in pos], 'position_error_m':err}
    finally: p.disconnect(cid)
