import math, sys
import numpy as np
from scipy.optimize import least_squares

def solve(task):
    import pybullet as p
    if '/public' not in sys.path:
        sys.path.insert(0, '/public')
    import scene
    client = p.connect(p.DIRECT)
    try:
        robot = scene.create_arm(p)
        q0 = np.asarray(task['joint_angles'], dtype=float)
        target = np.asarray(task['target_xyz'], dtype=float)
        for i, q in enumerate(q0):
            p.resetJointState(robot, i, float(q))

        def fk(q):
            for j, v in enumerate(q):
                p.resetJointState(robot, j, float(v))
            return np.asarray(p.getLinkState(robot, 6, computeForwardKinematics=True)[4], dtype=float)

        def fun(q):
            return fk(q) - target

        best_q = q0.copy()
        best_err = np.linalg.norm(fun(best_q))
        starts = [q0]
        # A few deterministic alternatives help when the initial configuration is singular or distant.
        starts += [q0 + d for d in (np.array([0, .7, -.6, .5, .4, -.5, .3]),
                                     np.array([.8, -.6, .7, -.7, .5, .6, -.8]),
                                     np.array([-1., .5, .8, .4, -.7, .5, .6]))]
        for start in starts:
            res = least_squares(fun, start, method='lm', max_nfev=800,
                                ftol=1e-12, xtol=1e-12, gtol=1e-12)
            e = float(np.linalg.norm(fun(res.x)))
            if e < best_err:
                best_q, best_err = res.x.copy(), e
            if best_err < 5e-5:
                break
        qout = ((best_q + math.pi) % (2*math.pi)) - math.pi
        pos = fk(qout)
        err = float(np.linalg.norm(pos-target))
        return {'joint_angles_rad': [float(x) for x in qout],
                'end_effector_xyz_m': [float(x) for x in pos],
                'position_error_m': err}
    finally:
        p.disconnect(client)
