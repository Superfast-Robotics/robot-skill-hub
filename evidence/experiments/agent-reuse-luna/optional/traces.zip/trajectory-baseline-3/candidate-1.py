import math
import numpy as np
from ruckig import InputParameter, Ruckig, Trajectory, Result

def solve(task):
    p0 = list(map(float, task['current_position']))
    n = len(p0)
    inp = InputParameter(n)
    inp.current_position = p0
    inp.current_velocity = list(map(float, task['current_velocity']))
    inp.current_acceleration = list(map(float, task['current_acceleration']))
    inp.target_position = list(map(float, task['target_position']))
    inp.target_velocity = list(map(float, task['target_velocity']))
    inp.target_acceleration = list(map(float, task['target_acceleration']))
    inp.max_velocity = list(map(float, task['max_velocity']))
    inp.max_acceleration = list(map(float, task['max_acceleration']))
    inp.max_jerk = list(map(float, task['max_jerk']))
    otg = Ruckig(n)
    traj = Trajectory(n)
    result = otg.calculate(inp, traj)
    if result != Result.Working and result != Result.Finished:
        raise ValueError('Ruckig failed to calculate a feasible trajectory')
    duration = float(traj.duration)
    dt = float(task['dt'])
    if duration <= 1e-12:
        # A stationary boundary-to-boundary trajectory; retain the two required endpoint samples.
        times = [0.0, 0.0]
        positions = [p0, p0.copy()]
        velocities = [list(inp.current_velocity), list(inp.current_velocity)]
        accelerations = [list(inp.current_acceleration), list(inp.current_acceleration)]
    else:
        intervals = max(1, int(math.ceil(duration / dt - 1e-12)))
        if intervals > 2999:
            raise ValueError('Trajectory cannot meet both sample-count and sample-spacing limits')
        times = [duration * k / intervals for k in range(intervals + 1)]
        positions, velocities, accelerations = [], [], []
        for t in times:
            pos, vel, acc = traj.at_time(t)
            positions.append([float(x) for x in pos])
            velocities.append([float(x) for x in vel])
            accelerations.append([float(x) for x in acc])
        # Preserve exact requested boundary states against floating point evaluation.
        positions[0] = p0
        velocities[0] = list(map(float, task['current_velocity']))
        accelerations[0] = list(map(float, task['current_acceleration']))
        positions[-1] = list(map(float, task['target_position']))
        velocities[-1] = list(map(float, task['target_velocity']))
        accelerations[-1] = list(map(float, task['target_acceleration']))
    return {'time_s': times, 'position': positions, 'velocity': velocities,
            'acceleration': accelerations, 'coordinate_type': task['coordinate_type'],
            'duration_s': duration}
